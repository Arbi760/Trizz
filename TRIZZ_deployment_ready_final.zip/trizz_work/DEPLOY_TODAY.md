# TRIZZ — Deployment Today

## 1. Supabase
1. Open the TRIZZ Supabase project.
2. SQL Editor → run `supabase/schema.sql`.
3. Run `supabase/seed.sql` only after reviewing the business/legal values. The seed intentionally leaves crypto deposit disabled and support channels empty until an authorized admin configures them.
4. Authentication → Providers → Google: enable Google and enter the Google OAuth Client ID/Secret.
5. Add production Site URL and Redirect URLs for the final domain.

## 2. Environment variables
Server:
- `VITE_SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY` (server-only; never expose it to Vite/browser)
- `TRIZZ_ALLOWED_ORIGINS` (comma-separated production origins)

Browser:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

## 3. Build
`npm install`
`npm run lint`
`npm run build`
`npm start`

## 4. Production checks
- `/api/health` returns JSON.
- Sign up/sign in uses Supabase Auth.
- Google sign-in uses Supabase OAuth, not an email/credential shortcut.
- Password recovery uses Supabase recovery email.
- No custom `trz_token_*` browser sessions.
- No public withdrawal demo bypass.
- Deposit proof never creates a fabricated transaction or credits a wallet by itself.
- Wallet-changing operations use database functions/RPC.
- Withdrawal settlement requires the configured server-side window and atomic function.
- No service-role key is present in client code.

## Important
The project is not declared production-ready until the real Supabase project has the schema applied and `npm run lint` + `npm run build` pass on the deployment environment.
