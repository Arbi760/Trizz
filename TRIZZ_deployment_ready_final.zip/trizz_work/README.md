# TRIZZ Public Platform

Production-oriented React/Vite + Express + Supabase application.

## Stack
- React + Vite + TypeScript
- Express Node backend
- Supabase Auth + PostgreSQL/RLS

## Security model
- Supabase Auth owns user sessions.
- Browser uses only the Supabase anon key.
- Service-role credentials are server-only.
- Wallet-changing financial operations use PostgreSQL RPC functions and an immutable ledger.
- Deposit proof does not credit balances by itself; provider/backend verification is required.
- No client-controlled withdrawal/demo bypass exists.
- No in-memory database is used by the API.

## Run
```bash
npm install
npm run lint
npm run build
npm start
```

Apply `supabase/schema.sql` before using authenticated or wallet features. Review `supabase/seed.sql` before running it in production.
