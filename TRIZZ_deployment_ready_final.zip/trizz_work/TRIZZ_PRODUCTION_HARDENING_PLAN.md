# TRIZZ — Production Hardening & Deployment Plan

Status: NOT PRODUCTION READY
Source: downloaded `trizz.zip` from Google AI Studio

## P0 blockers
1. Replace custom in-memory sessions (`db.sessions`, `trz_token_*`) with Supabase Auth access/refresh sessions.
2. Replace `/api/auth/google` payload decoding/direct-email login with real Supabase/Google OAuth token verification.
3. Remove hardcoded Google identity/account UI.
4. Implement real password recovery with Supabase Auth.
5. Remove or implement real MFA; never advertise unenforced 2FA.
6. Remove in-memory database as a production source of truth.
7. Route wallet/plan/withdrawal financial state changes through atomic, database-controlled operations.
8. Remove client/demo withdrawal bypass (`bypassWindowCheckForDemo`, `forceWindowOpenForTesting`).
9. Remove deposit verification fallback that creates a fixed $50 transaction when verification fails.
10. Remove hardcoded crypto address from application/seed data.
11. Remove financial mock/fallback data returned when API requests fail.
12. Harden Supabase SQL: safe SECURITY DEFINER search_path, caller identity checks, strict RLS, immutable ledger/audit trail, controlled financial operations.

## P1 blockers
- Restrict CORS to configured production origins.
- Add security headers and rate limiting.
- Protect/reduce Supabase diagnostics endpoint.
- Restrict financial transaction mutation to controlled server/database operations.
- Harden KYC, task submission, referral reward, notification and support-ticket policies.
- Remove broad admin FOR ALL policies where controlled functions are appropriate.
- Move admin-controlled content/configuration to Supabase.
- Ensure no service-role key is exposed to Vite/browser variables.

## P2 cleanup
- Rename `react-example` project metadata to TRIZZ.
- Rewrite README for independent deployment.
- Remove unused Google GenAI dependency if confirmed unused.
- Remove remaining hardcoded operational content that Admin must control.
- Add production build/start/health checks.

## Deployment architecture

TRIZZ Public Website
  -> secure Node/API layer
  -> Supabase Auth + PostgreSQL/RLS/RPC

TRIZZ Admin Control Center (separate application)
  -> same Supabase project

Custom domains can be connected after the public app passes the production checks.

## Important financial boundary
This plan intentionally does not implement guaranteed investment returns or unlicensed public deposit-taking mechanics. Genuine wallet/payment functionality must use verified transactions and, where required, authorized providers/compliance controls.
