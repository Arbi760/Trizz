const sharp = require("sharp");
const fs = require("fs");
const path = require("path");

async function processLogo() {
  console.log("Loading public/trizz-logo.png...");
  const srcPath = path.join(__dirname, "../public/trizz-logo.png");
  const input = await sharp(srcPath).raw().toBuffer({ resolveWithObject: true });
  const w = input.info.width;
  const h = input.info.height;
  const srcData = input.data;

  console.log(`Source dimensions: ${w}x${h}`);

  // Step 1: Calculate artwork confidence for every pixel
  // An artwork pixel is either:
  // (A) Chrome/metallic: neutral color balance, blue > 18, red > 22, luminance > 32
  // (B) Neon-lime: high green (g > 100) and high red (r > 50)
  // Everything else is background (black or ambient green bloom/glow spill)

  const confidence = new Float32Array(w * h);

  for (let i = 0; i < w * h; i++) {
    const r = srcData[i * 3];
    const g = srcData[i * 3 + 1];
    const b = srcData[i * 3 + 2];

    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    const maxVal = Math.max(r, g, b);
    const minVal = Math.min(r, g, b);

    // Chrome metric:
    // Chrome letters have balanced RGB. Both r and b are well above 0.
    // Even in deep shadow chrome bevels, r and b are present (e.g. r=30, g=36, b=36).
    // In background glow spill, b is 0..7 and r is 0..15.
    let chromeConf = 0;
    if (minVal >= 32 && lum >= 42) {
      chromeConf = 1.0;
    } else if (minVal >= 18 && lum >= 28 && (r >= 22 && b >= 18)) {
      // Transition zone
      const tMin = (minVal - 18) / 14;
      const tLum = (lum - 28) / 14;
      chromeConf = Math.min(tMin, tLum);
    }

    // Neon lime metric:
    // Neon lime elements are bright yellow-green.
    // Solid neon lime: g >= 140 && r >= 85
    // Neon edge: g >= 95 && r >= 55 && (g + r) >= 170
    let neonConf = 0;
    if (g >= 140 && r >= 85) {
      neonConf = 1.0;
    } else if (g >= 90 && r >= 50 && (g + r) >= 160) {
      const tSum = ((g + r) - 160) / 60;
      const tG = (g - 90) / 50;
      neonConf = Math.min(1.0, Math.max(0.0, Math.min(tSum, tG)));
    }

    // Combined confidence in [0, 1]
    const conf = Math.max(0.0, Math.min(1.0, Math.max(chromeConf, neonConf)));
    confidence[i] = conf;
  }

  // Step 2: Remove any isolated stray noise outside the main logo bounding box
  // The main logo is known to reside strictly within x: [90, 935], y: [155, 865]
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      if (y < 155 || y > 865 || x < 90 || x > 935) {
        confidence[y * w + x] = 0;
      }
    }
  }

  // Step 3: Pinhole filling / bilateral edge preservation
  // If a pixel is completely surrounded by solid artwork (e.g. an internal dark chrome reflection line)
  // ensure it remains solid so the chrome reflection looks authentic.
  const refinedConf = new Float32Array(confidence);

  for (let y = 160; y < 860; y++) {
    for (let x = 95; x < 930; x++) {
      const idx = y * w + x;
      const c = confidence[idx];
      if (c < 1.0 && c > 0.0) {
        // If all 4 cardinal neighbors are solid (1.0), fill to 1.0
        const up = confidence[(y - 1) * w + x];
        const down = confidence[(y + 1) * w + x];
        const left = confidence[y * w + (x - 1)];
        const right = confidence[y * w + (x + 1)];
        if (up === 1.0 && down === 1.0 && left === 1.0 && right === 1.0) {
          refinedConf[idx] = 1.0;
        }
      }
    }
  }

  // Step 4: Construct RGBA buffer with de-fringed colors
  const outRgba = Buffer.alloc(w * h * 4);

  let solidCount = 0;
  let semiCount = 0;
  let zeroCount = 0;

  for (let i = 0; i < w * h; i++) {
    const r = srcData[i * 3];
    const g = srcData[i * 3 + 1];
    const b = srcData[i * 3 + 2];

    const conf = refinedConf[i];

    if (conf >= 0.99) {
      outRgba[i * 4] = r;
      outRgba[i * 4 + 1] = g;
      outRgba[i * 4 + 2] = b;
      outRgba[i * 4 + 3] = 255;
      solidCount++;
    } else if (conf <= 0.01) {
      outRgba[i * 4] = 0;
      outRgba[i * 4 + 1] = 0;
      outRgba[i * 4 + 2] = 0;
      outRgba[i * 4 + 3] = 0;
      zeroCount++;
    } else {
      // Semi-transparent edge: Hermite smoothstep alpha
      const a = conf * conf * (3 - 2 * conf);
      const alphaByte = Math.round(a * 255);

      // Color de-fringing (unpremultiplying black / ambient glow)
      // Since pixel was composite of object and dark background:
      // Object color = (composite - bg * (1-a)) / a
      const bgR = 2 * (1 - a);
      const bgG = 12 * (1 - a);
      const bgB = 1 * (1 - a);

      const unmixedR = Math.min(255, Math.max(0, Math.round((r - bgR) / a)));
      const unmixedG = Math.min(255, Math.max(0, Math.round((g - bgG) / a)));
      const unmixedB = Math.min(255, Math.max(0, Math.round((b - bgB) / a)));

      outRgba[i * 4] = unmixedR;
      outRgba[i * 4 + 1] = unmixedG;
      outRgba[i * 4 + 2] = unmixedB;
      outRgba[i * 4 + 3] = alphaByte;
      semiCount++;
    }
  }

  console.log(`Processing complete:`);
  console.log(`- Solid pixels: ${solidCount} (${((solidCount / (w*h))*100).toFixed(1)}%)`);
  console.log(`- Semi-transparent edge pixels: ${semiCount} (${((semiCount / (w*h))*100).toFixed(1)}%)`);
  console.log(`- 100% Transparent pixels: ${zeroCount} (${((zeroCount / (w*h))*100).toFixed(1)}%)`);

  // Step 5: Save master transparent 1024x1024 asset
  const target1024 = path.join(__dirname, "../public/trizz-logo.png");
  await sharp(outRgba, { raw: { width: w, height: h, channels: 4 } })
    .png({ compressionLevel: 9 })
    .toFile(target1024);
  console.log(`Saved transparent 1024x1024 logo to: ${target1024}`);

  // Step 6: Generate pixel-perfect 512x512 transparent logo
  const target512 = path.join(__dirname, "../public/trizz-logo-512.png");
  await sharp(target1024)
    .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png({ compressionLevel: 9 })
    .toFile(target512);
  console.log(`Saved transparent 512x512 logo to: ${target512}`);

  // Step 7: Also update other derived icons (favicon, android-chrome, apple-touch-icon)
  // to ensure consistency across the entire app ecosystem
  const targetFavicon32 = path.join(__dirname, "../public/favicon-32x32.png");
  await sharp(target512)
    .resize(32, 32, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetFavicon32);

  const targetFavicon16 = path.join(__dirname, "../public/favicon-16x16.png");
  await sharp(target512)
    .resize(16, 16, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetFavicon16);

  const targetFavicon = path.join(__dirname, "../public/favicon.png");
  await sharp(target512)
    .resize(64, 64, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetFavicon);

  const targetApple = path.join(__dirname, "../public/apple-touch-icon.png");
  await sharp(target512)
    .resize(180, 180, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetApple);

  const targetAndroid192 = path.join(__dirname, "../public/android-chrome-192x192.png");
  await sharp(target512)
    .resize(192, 192, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetAndroid192);

  const targetAndroid512 = path.join(__dirname, "../public/android-chrome-512x512.png");
  await sharp(target512)
    .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png()
    .toFile(targetAndroid512);

  console.log("All derived logo assets regenerated with transparent backgrounds!");
}

processLogo().catch(err => {
  console.error("Error processing logo:", err);
  process.exit(1);
});
