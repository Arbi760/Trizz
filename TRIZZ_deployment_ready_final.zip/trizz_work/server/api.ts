import express, { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import { supabaseServer, isSupabaseConfigured, checkTableExists, sendSchemaNotReadyResponse } from "./supabaseServer.ts";

export const apiRouter = express.Router();

const requireSupabase = (res: Response) => {
  if (!isSupabaseConfigured || !supabaseServer) {
    res.status(503).json({ error: "Supabase is not configured.", code: "SUPABASE_NOT_CONFIGURED" });
    return false;
  }
  return true;
};

function normalizeUser(row: any) {
  return {
    id: row.id, fullName: row.full_name, username: row.username, email: row.email,
    phone: row.phone, country: row.country, currencyPreference: row.currency_preference,
    referralCode: row.referral_code, referredBy: row.referred_by, role: row.role,
    planTier: row.plan_tier || "FREE", verificationStatus: row.verification_status || "not_verified",
    isActive: row.is_active, isBanned: row.is_banned, createdAt: row.created_at,
    supabaseAuthId: row.supabase_auth_id,
  };
}

async function loadUserByAuthId(authId: string) {
  if (!supabaseServer) return null;
  const { data, error } = await supabaseServer.from("users").select("*").eq("supabase_auth_id", authId).maybeSingle();
  if (error) throw error;
  return data;
}

async function liveSettings() {
  if (!supabaseServer) return null;
  const { data, error } = await supabaseServer.from("platform_settings").select("*").eq("id", "default").maybeSingle();
  if (error) throw error;
  return data;
}

function withdrawalWindow(settings: any) {
  const now = new Date();
  const wat = new Date(now.getTime() + 60 * 60 * 1000);
  const day = wat.getUTCDay();
  const hour = wat.getUTCHours();
  const openDay = Number(settings?.withdrawal_window_day_num ?? 6);
  const openHour = Number(settings?.withdrawal_opening_hour ?? 0);
  const closeHour = Number(settings?.withdrawal_closing_hour ?? 23);
  const isOpen = day === openDay && hour >= openHour && hour <= closeHour;
  let days = (openDay - day + 7) % 7;
  if (days === 0 && !isOpen) days = 7;
  const next = new Date(wat);
  next.setUTCDate(next.getUTCDate() + days);
  next.setUTCHours(openHour, 0, 0, 0);
  return {
    isOpen, currentDay: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"][day],
    currentHour: hour, secondsUntilNextWindow: Math.max(0, Math.floor((next.getTime() - wat.getTime()) / 1000)),
    nextWindowDateString: next.toISOString(),
    message: isOpen ? "Saturday Withdrawal Window is currently OPEN." : "Withdrawals are currently closed. The next window opens Saturday at 12:00 AM WAT.",
    scheduleDay: settings?.withdrawal_window_day || "Saturday", timezone: settings?.withdrawal_timezone || "WAT (UTC+1)",
  };
}

export async function authenticate(req: Request, res: Response, next: NextFunction) {
  if (!requireSupabase(res)) return;
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) return res.status(401).json({ error: "Authentication token required" });
  const token = header.slice(7).trim();
  try {
    const { data, error } = await supabaseServer!.auth.getUser(token);
    if (error || !data.user) return res.status(401).json({ error: "Invalid or expired session. Please log in again." });
    const row = await loadUserByAuthId(data.user.id);
    if (!row) return res.status(401).json({ error: "TRIZZ profile was not found for this authenticated account." });
    if (row.is_banned || row.account_status === "banned") return res.status(403).json({ error: "Account suspended." });
    if (row.is_active === false || row.account_status === "inactive") return res.status(403).json({ error: "Account has been deactivated." });
    (req as any).supabaseUser = data.user;
    (req as any).user = normalizeUser(row);
    next();
  } catch (e) {
    console.error("[auth]", e);
    res.status(401).json({ error: "Invalid or expired session." });
  }
}

export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    if (!supabaseServer) return next();
    const header = req.headers.authorization;
    if (header?.startsWith("Bearer ")) {
      const { data } = await supabaseServer.auth.getUser(header.slice(7).trim());
      if (data.user) {
        const row = await loadUserByAuthId(data.user.id);
        if (row && row.is_active !== false && !row.is_banned) (req as any).user = normalizeUser(row);
      }
    }
  } catch {}
  next();
}

apiRouter.get("/supabase/status", (_req, res) => {
  if (!requireSupabase(res)) return;
  res.json({ status: "ok", service: "TRIZZ Public Platform Backend", timestamp: new Date().toISOString() });
});

apiRouter.get("/health", (_req, res) => res.json({ status: "ok", service: "TRIZZ Public Platform Backend", time: new Date().toISOString() }));

apiRouter.get("/config", async (_req, res) => {
  if (!requireSupabase(res)) return;
  try {
    const settings = await liveSettings();
    if (!settings) return res.status(503).json({ error: "Platform settings are not configured." });
    const { data: plans } = await supabaseServer!.from("plans").select("*").eq("is_active", true).order("sort_order");
    const { data: channels } = await supabaseServer!.from("support_channels").select("*").eq("is_active", true).order("sort_order");
    const { data: announcements } = await supabaseServer!.from("announcements").select("*").eq("is_active", true);
    const windowStatus = withdrawalWindow(settings);
    res.json({
      brand: { name: "TRIZZ", tagline: "Move. Earn. Refer.", supportingTagline: "Transfer. Trade. Transact.", description: "A modern digital platform connecting users with earning opportunities, referral rewards, and eligible financial services through a simple and transparent experience." },
      rates: { depositReferenceRateNgnPerUsd: Number(settings.deposit_reference_rate_ngn_per_usd), withdrawalReferenceRateNgnPerUsd: Number(settings.withdrawal_reference_rate_ngn_per_usd), standardWithdrawalFeePercent: Number(settings.standard_withdrawal_fee_percent), autoWithdrawalFeePercent: Number(settings.auto_withdrawal_fee_percent) },
      withdrawalWindow: windowStatus,
      minimumWithdrawalsByTier: Object.fromEntries((plans || []).map((p:any) => [p.tier, Number(p.min_withdrawal_usd)])),
      cryptoDeposit: { enabled: Boolean(settings.crypto_deposit_enabled), asset: settings.crypto_deposit_asset, network: settings.crypto_deposit_network, address: settings.crypto_deposit_address || "", minimumDepositUsd: Number(settings.crypto_deposit_min_usd) },
      supportChannels: { email: channels?.find((c:any)=>c.channel_type === "email")?.handle || "", whatsapp: channels?.find((c:any)=>c.channel_type === "whatsapp")?.handle || "", telegram: channels?.find((c:any)=>c.channel_type === "telegram")?.handle || "", supportHours: channels?.[0]?.support_hours || "" },
      plans: (plans || []).map(mapPlan), announcements: announcements || [], maintenanceMode: Boolean(settings.maintenance_mode), complianceStatement: settings.compliance_statement || "",
    });
  } catch (e:any) { res.status(500).json({ error: "Unable to load platform configuration." }); }
});

function mapPlan(p:any) { return { id:p.id, tier:p.tier, name:p.name, priceUsd:Number(p.price_usd), priceNgn:Number(p.price_ngn), description:p.description, features:Array.isArray(p.features)?p.features:[], minWithdrawalUsd:Number(p.min_withdrawal_usd), minWithdrawalNgn:Number(p.min_withdrawal_ngn), dailyTaskCap:Number(p.daily_task_cap), referralBonusPercentage:Number(p.referral_bonus_percentage), popular:Boolean(p.popular) }; }

apiRouter.post("/auth/register", async (req, res) => {
  if (!requireSupabase(res)) return;
  const { fullName, username, email, phone, password, confirmPassword, referralCode, country, currencyPreference, termsAccepted } = req.body || {};
  if (!fullName || !username || !email || !phone || !password) return res.status(400).json({ error: "Please fill in all required registration fields." });
  if (password !== confirmPassword) return res.status(400).json({ error: "Passwords do not match." });
  if (String(password).length < 8) return res.status(400).json({ error: "Password must be at least 8 characters." });
  if (termsAccepted === false) return res.status(400).json({ error: "You must accept the Terms and Privacy Policy." });
  const cleanUsername = String(username).trim().toLowerCase().replace(/[^a-z0-9_]/g, "");
  const cleanEmail = String(email).trim().toLowerCase();
  const cleanPhone = String(phone).trim();
  const { data: duplicate } = await supabaseServer!.from("users").select("username,email,phone").or(`username.eq.${cleanUsername},email.eq.${cleanEmail},phone.eq.${cleanPhone}`).limit(1);
  if (duplicate?.length) return res.status(400).json({ error: duplicate[0].email === cleanEmail ? "An account with this email already exists." : duplicate[0].username === cleanUsername ? "Username is already registered." : "This phone number is already registered." });
  let referredBy: string | null = null;
  if (referralCode) { const { data: ref } = await supabaseServer!.from("users").select("id").eq("referral_code", String(referralCode).trim().toUpperCase()).maybeSingle(); referredBy = ref?.id || null; }
  const { data: auth, error: authErr } = await supabaseServer!.auth.admin.createUser({ email: cleanEmail, password, email_confirm: false, user_metadata: { fullName: String(fullName).trim(), username: cleanUsername, phone: cleanPhone, country: country || "Nigeria" } });
  if (authErr || !auth.user) return res.status(400).json({ error: authErr?.message || "Unable to create authentication account." });
  const referral = `TRZ-${cleanUsername.toUpperCase().slice(0,4)}${crypto.randomInt(1000,9999)}`;
  const { data: profile, error: profileErr } = await supabaseServer!.from("users").insert({ supabase_auth_id: auth.user.id, full_name: String(fullName).trim(), username: cleanUsername, email: cleanEmail, phone: cleanPhone, country: country || "Nigeria", currency_preference: currencyPreference === "NGN" ? "NGN" : "USD", referral_code: referral, referred_by: referredBy, role: "user", plan_tier: "FREE", verification_status: "not_verified" }).select().single();
  if (profileErr || !profile) { await supabaseServer!.auth.admin.deleteUser(auth.user.id); return res.status(500).json({ error: "Failed to create TRIZZ profile." }); }
  const { error: signErr } = await supabaseServer!.auth.signInWithPassword({ email: cleanEmail, password });
  if (signErr) return res.status(201).json({ message: "Account created. Please verify your email before signing in.", user: normalizeUser(profile), requiresEmailVerification: true });
  return res.status(201).json({ message: "ACCOUNT CREATED SUCCESSFULLY", user: normalizeUser(profile) });
});

apiRouter.post("/auth/login", async (req, res) => {
  if (!requireSupabase(res)) return;
  const { identifier, password } = req.body || {};
  if (!identifier || !password) return res.status(400).json({ error: "Please enter your login details." });
  const ident = String(identifier).trim().toLowerCase();
  const { data: rows } = await supabaseServer!.from("users").select("*").or(`email.eq.${ident},username.eq.${ident},phone.eq.${ident}`).limit(1);
  if (!rows?.length) return res.status(401).json({ error: "Invalid login credentials." });
  const profile = rows[0];
  const { data, error } = await supabaseServer!.auth.signInWithPassword({ email: profile.email, password });
  if (error || !data.user) return res.status(401).json({ error: "Invalid login credentials." });
  res.json({ user: normalizeUser(profile), session: data.session ? { access_token: data.session.access_token, refresh_token: data.session.refresh_token, expires_at: data.session.expires_at } : null });
});

apiRouter.post("/auth/oauth-profile", async (req,res) => {
  if (!requireSupabase(res)) return;
  const header = req.headers.authorization;
  if (!header?.startsWith("Bearer ")) return res.status(401).json({ error: "Authentication token required" });
  try {
    const { data: authData, error: authError } = await supabaseServer!.auth.getUser(header.slice(7).trim());
    const auth = authData?.user;
    if (authError || !auth) return res.status(401).json({ error: "Invalid or expired session. Please log in again." });
    const { data: existing, error: existingError } = await supabaseServer!.from("users").select("*").eq("supabase_auth_id", auth.id).maybeSingle();
    if (existingError) return res.status(500).json({ error: "Unable to load TRIZZ profile." });
    const metadata:any = auth.user_metadata || {}; const body:any = req.body || {};
    const base = String(body.username || metadata.user_name || metadata.username || metadata.name || auth.email?.split("@")[0] || "trizzuser").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0,20) || "trizzuser";
    if (!existing) {
      let username = base;
      for (let i=0;i<10;i++) { const {data:taken}=await supabaseServer!.from("users").select("id").eq("username",username).maybeSingle(); if(!taken) break; username=`${base.slice(0,Math.max(1,20-String(i+1).length))}${i+1}`; }
      let referredBy:any=null; const code=body.referralCode?String(body.referralCode).trim().toUpperCase():"";
      if(code){const {data:ref}=await supabaseServer!.from("users").select("id").eq("referral_code",code).maybeSingle(); referredBy=ref?.id||null;}
      const {data:profile,error:insertError}=await supabaseServer!.from("users").insert({supabase_auth_id:auth.id,full_name:String(body.fullName||metadata.fullName||metadata.name||auth.email?.split("@")[0]||"TRIZZ User").trim().slice(0,128),username,email:String(auth.email||"").toLowerCase(),phone:body.phone?String(body.phone).trim().slice(0,32):null,country:String(body.country||metadata.country||"Nigeria").slice(0,64),currency_preference:body.currencyPreference==="NGN"?"NGN":"USD",referral_code:`TRZ-${username.toUpperCase().slice(0,4)}${crypto.randomInt(1000,9999)}`,referred_by:referredBy}).select().single();
      if(insertError||!profile) return res.status(400).json({error:insertError?.message||"Unable to create TRIZZ profile."});
      const {error:walletError}=await supabaseServer!.from("wallets").insert({user_id:profile.id}); if(walletError&&walletError.code!=="23505") return res.status(500).json({error:"Profile created, but wallet initialization failed."});
      return res.status(201).json({user:normalizeUser(profile)});
    }
    const patch:any={}; if(body.fullName||metadata.fullName||metadata.name)patch.full_name=String(body.fullName||metadata.fullName||metadata.name).trim().slice(0,128); if(body.phone)patch.phone=String(body.phone).trim().slice(0,32); if(body.country)patch.country=String(body.country).slice(0,64); if(body.currencyPreference)patch.currency_preference=body.currencyPreference==="NGN"?"NGN":"USD";
    const {data:updated,error:updateError}=Object.keys(patch).length?await supabaseServer!.from("users").update(patch).eq("id",existing.id).select().single():{data:existing,error:null as any};
    if(updateError||!updated)return res.status(400).json({error:updateError?.message||"Unable to update TRIZZ profile."});
    const {data:wallet}=await supabaseServer!.from("wallets").select("user_id").eq("user_id",existing.id).maybeSingle(); if(!wallet)await supabaseServer!.from("wallets").insert({user_id:existing.id});
    return res.json({user:normalizeUser(updated)});
  } catch(e){ console.error("[oauth-profile]",e); return res.status(500).json({error:"Unable to initialize TRIZZ profile."}); }
});

apiRouter.get("/auth/me", authenticate, async (req,res)=>{ const u=(req as any).user; const {data:w}=await supabaseServer!.from("wallets").select("*").eq("user_id",u.id).maybeSingle(); const {data:k}=await supabaseServer!.from("kyc_verifications").select("*").eq("user_id",u.id).order("created_at",{ascending:false}).limit(1).maybeSingle(); res.json({user:u,wallet:w||null,verification:k||{status:u.verificationStatus||"not_verified"},twoFactorEnabled:false}); });
apiRouter.post("/auth/logout", authenticate, (_req,res)=>res.json({message:"Logged out successfully"}));

apiRouter.get("/wallet", authenticate, async (req,res)=>{
  const u=(req as any).user; const settings=await liveSettings(); const {data:w}=await supabaseServer!.from("wallets").select("*").eq("user_id",u.id).maybeSingle();
  if(!w)return res.status(404).json({error:"Wallet not found."}); const {data:tx}=await supabaseServer!.from("wallet_transactions").select("*").eq("user_id",u.id).order("created_at",{ascending:false}).limit(5); const {data:plan}=await supabaseServer!.from("plans").select("min_withdrawal_usd").eq("tier",u.planTier).maybeSingle();
  const dep=Number(settings?.deposit_reference_rate_ngn_per_usd||1500), wd=Number(settings?.withdrawal_reference_rate_ngn_per_usd||1200); res.json({availableBalanceUsd:Number(w.available_balance_usd),pendingBalanceUsd:Number(w.pending_balance_usd),totalEarnedUsd:Number(w.total_earned_usd),totalWithdrawnUsd:Number(w.total_withdrawn_usd),referralRewardsUsd:Number(w.referral_rewards_usd),availableBalanceNgn:Number(w.available_balance_usd)*wd,pendingBalanceNgn:Number(w.pending_balance_usd)*wd,totalEarnedNgn:Number(w.total_earned_usd)*dep,totalWithdrawnNgn:Number(w.total_withdrawn_usd)*wd,rates:{depositRate:dep,withdrawalRate:wd,withdrawalFeePercent:Number(settings?.standard_withdrawal_fee_percent||15)},userTier:u.planTier,minimumWithdrawalUsd:Number(plan?.min_withdrawal_usd||20),minimumWithdrawalNgn:Number(plan?.min_withdrawal_usd||20)*wd,withdrawalWindow:withdrawalWindow(settings),autoWithdrawal:{enabled:Boolean(w.auto_withdrawal_enabled),mode:w.auto_withdrawal_mode||"minimum",customAmount:Number(w.auto_withdrawal_custom_amount||50),feePercent:Number(settings?.auto_withdrawal_fee_percent||2.5)},cryptoDeposit:{enabled:Boolean(settings?.crypto_deposit_enabled),asset:settings?.crypto_deposit_asset||"USDT",network:settings?.crypto_deposit_network||"BEP-20 (BNB Smart Chain)",address:settings?.crypto_deposit_address||"",minimumDepositUsd:Number(settings?.crypto_deposit_min_usd||10)},recentTransactions:(tx||[]).map(mapTx)});
});

apiRouter.post("/wallet/deposit", authenticate, async(req,res)=>{ const u=(req as any).user; const settings=await liveSettings(); const amount=Number(req.body?.amountUsd); if(!Number.isFinite(amount)||amount<=0)return res.status(400).json({error:"Please provide a valid deposit amount."}); if(amount<Number(settings?.crypto_deposit_min_usd||10))return res.status(400).json({error:`Minimum deposit amount is $${Number(settings?.crypto_deposit_min_usd||10)}.`}); if(!settings?.crypto_deposit_enabled||!settings?.crypto_deposit_address)return res.status(503).json({error:"Crypto deposits are not currently configured by the platform."}); const reference=`DEP-${crypto.randomBytes(5).toString("hex").toUpperCase()}`; const {data:tx,error}=await supabaseServer!.from("wallet_transactions").insert({user_id:u.id,type:"deposit",amount_usd:amount,amount_ngn:amount*Number(settings.deposit_reference_rate_ngn_per_usd),conversion_rate:Number(settings.deposit_reference_rate_ngn_per_usd),fee_usd:0,net_amount_usd:amount,currency:"USDT",status:"pending",reference,description:`USDT (${req.body?.network||settings.crypto_deposit_network}) Deposit Request`,metadata:{asset:settings.crypto_deposit_asset,network:req.body?.network||settings.crypto_deposit_network,destinationAddress:settings.crypto_deposit_address}}).select().single(); if(error)return res.status(500).json({error:"Failed to initialize deposit request."}); res.json({transactionId:tx.id,reference,asset:settings.crypto_deposit_asset,network:req.body?.network||settings.crypto_deposit_network,depositAddress:settings.crypto_deposit_address,amountUsd:amount,amountNgn:amount*Number(settings.deposit_reference_rate_ngn_per_usd),minimumAmountUsd:Number(settings.crypto_deposit_min_usd),status:"pending",instructions:["Send the stated asset on the stated network to the configured deposit address.","Keep your transaction hash/TxID.","Submit the hash for verification; wallet credit occurs only after backend/provider verification."]}); });
apiRouter.post("/wallet/deposit/verify", authenticate, async(req,res)=>{ const u=(req as any).user; const {transactionId,transactionHash,paymentReference,notes}=req.body||{}; if(!transactionHash&&!paymentReference)return res.status(400).json({error:"Transaction hash or payment reference is required."}); let q=supabaseServer!.from("wallet_transactions").select("*").eq("user_id",u.id); if(transactionId)q=q.eq("id",transactionId); else if(paymentReference)q=q.eq("reference",paymentReference); const {data:tx}=await q.maybeSingle(); if(!tx)return res.status(404).json({error:"Deposit request not found. Create a deposit request first."}); if(tx.type!=="deposit")return res.status(400).json({error:"Invalid transaction type."}); const meta={...(tx.metadata||{}),transactionHash:transactionHash||null,notes:notes||null}; const {data:updated,error}=await supabaseServer!.from("wallet_transactions").update({status:"processing",transaction_hash:transactionHash||tx.transaction_hash,metadata:meta}).eq("id",tx.id).eq("user_id",u.id).select().single(); if(error)return res.status(500).json({error:"Unable to submit deposit for verification."}); res.json({message:"Deposit submitted for backend verification. No balance has been credited yet.",transaction:mapTx(updated)}); });

apiRouter.post("/wallet/withdraw", authenticate, async(req,res)=>{ const u=(req as any).user; const amount=Number(req.body?.amountUsd); const method=req.body?.withdrawalMethod||"bank_transfer"; const destination=req.body?.destinationDetails; if(!Number.isFinite(amount)||amount<=0)return res.status(400).json({error:"Please provide a valid withdrawal amount."}); if(!destination?.accountNumber)return res.status(400).json({error:"Withdrawal destination details are required."}); const settings=await liveSettings(); const win=withdrawalWindow(settings); if(!win.isOpen)return res.status(403).json({error:win.message,windowStatus:win}); const reference=`WD-${crypto.randomBytes(5).toString("hex").toUpperCase()}`; const {data,result,error}=await supabaseServer!.rpc("process_withdrawal_request",{p_user_id:u.id,p_amount_usd:amount,p_withdrawal_method:method,p_destination_details:destination,p_reference:reference}); if(error)return res.status(400).json({error:error.message}); res.json(result||data); });
apiRouter.post("/wallet/auto-withdraw", authenticate, async(req,res)=>{ const u=(req as any).user; const enabled=Boolean(req.body?.enabled); const mode=req.body?.mode==="custom"?"custom":"minimum"; const custom=Math.max(1,Number(req.body?.customAmount||50)); const {error}=await supabaseServer!.from("wallets").update({auto_withdrawal_enabled:enabled,auto_withdrawal_mode:mode,auto_withdrawal_custom_amount:custom}).eq("user_id",u.id); if(error)return res.status(500).json({error:"Failed to update auto-withdrawal settings."}); const settings=await liveSettings(); res.json({message:`Auto-withdrawal has been ${enabled?"activated":"deactivated"}.`,autoWithdrawal:{enabled,mode,customAmount:custom,feePercent:Number(settings?.auto_withdrawal_fee_percent||2.5)}}); });

apiRouter.get("/tasks", optionalAuth, async(req,res)=>{ const {data}=await supabaseServer!.from("tasks").select("*").eq("is_active",true).order("created_at",{ascending:false}); const u=(req as any).user; let subs:any[]=[]; if(u){const r=await supabaseServer!.from("task_submissions").select("*").eq("user_id",u.id); subs=r.data||[];} const tasks=(data||[]).map((t:any)=>{const s=subs.find(x=>x.task_id===t.id);return {id:t.id,title:t.title,description:t.description,category:t.category,rewardUsd:Number(t.reward_usd),rewardNgn:Number(t.reward_ngn||0),estimatedMinutes:Number(t.estimated_minutes||0),status:s?.status||"available",userStatus:s?.status||"available",requirements:Array.isArray(t.requirements)?t.requirements:Object.values(t.requirements||{}),instructions:t.instructions||"Follow the task instructions.",deadlineDays:Number(t.deadline_days||1),planRequirement:t.plan_requirement,submission:s?{id:s.id,status:s.status,proofText:s.proof_data?.proofText,proofUrl:s.proof_data?.proofUrl,submittedAt:s.submitted_at}:undefined};}); res.json({tasks,categories:[...new Set(tasks.map((x:any)=>x.category).filter(Boolean))],userTier:u?.planTier||"FREE"}); });
apiRouter.post("/tasks/:id/start", authenticate, async(req,res)=>{ const u=(req as any).user; const {data:task}=await supabaseServer!.from("tasks").select("*").eq("id",req.params.id).eq("is_active",true).maybeSingle(); if(!task)return res.status(404).json({error:"Task not found."}); const {data:existing}=await supabaseServer!.from("task_submissions").select("*").eq("task_id",task.id).eq("user_id",u.id).in("status",["in_progress","submitted","under_review","approved","completed"]).maybeSingle(); if(existing)return res.json({submission:existing}); const {data:sub,error}=await supabaseServer!.from("task_submissions").insert({task_id:task.id,user_id:u.id,status:"in_progress",proof_data:{}}).select().single(); if(error)return res.status(400).json({error:error.message}); res.json({submission:sub}); });
apiRouter.post("/tasks/:id/submit", authenticate, async(req,res)=>{ const u=(req as any).user; const {data:sub}=await supabaseServer!.from("task_submissions").select("*").eq("task_id",req.params.id).eq("user_id",u.id).eq("status","in_progress").maybeSingle(); if(!sub)return res.status(404).json({error:"No active task submission found."}); const proofData={...(sub.proof_data||{}),proofText:req.body?.proofText||"",proofUrl:req.body?.proofUrl||""}; const {data:updated,error}=await supabaseServer!.from("task_submissions").update({proof_data:proofData,status:"submitted",submitted_at:new Date().toISOString()}).eq("id",sub.id).select().single(); if(error)return res.status(400).json({error:error.message}); res.json({message:"Task submitted for review.",submission:updated}); });

apiRouter.get("/referrals", authenticate, async(req,res)=>{ const u=(req as any).user; const {data:refs}=await supabaseServer!.from("users").select("id,username,created_at,is_active").eq("referred_by",u.id); const {data:rewards}=await supabaseServer!.from("referral_rewards").select("*").eq("referrer_user_id",u.id).order("created_at",{ascending:false}); const settings=await liveSettings(); const rate=Number(settings?.deposit_reference_rate_ngn_per_usd||1500); const rr=referralCode=>`${windowOrigin(req)}/#signup?ref=${encodeURIComponent(referralCode)}`; res.json({referralCode:u.referralCode,referralLink:rr(u.referralCode),totalReferrals:refs?.length||0,activeReferrals:(refs||[]).filter((x:any)=>x.is_active).length,pendingRewardsUsd:(rewards||[]).filter((x:any)=>x.status==="pending").reduce((a:any,x:any)=>a+Number(x.reward_usd),0),pendingRewardsNgn:(rewards||[]).filter((x:any)=>x.status==="pending").reduce((a:any,x:any)=>a+Number(x.reward_usd)*rate,0),approvedRewardsUsd:(rewards||[]).filter((x:any)=>["approved","paid"].includes(x.status)).reduce((a:any,x:any)=>a+Number(x.reward_usd),0),approvedRewardsNgn:(rewards||[]).filter((x:any)=>["approved","paid"].includes(x.status)).reduce((a:any,x:any)=>a+Number(x.reward_usd)*rate,0),tierCommissionRate:"Configured by platform",history:(rewards||[]).map((x:any)=>({id:x.id,referredUsername:x.referred_user_id,qualifyingAction:x.qualifying_action||"Referral reward",rewardUsd:Number(x.reward_usd),rewardNgn:Number(x.reward_ngn||Number(x.reward_usd)*rate),status:x.status,createdAt:x.created_at}))}); });
function windowOrigin(req:Request){return `${req.protocol}://${req.get("host")}`;}

apiRouter.get("/plans", async(_req,res)=>{ const {data}=await supabaseServer!.from("plans").select("*").eq("is_active",true).order("sort_order"); const settings=await liveSettings(); res.json({plans:(data||[]).map(mapPlan),referenceConversion:`1 USD = ₦${Number(settings?.deposit_reference_rate_ngn_per_usd||1500)}`}); });
apiRouter.post("/plans/subscribe", authenticate, async(req,res)=>{ const u=(req as any).user; const tier=String(req.body?.planTier||""); if(!tier)return res.status(400).json({error:"Please specify a target plan tier."}); const reference=`PLN-${crypto.randomBytes(5).toString("hex").toUpperCase()}`; const {data,result,error}=await supabaseServer!.rpc("process_plan_upgrade",{p_user_id:u.id,p_target_tier:tier,p_reference:reference}); if(error)return res.status(400).json({error:error.message}); res.json(result||data); });

apiRouter.get("/verification", authenticate, async(req,res)=>{ const u=(req as any).user; const {data}=await supabaseServer!.from("kyc_verifications").select("*").eq("user_id",u.id).order("created_at",{ascending:false}).limit(1).maybeSingle(); res.json(data||{status:u.verificationStatus||"not_verified",hasSubmitted:false}); });
apiRouter.post("/verification/submit", authenticate, async(req,res)=>{ const u=(req as any).user; const {documentType,documentNumber,fullNameOnDocument,documentFrontName}=req.body||{}; if(!documentType||!documentNumber||!fullNameOnDocument)return res.status(400).json({error:"All verification fields are required."}); const {data,error}=await supabaseServer!.from("kyc_verifications").insert({user_id:u.id,status:"pending",document_type:documentType,document_number:documentNumber,full_name_on_document:fullNameOnDocument,document_front_name:documentFrontName||null}).select().single(); if(error)return res.status(400).json({error:error.message}); await supabaseServer!.from("users").update({verification_status:"pending"}).eq("id",u.id); res.status(201).json({message:"Verification submitted for review.",verification:data}); });

function mapTx(t:any){return {id:t.id,userId:t.user_id,type:t.type,amountUsd:Number(t.amount_usd),amountNgn:Number(t.amount_ngn||0),conversionRate:Number(t.conversion_rate||0),feeUsd:Number(t.fee_usd||0),netAmountUsd:Number(t.net_amount_usd||t.amount_usd),currency:t.currency,status:t.status,reference:t.reference,description:t.description||"",createdAt:t.created_at,metadata:t.metadata||{}};}
apiRouter.get("/transactions", authenticate, async(req,res)=>{ const u=(req as any).user; let q=supabaseServer!.from("wallet_transactions").select("*",{count:"exact"}).eq("user_id",u.id).order("created_at",{ascending:false}); if(req.query.type)q=q.eq("type",String(req.query.type)); if(req.query.status)q=q.eq("status",String(req.query.status)); if(req.query.search)q=q.ilike("description",`%${String(req.query.search)}%`); const {data,count,error}=await q; if(error)return res.status(500).json({error:"Unable to load transactions."}); res.json({transactions:(data||[]).map(mapTx),totalCount:count||0}); });

apiRouter.get("/blog", async(req,res)=>{ let q=supabaseServer!.from("blog_posts").select("*").eq("status","published").order("published_at",{ascending:false}); if(req.query.search)q=q.or(`title.ilike.%${String(req.query.search)}%,excerpt.ilike.%${String(req.query.search)}%`); const {data}=await q; const categories=["All",...[...new Set((data||[]).map((p:any)=>p.category).filter(Boolean))]]; res.json({posts:(data||[]).map(mapBlog),categories}); });
apiRouter.get("/blog/:slug", async(req,res)=>{ const {data}=await supabaseServer!.from("blog_posts").select("*").eq("slug",req.params.slug).eq("status","published").maybeSingle(); if(!data)return res.status(404).json({error:"Post not found."}); res.json({post:mapBlog(data)}); });
function mapBlog(p:any){return {id:p.id,slug:p.slug,title:p.title,summary:p.excerpt||"",content:p.content,category:p.category||"TRIZZ News",author:{name:"TRIZZ",role:"Platform"},publishedAt:p.published_at,readingTimeMinutes:Math.max(1,Math.ceil(String(p.content||"").split(/\s+/).length/200)),tags:[],featuredImageUrl:p.cover_image_url};}

apiRouter.get("/support/info", async(_req,res)=>{ const {data}=await supabaseServer!.from("support_channels").select("*").eq("is_active",true).order("sort_order"); res.json({channels:data||[]}); });
apiRouter.post("/support/ticket", optionalAuth, async(req,res)=>{ const u=(req as any).user; if(!u)return res.status(401).json({error:"Please sign in to create a support ticket."}); const {subject,message}=req.body||{}; if(!subject||!message)return res.status(400).json({error:"Subject and message are required."}); const {data,error}=await supabaseServer!.from("support_tickets").insert({user_id:u.id,name:u.fullName||"TRIZZ User",email:u.email,subject:String(subject).slice(0,200),message:String(message).slice(0,10000),category:String(req.body?.category||"general").slice(0,32)}).select().single(); if(error)return res.status(400).json({error:error.message}); res.status(201).json({message:"Support ticket created.",ticket:data}); });

apiRouter.get("/notifications", authenticate, async(req,res)=>{ const u=(req as any).user; const {data}=await supabaseServer!.from("notifications").select("*").eq("user_id",u.id).order("created_at",{ascending:false}).limit(100); const ns=(data||[]).map((n:any)=>({id:n.id,userId:n.user_id,title:n.title,message:n.message,type:n.type,read:n.read,link:n.link,createdAt:n.created_at})); res.json({notifications:ns,unreadCount:ns.filter((n:any)=>!n.read).length}); });
apiRouter.post("/notifications/:id/read", authenticate, async(req,res)=>{ const u=(req as any).user; const {error}=await supabaseServer!.from("notifications").update({read:true}).eq("id",req.params.id).eq("user_id",u.id); if(error)return res.status(400).json({error:error.message}); res.json({success:true}); });
apiRouter.post("/notifications/read-all", authenticate, async(req,res)=>{ const u=(req as any).user; const {error}=await supabaseServer!.from("notifications").update({read:true}).eq("user_id",u.id); if(error)return res.status(400).json({error:error.message}); res.json({success:true}); });

apiRouter.get("/legal", async(_req,res)=>{ const {data}=await supabaseServer!.from("legal_documents").select("*").eq("is_current",true); res.json({documents:data||[]}); });
apiRouter.get("/legal/:slug", async(req,res)=>{ const {data}=await supabaseServer!.from("legal_documents").select("*").eq("document_type",req.params.slug).eq("is_current",true).maybeSingle(); if(!data)return res.status(404).json({error:"Legal document not found."}); res.json({document:data}); });
apiRouter.get("/announcements", async(_req,res)=>{ const {data}=await supabaseServer!.from("announcements").select("*").eq("is_active",true); res.json({announcements:data||[]}); });
apiRouter.get("/support-channels", async(_req,res)=>{ const {data}=await supabaseServer!.from("support_channels").select("*").eq("is_active",true).order("sort_order"); res.json({channels:data||[]}); });
apiRouter.get("/wallet/ledger", authenticate, async(req,res)=>{ const u=(req as any).user; const {data}=await supabaseServer!.from("wallet_ledger").select("*").eq("user_id",u.id).order("created_at",{ascending:false}).limit(200); res.json({entries:data||[]}); });
