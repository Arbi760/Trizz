import { createClient, SupabaseClient } from "@supabase/supabase-js";

/**
 * TRIZZ SERVER-SIDE SUPABASE SERVICE
 *
 * CRITICAL ARCHITECTURAL DIRECTIVE:
 * - This module executes EXCLUSIVELY on the secure Node.js backend.
 * - It uses SUPABASE_SERVICE_ROLE_KEY to perform privileged operations that must NEVER
 *   be entrusted to the client browser (e.g. ledger balancing, audit logging, admin sync).
 * - SUPABASE_SERVICE_ROLE_KEY is strictly never returned in any API response or sent to the browser.
 */

const supabaseUrl = process.env.VITE_SUPABASE_URL || "";
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  serviceRoleKey &&
  !supabaseUrl.includes("YOUR_PROJECT_REF")
);

export let supabaseServer: SupabaseClient | null = null;

if (isSupabaseConfigured) {
  try {
    supabaseServer = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
    console.log("[Supabase Server] Initialized with Service Role credentials for:", supabaseUrl);
  } catch (err) {
    console.error("[Supabase Server] Failed to initialize Supabase client:", err);
    supabaseServer = null;
  }
} else {
  console.warn(
    "[Supabase Server] Supabase environment variables not fully configured. The server will refuse database-dependent operations until Supabase is configured."
  );
}

// Cache of table existence with 15s TTL so newly created tables are picked up quickly
const tableStatusCache: Record<string, { exists: boolean; expiresAt: number }> = {};

/**
 * Checks whether a table exists and is accessible in Supabase
 */
export async function checkTableExists(tableName: string, forceCheck = false): Promise<boolean> {
  if (!supabaseServer) return false;
  const cached = tableStatusCache[tableName];
  if (!forceCheck && cached && cached.expiresAt > Date.now()) {
    return cached.exists;
  }

  try {
    const { error } = await supabaseServer.from(tableName).select("*").limit(1);
    if (error && (error.code === "PGRST205" || error.code === "42P01")) {
      tableStatusCache[tableName] = { exists: false, expiresAt: Date.now() + 15000 };
      return false;
    }
    tableStatusCache[tableName] = { exists: true, expiresAt: Date.now() + 60000 };
    return true;
  } catch {
    tableStatusCache[tableName] = { exists: false, expiresAt: Date.now() + 15000 };
    return false;
  }
}

/**
 * Sends a structured, fail-safe error response when a required Supabase table is not yet initialized.
 * Strictly prevents silent in-memory fallback for persistent financial and user data.
 */
export function sendSchemaNotReadyResponse(res: any, tableName: string) {
  return res.status(503).json({
    success: false,
    error: `Persistent database table '${tableName}' is not yet initialized in Supabase PostgreSQL. Please execute /supabase/schema.sql in the Supabase SQL Editor to initialize the database.`,
    code: "SCHEMA_NOT_DEPLOYED",
    table: tableName,
    requiresSetup: true,
  });
}

/**
 * Full diagnostics of Supabase connection status across all required tables
 */
export async function getSupabaseDiagnostics() {
  if (!isSupabaseConfigured || !supabaseServer) {
    return {
      connected: false,
      url: supabaseUrl ? `${supabaseUrl.substring(0, 15)}...` : "Missing",
      hasServiceRoleKey: Boolean(serviceRoleKey),
      message: "Supabase credentials not configured in environment.",
      tables: {},
    };
  }

  const requiredTables = [
    "platform_settings",
    "support_channels",
    "announcements",
    "plans",
    "users",
    "kyc_verifications",
    "wallets",
    "wallet_ledger",
    "wallet_transactions",
    "user_plan_subscriptions",
    "tasks",
    "task_submissions",
    "referral_rewards",
    "blog_posts",
    "legal_documents",
    "support_tickets",
    "notifications",
    "audit_logs",
  ];

  const tableResults: Record<string, { exists: boolean; rowCount?: number; error?: string }> = {};

  for (const table of requiredTables) {
    try {
      const { data, error } = await supabaseServer
        .from(table)
        .select("*")
        .limit(1);

      if (error) {
        tableResults[table] = {
          exists: false,
          error: error.message || "Table not found in schema cache",
        };
      } else {
        tableResults[table] = {
          exists: true,
          rowCount: data?.length || 0,
        };
      }
    } catch (err: any) {
      tableResults[table] = { exists: false, error: err?.message || "Check failed" };
    }
  }

  let authConnected = false;
  try {
    const { error } = await supabaseServer.auth.admin.listUsers({ page: 1, perPage: 1 });
    authConnected = !error;
  } catch {
    authConnected = false;
  }

  const existingCount = Object.values(tableResults).filter((t) => t.exists).length;

  return {
    connected: true,
    authConnected,
    url: supabaseUrl,
    hasServiceRoleKey: true,
    allTablesReady: existingCount === requiredTables.length,
    existingTablesCount: existingCount,
    totalRequiredTables: requiredTables.length,
    tables: tableResults,
  };
}
