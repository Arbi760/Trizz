import React, { useState, useEffect } from "react";
import { PageRoute, UserSession, WalletData, PlatformNotification } from "./types.ts";
import { api } from "./services/api.ts";
import { supabase } from "./lib/supabaseClient.ts";
import { PublicNavbar } from "./components/PublicNavbar.tsx";
import { AuthNavbar } from "./components/AuthNavbar.tsx";
import { MobileBottomNav } from "./components/MobileBottomNav.tsx";
import { Footer } from "./components/Footer.tsx";
import { NotificationCenter } from "./components/NotificationCenter.tsx";

// Views
import { HomeView } from "./views/HomeView.tsx";
import { AboutView } from "./views/AboutView.tsx";
import { HowItWorksView } from "./views/HowItWorksView.tsx";
import { EarnView } from "./views/EarnView.tsx";
import { ReferralView } from "./views/ReferralView.tsx";
import { PlansView } from "./views/PlansView.tsx";
import { FinancialServicesView } from "./views/FinancialServicesView.tsx";
import { WalletView } from "./views/WalletView.tsx";
import { WithdrawView } from "./views/WithdrawView.tsx";
import { TransactionsView } from "./views/TransactionsView.tsx";
import { BlogView } from "./views/BlogView.tsx";
import { BlogDetailView } from "./views/BlogDetailView.tsx";
import { SupportView } from "./views/SupportView.tsx";
import { FaqView } from "./views/FaqView.tsx";
import { SecurityView } from "./views/SecurityView.tsx";
import { LegalViews } from "./views/LegalViews.tsx";
import { AuthViews } from "./views/AuthViews.tsx";
import { VerificationView } from "./views/VerificationView.tsx";
import { DashboardView } from "./views/DashboardView.tsx";
import { ErrorView } from "./views/ErrorView.tsx";

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<PageRoute>("home");
  const [selectedBlogSlug, setSelectedBlogSlug] = useState<string>("saturday-settlement-windows-explained");
  const [user, setUser] = useState<UserSession | null>(null);
  const [wallet, setWallet] = useState<WalletData | null>(null);
  const [notifications, setNotifications] = useState<PlatformNotification[]>([]);
  const [unreadNotifsCount, setUnreadNotifsCount] = useState<number>(0);
  const [isNotifCenterOpen, setIsNotifCenterOpen] = useState<boolean>(false);
  const [loadingSession, setLoadingSession] = useState<boolean>(true);

  // Sync state with URL hash for browser back/forward and bookmarking
  useEffect(() => {
    const handleHashChange = () => {
      const hash = decodeURIComponent(window.location.hash.replace(/^#/, "")).trim() as PageRoute;
      if (hash) {
        if (hash.startsWith("blog-post/")) {
          const slug = hash.replace("blog-post/", "");
          setSelectedBlogSlug(slug);
          setCurrentRoute("blog-detail");
        } else {
          setCurrentRoute(hash);
        }
      }
    };

    if (window.location.hash) {
      handleHashChange();
    }

    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // Fetch active session and wallet data
  const refreshUserSession = async () => {
    if (!supabase) {
      setUser(null);
      setWallet(null);
      setLoadingSession(false);
      return;
    }
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) {
      setUser(null);
      setWallet(null);
      setLoadingSession(false);
      return;
    }

    try {
      let meRes: any;
      try {
        meRes = await api.getMe();
      } catch (firstErr: any) {
        const metadata = session.user.user_metadata || {};
        if (firstErr?.status === 401 && session.user.app_metadata?.provider === "google") {
          const base = String(metadata.user_name || metadata.name || session.user.email?.split("@")[0] || "trizzuser").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 20) || "trizzuser";
          const profileRes = await api.ensureOAuthProfile({ fullName: metadata.fullName || metadata.name || session.user.email?.split("@")[0], username: base, country: "Nigeria", currencyPreference: "USD" });
          meRes = await api.getMe();
        } else {
          throw firstErr;
        }
      }
      setUser(meRes.user);

      // Also fetch wallet data
      const walletRes = await api.getWallet();
      setWallet(walletRes);

      // Fetch notifications
      const notifRes = await api.getNotifications();
      setNotifications(notifRes?.notifications || []);
      setUnreadNotifsCount(notifRes?.unreadCount || 0);
    } catch (err) {
      console.warn("Session expired or invalid, resetting token:", err);
      await supabase.auth.signOut();
      setUser(null);
      setWallet(null);
    } finally {
      setLoadingSession(false);
    }
  };

  useEffect(() => {
    refreshUserSession();
    if (!supabase) return;
    const { data: listener } = supabase.auth.onAuthStateChange(() => {
      refreshUserSession();
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  const handleNavigate = (route: PageRoute, blogSlug?: string) => {
    if (route === "blog-detail" && blogSlug) {
      setSelectedBlogSlug(blogSlug);
      window.location.hash = `blog-post/${blogSlug}`;
    } else {
      window.location.hash = route;
    }
    setCurrentRoute(route);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLogout = async () => {
    if (supabase) await supabase.auth.signOut();
    setUser(null);
    setWallet(null);
    handleNavigate("home");
  };

  const handleMarkNotificationRead = async (id: string) => {
    try {
      await api.markNotificationRead(id);
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
      );
      setUnreadNotifsCount((prev) => Math.max(0, prev - 1));
    } catch (err) {
      console.error(err);
    }
  };

  const handleClearNotifications = () => {
    setNotifications([]);
    setUnreadNotifsCount(0);
  };

  return (
    <div className="min-h-screen bg-[#07080b] text-[#f1f5f9] flex flex-col justify-between selection:bg-[#00e575]/20 selection:text-[#00e575]">
      {/* Top Navigation */}
      {user ? (
        <AuthNavbar
          user={user}
          wallet={wallet}
          currentRoute={currentRoute}
          onNavigate={handleNavigate}
          onLogout={handleLogout}
          unreadNotifications={unreadNotifsCount}
          onOpenNotifications={() => setIsNotifCenterOpen(!isNotifCenterOpen)}
        />
      ) : (
        <PublicNavbar currentRoute={currentRoute} onNavigate={handleNavigate} />
      )}

      {/* Main View Router */}
      <main className="flex-grow pt-16 sm:pt-20 pb-16 md:pb-0">
        {currentRoute === "home" && (
          <HomeView user={user} onNavigate={handleNavigate} />
        )}

        {currentRoute === "about" && (
          <AboutView onNavigate={handleNavigate} />
        )}

        {currentRoute === "how-it-works" && (
          <HowItWorksView onNavigate={handleNavigate} />
        )}

        {currentRoute === "earn" && (
          <EarnView
            user={user}
            onRefreshWallet={refreshUserSession}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "referral" && (
          <ReferralView user={user} onNavigate={handleNavigate} />
        )}

        {currentRoute === "plans" && (
          <PlansView
            user={user}
            onRefreshUser={refreshUserSession}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "services" && (
          <FinancialServicesView onNavigate={handleNavigate} />
        )}

        {currentRoute === "wallet" && (
          <WalletView
            user={user}
            wallet={wallet}
            onRefresh={refreshUserSession}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "withdraw" && (
          <WithdrawView
            user={user}
            wallet={wallet}
            onRefresh={refreshUserSession}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "transactions" && (
          <TransactionsView user={user} onNavigate={handleNavigate} />
        )}

        {currentRoute === "blog" && (
          <BlogView
            onSelectPost={(slug) => handleNavigate("blog-detail", slug)}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "blog-detail" && (
          <BlogDetailView
            slug={selectedBlogSlug}
            onBack={() => handleNavigate("blog")}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "support" && (
          <SupportView user={user} onNavigate={handleNavigate} />
        )}

        {currentRoute === "faq" && (
          <FaqView onNavigate={handleNavigate} />
        )}

        {currentRoute === "security" && (
          <SecurityView onNavigate={handleNavigate} />
        )}

        {currentRoute === "terms" && (
          <LegalViews initialTab="terms" onNavigate={handleNavigate} />
        )}

        {currentRoute === "privacy" && (
          <LegalViews initialTab="privacy" onNavigate={handleNavigate} />
        )}

        {currentRoute === "risk-disclosure" && (
          <LegalViews initialTab="risk-disclosure" onNavigate={handleNavigate} />
        )}

        {currentRoute === "login" && (
          <AuthViews
            mode="login"
            onSuccess={(u) => {
              setUser(u);
              refreshUserSession();
            }}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "signup" && (
          <AuthViews
            mode="signup"
            onSuccess={(u) => {
              setUser(u);
              refreshUserSession();
            }}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "verification" && (
          <VerificationView
            user={user}
            onRefreshUser={refreshUserSession}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "dashboard" && user && (
          <DashboardView
            user={user}
            wallet={wallet}
            onNavigate={handleNavigate}
          />
        )}

        {currentRoute === "dashboard" && !user && (
          <AuthViews
            mode="login"
            onSuccess={(u) => {
              setUser(u);
              refreshUserSession();
            }}
            onNavigate={handleNavigate}
          />
        )}

        {!(["home","about","how-it-works","earn","referral","plans","services","wallet","withdraw","transactions","blog","blog-detail","support","faq","security","terms","privacy","risk-disclosure","login","signup","verification","dashboard","404","maintenance"] as string[]).includes(currentRoute as string) && (
          <ErrorView type="404" onNavigate={handleNavigate} />
        )}

        {currentRoute === "404" && (
          <ErrorView type="404" onNavigate={handleNavigate} />
        )}

        {currentRoute === "maintenance" && (
          <ErrorView type="maintenance" onNavigate={handleNavigate} />
        )}
      </main>

      {/* Slide-out Notification Drawer */}
      <NotificationCenter
        isOpen={isNotifCenterOpen}
        onClose={() => setIsNotifCenterOpen(false)}
        notifications={notifications}
        onMarkAsRead={handleMarkNotificationRead}
        onClearAll={handleClearNotifications}
        onNavigate={handleNavigate}
      />

      {/* Mobile Bottom Quick Bar for Authenticated Users */}
      {user && (
        <MobileBottomNav
          currentRoute={currentRoute}
          onNavigate={handleNavigate}
          unreadNotifications={unreadNotifsCount}
          onOpenNotifications={() => setIsNotifCenterOpen(!isNotifCenterOpen)}
        />
      )}

      {/* Global Footer (Visible everywhere except login/signup cards) */}
      {currentRoute !== "login" && currentRoute !== "signup" && (
        <Footer onNavigate={handleNavigate} />
      )}
    </div>
  );
}
