import React, { useState } from "react";
import { TRIZZLogo } from "./TRIZZLogo.tsx";
import { PageRoute, UserSession, WalletData } from "../types.ts";
import {
  Bell,
  LogOut,
  ShieldCheck,
  Clock,
  AlertCircle,
  Menu,
  X,
  Wallet as WalletIcon,
  Layers,
  Share2,
  ListTodo,
  History,
  ArrowDownToLine,
  LifeBuoy,
  LayoutDashboard,
} from "lucide-react";

interface AuthNavbarProps {
  user: UserSession;
  wallet: WalletData | null;
  unreadNotifications: number;
  currentRoute: PageRoute;
  onNavigate: (route: PageRoute) => void;
  onOpenNotifications: () => void;
  onLogout: () => void;
}

export const AuthNavbar: React.FC<AuthNavbarProps> = ({
  user,
  wallet,
  unreadNotifications,
  currentRoute,
  onNavigate,
  onOpenNotifications,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; route: PageRoute; icon: React.ReactNode }[] = [
    { label: "Dashboard", route: "dashboard", icon: <LayoutDashboard className="w-4 h-4" /> },
    { label: "Earn", route: "earn", icon: <ListTodo className="w-4 h-4" /> },
    { label: "Refer", route: "referral", icon: <Share2 className="w-4 h-4" /> },
    { label: "Plans", route: "plans", icon: <Layers className="w-4 h-4" /> },
    { label: "Wallet", route: "wallet", icon: <WalletIcon className="w-4 h-4" /> },
    { label: "Withdraw", route: "withdraw", icon: <ArrowDownToLine className="w-4 h-4" /> },
    { label: "Transactions", route: "transactions", icon: <History className="w-4 h-4" /> },
    { label: "Support", route: "support", icon: <LifeBuoy className="w-4 h-4" /> },
  ];

  const getStatusBadge = () => {
    switch (user.verificationStatus) {
      case "verified":
        return (
          <button
            onClick={() => onNavigate("verification")}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] text-xs font-bold tracking-wide uppercase hover:bg-[#00e575]/20 cursor-pointer transition-colors"
            title="Identity Verified"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#00e575]" />
            <span>VERIFIED</span>
          </button>
        );
      case "pending":
        return (
          <button
            onClick={() => onNavigate("verification")}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold tracking-wide uppercase hover:bg-amber-500/20 cursor-pointer transition-colors"
            title="Verification In Review"
          >
            <Clock className="w-3.5 h-3.5" />
            <span>PENDING</span>
          </button>
        );
      default:
        return (
          <button
            onClick={() => onNavigate("verification")}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold tracking-wide uppercase hover:bg-rose-500/20 cursor-pointer transition-colors"
            title="Action Required"
          >
            <AlertCircle className="w-3.5 h-3.5" />
            <span>UNVERIFIED</span>
          </button>
        );
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#07080b]/95 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo & Status */}
        <div className="flex items-center gap-4 sm:gap-6">
          <TRIZZLogo
            size="md"
            showTagline={false}
            onClick={() => onNavigate("dashboard")}
          />
          <div className="hidden sm:flex items-center gap-2">
            {getStatusBadge()}
            <span className="px-2.5 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-slate-300 text-xs font-mono font-bold">
              {user.planTier}
            </span>
          </div>
        </div>

        {/* Desktop Nav Links */}
        <nav className="hidden xl:flex items-center gap-1">
          {navLinks.map((link) => {
            const isActive = currentRoute === link.route;
            return (
              <button
                key={link.route}
                id={`auth-nav-${link.route}`}
                onClick={() => onNavigate(link.route)}
                className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                  isActive
                    ? "text-[#00e575] bg-[#00e575]/10 font-semibold"
                    : "text-slate-300 hover:text-white hover:bg-slate-800/60"
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right side: Balance, Notifications & User Info */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Live Balance Card */}
          <div
            onClick={() => onNavigate("wallet")}
            className="hidden md:flex flex-col items-end px-3 py-1.5 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 cursor-pointer transition-colors"
          >
            <span className="text-[10px] uppercase tracking-wider text-slate-400 font-medium">Available</span>
            <span className="text-sm font-extrabold text-[#00e575] font-mono">
              ${(wallet?.availableBalanceUsd ?? 0).toFixed(2)}
            </span>
          </div>

          {/* Notifications Button */}
          <button
            id="btn-notifications-bell"
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors cursor-pointer"
            aria-label="Notifications"
          >
            <Bell className="w-5 h-5" />
            {unreadNotifications > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-[#00e575] text-[#07080b] text-[10px] font-extrabold flex items-center justify-center animate-pulse">
                {unreadNotifications}
              </span>
            )}
          </button>

          {/* User Menu / Logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="hidden lg:flex flex-col items-start leading-none">
              <span className="text-xs font-bold text-white max-w-[110px] truncate">{user.fullName}</span>
              <span className="text-[10px] text-slate-400 font-mono">@{user.username}</span>
            </div>
            <button
              id="btn-logout"
              onClick={onLogout}
              className="p-2 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-b border-slate-800 bg-[#090b10] px-4 pt-3 pb-6 space-y-1">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-2">
            <div>
              <p className="text-sm font-bold text-white">{user.fullName}</p>
              <p className="text-xs text-slate-400">@{user.username}</p>
            </div>
            <div className="flex items-center gap-2">
              {getStatusBadge()}
              <span className="px-2 py-0.5 rounded bg-slate-800 text-xs font-mono text-slate-300">{user.planTier}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pb-3">
            {navLinks.map((link) => (
              <button
                key={link.route}
                onClick={() => {
                  onNavigate(link.route);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium cursor-pointer ${
                  currentRoute === link.route
                    ? "bg-[#00e575]/15 text-[#00e575] font-semibold"
                    : "text-slate-300 hover:bg-slate-800"
                }`}
              >
                {link.icon}
                <span>{link.label}</span>
              </button>
            ))}
          </div>

          <button
            onClick={() => {
              onLogout();
              setMobileMenuOpen(false);
            }}
            className="w-full py-2 rounded-lg border border-rose-500/30 text-rose-400 text-xs font-bold hover:bg-rose-500/10 flex items-center justify-center gap-2"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      )}
    </header>
  );
};
