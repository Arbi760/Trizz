import React from "react";
import { TRIZZLogo } from "./TRIZZLogo.tsx";
import { PageRoute } from "../types.ts";
import { ShieldCheck, Lock, ExternalLink, HelpCircle, FileText } from "lucide-react";

interface FooterProps {
  onNavigate: (route: PageRoute) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#050608] border-t border-slate-900 pt-16 pb-24 md:pb-12 text-slate-400 text-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800/80">
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <TRIZZLogo size="md" showTagline={true} onClick={() => onNavigate("home")} />
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed max-w-sm pt-2">
              A modern digital platform connecting users with earning opportunities, referral rewards,
              and eligible financial services through a simple, transparent, and security-first experience.
            </p>
            <div className="flex items-center gap-3 pt-2 text-xs">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-300 font-medium">
                <ShieldCheck className="w-3.5 h-3.5 text-[#00e575]" />
                Security-First
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-300 font-medium">
                <Lock className="w-3.5 h-3.5 text-sky-400" />
                Transparent
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-slate-300 font-medium">
                Compliance-Focused
              </span>
            </div>
          </div>

          {/* Platform Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Platform</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate("how-it-works")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  How It Works
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("earn")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Earn / Tasks
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("referral")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Referral System
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("plans")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  T1–T7 Product Plans
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("financial-services")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Financial Services
                </button>
              </li>
            </ul>
          </div>

          {/* Company & Content */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Company</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate("about")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  About TRIZZ
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("blog")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Blog & Knowledge Base
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("security")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Security & Architecture
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("support")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Contact Support
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("faq")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Frequently Asked Questions
                </button>
              </li>
            </ul>
          </div>

          {/* Compliance & Legal */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">Legal & Governance</h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              <li>
                <button
                  onClick={() => onNavigate("terms")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Terms & Conditions
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("privacy")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("risk-disclosure")}
                  className="hover:text-[#00e575] transition-colors cursor-pointer font-medium"
                >
                  Risk Disclosure Statement
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate("verification")}
                  className="hover:text-white transition-colors cursor-pointer"
                >
                  Account Verification (KYC)
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Regulatory & Risk Transparency Notice */}
        <div className="py-8 text-xs text-slate-400 space-y-2 leading-relaxed">
          <p>
            <strong className="text-slate-300">Mandatory Regulatory & Operational Disclaimer:</strong> TRIZZ is a digital task marketplace and rewards technology platform. Earning opportunities, referral commissions, and task payouts are contingent upon genuine qualifying events, rigorous fraud monitoring, and server-side validation.
          </p>
          <p>
            TRIZZ does not make claims of guaranteed income, fixed investment returns, or risk-free financial transactions. Financial services presented on the platform are provided in conjunction with third-party regulated and authorized infrastructure partners. Standard withdrawal settlement windows occur exclusively on Saturdays (00:00 to 23:59 WAT) subject to applicable tier minimums and the standard 15% platform processing fee.
          </p>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <div>
            © {new Date().getFullYear()} TRIZZ Technologies. All rights reserved. Built for modern digital finance.
          </div>
          <div className="flex items-center gap-6">
            <span className="flex items-center gap-1.5 text-slate-400">
              <span className="w-2 h-2 rounded-full bg-[#00e575]" />
              System Status: Fully Operational
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
};
