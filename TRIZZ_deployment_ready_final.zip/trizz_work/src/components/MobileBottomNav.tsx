import React from "react";
import { PageRoute } from "../types.ts";
import { LayoutDashboard, ListTodo, Wallet, ArrowDownToLine, Share2 } from "lucide-react";

interface MobileBottomNavProps {
  currentRoute: PageRoute;
  onNavigate: (route: PageRoute) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentRoute,
  onNavigate,
}) => {
  const items: { label: string; route: PageRoute; icon: React.ReactNode }[] = [
    { label: "Dashboard", route: "dashboard", icon: <LayoutDashboard className="w-5 h-5" /> },
    { label: "Earn", route: "earn", icon: <ListTodo className="w-5 h-5" /> },
    { label: "Wallet", route: "wallet", icon: <Wallet className="w-5 h-5" /> },
    { label: "Withdraw", route: "withdraw", icon: <ArrowDownToLine className="w-5 h-5" /> },
    { label: "Refer", route: "referral", icon: <Share2 className="w-5 h-5" /> },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#07080b]/95 backdrop-blur-lg border-t border-slate-800/90 px-2 py-2">
      <div className="grid grid-cols-5 items-center justify-around">
        {items.map((item) => {
          const isActive = currentRoute === item.route;
          return (
            <button
              key={item.route}
              id={`mobile-bottom-nav-${item.route}`}
              onClick={() => onNavigate(item.route)}
              className={`flex flex-col items-center justify-center py-1 px-1 rounded-xl transition-all cursor-pointer ${
                isActive ? "text-[#00e575]" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <div
                className={`p-1 rounded-lg transition-colors ${
                  isActive ? "bg-[#00e575]/15 text-[#00e575]" : ""
                }`}
              >
                {item.icon}
              </div>
              <span className={`text-[10px] mt-0.5 tracking-tight ${isActive ? "font-bold text-[#00e575]" : "font-medium"}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
