import React from "react";
import { TRIZZLogo } from "./TRIZZLogo.tsx";
import { NotificationItem, PageRoute } from "../types.ts";
import { Bell, X, CheckCheck, ExternalLink, ShieldAlert, Award, Clock, ArrowDownToLine } from "lucide-react";

interface NotificationCenterProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
  onMarkRead: (id: string) => void;
  onMarkAllRead: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkRead,
  onMarkAllRead,
  onNavigate,
}) => {
  if (!isOpen) return null;

  const getIcon = (type: string) => {
    switch (type) {
      case "verification":
        return <Award className="w-4 h-4 text-amber-400" />;
      case "withdrawal":
        return <ArrowDownToLine className="w-4 h-4 text-sky-400" />;
      case "security":
        return <ShieldAlert className="w-4 h-4 text-rose-400" />;
      default:
        return <Clock className="w-4 h-4 text-[#00e575]" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm transition-opacity">
      <div
        className="w-full max-w-md bg-[#0d0f17] border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200"
        id="notification-drawer"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-[#00e575]" />
            <h3 className="font-bold text-white text-base">Notifications</h3>
            <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-xs font-mono font-bold">
              {notifications.filter((n) => !n.read).length}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {notifications.some((n) => !n.read) && (
              <button
                onClick={onMarkAllRead}
                className="text-xs text-slate-400 hover:text-[#00e575] transition-colors flex items-center gap-1 cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>Mark all read</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {notifications.length === 0 ? (
            <div className="text-center py-20 flex flex-col items-center justify-center space-y-3">
              <div className="p-3 rounded-2xl bg-[#0a0d14] border border-slate-800/80">
                <TRIZZLogo size="xs" glow />
              </div>
              <p className="text-sm font-bold text-white uppercase tracking-wider font-heading">
                No Notifications Yet
              </p>
              <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                You're all caught up. Account updates, Saturday withdrawal schedules, and task verifications will show here.
              </p>
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => {
                  if (!n.read) onMarkRead(n.id);
                  if (n.link) {
                    const cleanRoute = n.link.replace("/", "") as PageRoute;
                    onNavigate(cleanRoute);
                    onClose();
                  }
                }}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  n.read
                    ? "bg-slate-900/40 border-slate-800/80 text-slate-400"
                    : "bg-slate-900/90 border-[#00e575]/30 text-white shadow-sm"
                } hover:border-[#00e575]/50`}
              >
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-slate-800/80 flex-shrink-0 mt-0.5">
                    {getIcon(n.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="text-xs font-bold text-slate-200 truncate">{n.title}</h4>
                      <span className="text-[10px] text-slate-400 font-mono whitespace-nowrap">
                        {new Date(n.createdAt).toLocaleDateString(undefined, {
                          month: "short",
                          day: "numeric",
                        })}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">{n.message}</p>
                    {n.link && (
                      <span className="inline-flex items-center gap-1 text-[11px] text-[#00e575] font-semibold mt-2">
                        <span>View details</span>
                        <ExternalLink className="w-3 h-3" />
                      </span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
