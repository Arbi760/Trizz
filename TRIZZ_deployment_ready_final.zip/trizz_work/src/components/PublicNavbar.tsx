import React, { useState } from "react";
import { TRIZZLogo } from "./TRIZZLogo.tsx";
import { PageRoute, UserSession } from "../types.ts";
import { Menu, X, ArrowRight, ShieldCheck, User } from "lucide-react";

interface PublicNavbarProps {
  currentRoute: PageRoute;
  onNavigate: (route: PageRoute) => void;
  user: UserSession | null;
}

export const PublicNavbar: React.FC<PublicNavbarProps> = ({
  currentRoute,
  onNavigate,
  user,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; route: PageRoute }[] = [
    { label: "Home", route: "home" },
    { label: "How It Works", route: "how-it-works" },
    { label: "Earn / Tasks", route: "earn" },
    { label: "Referral", route: "referral" },
    { label: "Plans", route: "plans" },
    { label: "Financial Services", route: "financial-services" },
    { label: "Blog", route: "blog" },
    { label: "Support", route: "support" },
  ];

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-[#07080b]/90 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <div className="flex items-center gap-8">
          <TRIZZLogo
            size="md"
            showTagline={false}
            onClick={() => onNavigate("home")}
          />

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
            {navLinks.map((link) => {
              const isActive = currentRoute === link.route;
              return (
                <button
                  key={link.route}
                  id={`nav-link-${link.route}`}
                  onClick={() => onNavigate(link.route)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap cursor-pointer ${
                    isActive
                      ? "text-[#00e575] bg-[#00e575]/10 font-semibold"
                      : "text-slate-300 hover:text-white hover:bg-slate-800/50"
                  }`}
                >
                  {link.label}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Right Action Buttons */}
        <div className="hidden lg:flex items-center gap-3">
          {user ? (
            <button
              id="nav-btn-dashboard"
              onClick={() => onNavigate("dashboard")}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-all cursor-pointer shadow-lg shadow-[#00e575]/20"
            >
              <User className="w-4 h-4" />
              <span>Dashboard</span>
            </button>
          ) : (
            <>
              <button
                id="nav-btn-login"
                onClick={() => onNavigate("login")}
                className="px-4 py-2 rounded-xl text-sm font-semibold text-slate-200 hover:text-white hover:bg-slate-800/60 transition-colors cursor-pointer"
              >
                Sign In
              </button>
              <button
                id="nav-btn-get-started"
                onClick={() => onNavigate("signup")}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm tracking-wide hover:bg-[#00ff84] transition-all transform hover:-translate-y-0.5 cursor-pointer shadow-lg shadow-[#00e575]/25"
              >
                <span>GET STARTED</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </>
          )}
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex lg:hidden items-center gap-2">
          {user && (
            <button
              onClick={() => onNavigate("dashboard")}
              className="px-3 py-1.5 rounded-lg bg-[#00e575] text-[#07080b] text-xs font-bold"
            >
              Dashboard
            </button>
          )}
          <button
            id="mobile-nav-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-b border-slate-800 bg-[#090b10] px-4 pt-3 pb-6 space-y-1">
          {navLinks.map((link) => (
            <button
              key={link.route}
              onClick={() => {
                onNavigate(link.route);
                setMobileMenuOpen(false);
              }}
              className={`w-full text-left px-4 py-2.5 rounded-lg text-sm font-medium transition-colors cursor-pointer ${
                currentRoute === link.route
                  ? "bg-[#00e575]/15 text-[#00e575] font-semibold"
                  : "text-slate-300 hover:bg-slate-800/60 hover:text-white"
              }`}
            >
              {link.label}
            </button>
          ))}

          <div className="pt-4 border-t border-slate-800 flex flex-col gap-2.5">
            {user ? (
              <button
                onClick={() => {
                  onNavigate("dashboard");
                  setMobileMenuOpen(false);
                }}
                className="w-full py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-center text-sm shadow-md"
              >
                Open Dashboard
              </button>
            ) : (
              <>
                <button
                  onClick={() => {
                    onNavigate("login");
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-2.5 rounded-xl border border-slate-700 text-slate-200 font-semibold text-center text-sm"
                >
                  Sign In
                </button>
                <button
                  onClick={() => {
                    onNavigate("signup");
                    setMobileMenuOpen(false);
                  }}
                  className="w-full py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-center text-sm shadow-lg shadow-[#00e575]/20"
                >
                  GET STARTED
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
