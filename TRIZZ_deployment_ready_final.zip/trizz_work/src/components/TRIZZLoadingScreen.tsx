import React, { useEffect, useState } from "react";
import { TRIZZLogo } from "./TRIZZLogo";

interface TRIZZLoadingScreenProps {
  onComplete?: () => void;
  minDurationMs?: number;
}

export const TRIZZLoadingScreen: React.FC<TRIZZLoadingScreenProps> = ({
  onComplete,
  minDurationMs = 1200,
}) => {
  const [fadingOut, setFadingOut] = useState(false);
  const [mounted, setMounted] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setFadingOut(true);
      const exitTimer = setTimeout(() => {
        setMounted(false);
        onComplete?.();
      }, 500);
      return () => clearTimeout(exitTimer);
    }, minDurationMs);

    return () => clearTimeout(timer);
  }, [minDurationMs, onComplete]);

  if (!mounted) return null;

  return (
    <div
      id="trizz-loading-screen"
      className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-[#07080b] transition-opacity duration-500 ${
        fadingOut ? "opacity-0 pointer-events-none" : "opacity-100"
      }`}
    >
      {/* Ambient background soft glow */}
      <div className="absolute w-96 h-96 rounded-full bg-[#00e575]/10 blur-[100px] pointer-events-none animate-pulse" />

      {/* Centered Brand Container */}
      <div className="relative flex flex-col items-center text-center px-4 max-w-sm">
        <div className="relative mb-6">
          {/* Subtle pulsating energy ring */}
          <div
            className="absolute -inset-4 rounded-full bg-gradient-to-tr from-[#00e575]/20 to-transparent blur-md animate-spin"
            style={{ animationDuration: "8s" }}
          />
          <TRIZZLogo size="hero" glow priority />
        </div>

        {/* Brand Tagline */}
        <div className="flex items-center gap-2 mb-4">
          <span className="h-1.5 w-1.5 rounded-full bg-[#00e575] animate-ping" />
          <span className="text-xs font-semibold tracking-[0.25em] text-slate-300 uppercase">
            Move • Earn • Refer
          </span>
        </div>

        {/* Minimalist Loading Bar */}
        <div className="w-48 h-1 bg-slate-900 rounded-full overflow-hidden border border-slate-800/80">
          <div
            className="h-full bg-gradient-to-r from-[#00e575]/40 via-[#00e575] to-[#00e575]/40 rounded-full animate-[shimmer_1.5s_infinite]"
            style={{
              width: "100%",
              animation: "pulse 1.2s ease-in-out infinite",
            }}
          />
        </div>

        <p className="text-[11px] text-slate-500 font-mono tracking-wider mt-3">
          SECURE FINTECH INFRASTRUCTURE
        </p>
      </div>
    </div>
  );
};
