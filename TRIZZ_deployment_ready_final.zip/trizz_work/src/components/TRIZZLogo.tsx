import React from "react";

export interface TRIZZLogoProps {
  size?: "xs" | "sm" | "md" | "lg" | "xl" | "hero" | "splash";
  variant?: "full" | "compact" | "emblem";
  showTagline?: boolean;
  glow?: boolean;
  className?: string;
  onClick?: () => void;
  priority?: boolean;
}

export const TRIZZLogo: React.FC<TRIZZLogoProps> = ({
  size = "md",
  showTagline = false,
  glow = false,
  className = "",
  onClick,
  priority = false,
}) => {
  const sizeMap: Record<
    "xs" | "sm" | "md" | "lg" | "xl" | "hero" | "splash",
    {
      img: string;
      tagline: string;
    }
  > = {
    xs: { img: "h-6 w-6", tagline: "text-[8px]" },
    sm: { img: "h-8 w-8", tagline: "text-[9px]" },
    md: { img: "h-10 w-10 sm:h-11 sm:w-11", tagline: "text-[10px]" },
    lg: { img: "h-14 w-14 sm:h-16 sm:w-16", tagline: "text-xs" },
    xl: { img: "h-20 w-20 sm:h-24 sm:w-24", tagline: "text-xs" },
    hero: { img: "h-32 w-32 sm:h-40 sm:w-40 md:h-48 md:w-48", tagline: "text-sm" },
    splash: { img: "h-44 w-44 sm:h-52 sm:w-52", tagline: "text-base" },
  };

  const currentSize = sizeMap[size] || sizeMap.md;

  return (
    <div
      id="trizz-official-logo"
      onClick={onClick}
      className={`inline-flex items-center gap-3 select-none ${onClick ? "cursor-pointer" : ""} group ${className}`}
    >
      <div className="relative flex-shrink-0 flex items-center justify-center">
        {/* Subtle Brand Neon Glow Ambient layer */}
        {glow && (
          <div
            className="absolute inset-0 rounded-full bg-[#00e575]/25 blur-xl pointer-events-none transform group-hover:scale-110 transition-transform duration-500"
            aria-hidden="true"
          />
        )}

        {/* Official Single Source of Truth Transparent Brand Logo */}
        <img
          src="/trizz-logo-512.png"
          srcSet="/trizz-logo-512.png 1x, /trizz-logo.png 2x"
          alt="TRIZZ Official Brand Logo"
          referrerPolicy="no-referrer"
          loading={priority ? "eager" : "lazy"}
          decoding="async"
          className={`${currentSize.img} object-contain drop-shadow-[0_0_15px_rgba(0,229,117,0.22)] transition-all duration-300 group-hover:drop-shadow-[0_0_24px_rgba(0,229,117,0.4)] group-hover:scale-[1.02]`}
        />
      </div>

      {showTagline && (
        <div className="flex flex-col justify-center leading-none">
          <span className="font-heading font-black tracking-[0.25em] text-white text-base sm:text-lg uppercase">
            TRIZZ
          </span>
          <span
            className={`${currentSize.tagline} text-[#00e575] font-semibold tracking-[0.22em] uppercase mt-1 opacity-90`}
          >
            Move • Earn • Refer
          </span>
        </div>
      )}
    </div>
  );
};

// Also export with alias TrizzLogo for seamless compatibility
export const TrizzLogo = TRIZZLogo;
