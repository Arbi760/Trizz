import { createClient, SupabaseClient } from "@supabase/supabase-js";

/**
 * TRIZZ PUBLIC CLIENT — SUPABASE CONFIGURATION
 *
 * CRITICAL SECURITY DIRECTIVE:
 * - This file runs exclusively in the user's browser / client-side environment.
 * - It uses ONLY the public anon key (VITE_SUPABASE_ANON_KEY) restricted by PostgreSQL Row Level Security (RLS).
 * - NEVER import, expose, or use SUPABASE_SERVICE_ROLE_KEY here.
 * - All privileged operations and administrative controls are reserved for the future separate TRIZZ Admin Control Center.
 */

const env = ((import.meta as unknown as { env?: Record<string, string> }).env) || {};
const supabaseUrl = env.VITE_SUPABASE_URL || "";
const supabaseAnonKey = env.VITE_SUPABASE_ANON_KEY || "";

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  !supabaseUrl.includes("YOUR_PROJECT_REF")
);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    })
  : null;
