import { supabase } from "../lib/supabaseClient.ts";
import {
  PlatformConfig,
  UserSession,
  WalletData,
  TaskItem,
  ReferralData,
  PlanItem,
  BlogPostItem,
  NotificationItem,
  WalletTransaction,
} from "../types.ts";

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const { data: { session } } = supabase ? await supabase.auth.getSession() : { data: { session: null } };
  const token = session?.access_token || null;
  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const isGet = !options.method || options.method.toUpperCase() === "GET";

  let res: Response;
  try {
    res = await fetch(path, {
      ...options,
      headers,
    });
  } catch (networkError: any) {
    console.warn(`[TRIZZ API] Network fetch failed for ${path}:`, networkError?.message);

    // If it's a GET request, retry once after 350ms to absorb server restarts
    if (isGet) {
      try {
        await new Promise((resolve) => setTimeout(resolve, 350));
        res = await fetch(path, {
          ...options,
          headers,
        });
      } catch {
        throw new Error("Unable to reach the TRIZZ secure server. Please try again.");
      }
    } else {
      throw new Error(
        networkError?.message === "Failed to fetch"
          ? "Unable to reach the TRIZZ secure server. Please check your internet connection and try again."
          : networkError?.message || "Network request failed"
      );
    }
  }

  // Guard against HTML response from proxies or Vite fallbacks
  const contentType = res.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    throw new Error("Invalid response received from server. Please try again.");
  }

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const message = data.error || data.message || `Request failed with status ${res.status}`;
    const err = new Error(message) as any;
    err.code = data.code;
    err.status = res.status;
    err.table = data.table;
    err.requiresSetup = data.requiresSetup;
    throw err;
  }

  return data as T;
}

export const api = {
  // Supabase Backend Status & Diagnostics
  getSupabaseStatus: () => request<any>("/api/supabase/status"),

  // Config
  getConfig: () => request<PlatformConfig>("/api/config"),

  // Auth
  register: (payload: any) =>
    request<{ message: string; token: string; user: UserSession }>("/api/auth/register", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  login: (payload: { identifier: string; password: string }) =>
    request<{ token: string; user: UserSession }>("/api/auth/login", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  getMe: () =>
    request<{
      user: UserSession;
      wallet: any;
      verification: any;
      twoFactorEnabled: boolean;
    }>("/api/auth/me"),
  ensureOAuthProfile: (payload: { fullName?: string; username?: string; phone?: string; country?: string; currencyPreference?: "USD" | "NGN"; referralCode?: string }) =>
    request<{ user: UserSession }>("/api/auth/oauth-profile", { method: "POST", body: JSON.stringify(payload) }),
  logout: () =>
    request<{ message: string }>("/api/auth/logout", {
      method: "POST",
    }),

  // Wallet
  getWallet: () => request<WalletData>("/api/wallet"),
  initiateDeposit: (amountUsd: number, network?: string) =>
    request<any>("/api/wallet/deposit", {
      method: "POST",
      body: JSON.stringify({ amountUsd, network }),
    }),
  verifyDeposit: (payload: {
    transactionId?: string;
    transactionHash: string;
    paymentReference?: string;
    notes?: string;
  }) =>
    request<any>("/api/wallet/deposit/verify", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  submitWithdrawal: (payload: {
    amountUsd: number;
    withdrawalMethod: string;
    destinationDetails: {
      bankName?: string;
      accountNumber: string;
      accountName?: string;
      routingCode?: string;
    };
  }) =>
    request<any>("/api/wallet/withdraw", {
      method: "POST",
      body: JSON.stringify(payload),
    }),
  configureAutoWithdraw: (payload: {
    enabled: boolean;
    mode: "minimum" | "custom";
    customAmount: number;
  }) =>
    request<any>("/api/wallet/auto-withdraw", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // Tasks
  getTasks: () =>
    request<{ tasks: TaskItem[]; categories: string[]; userTier: string }>("/api/tasks"),
  startTask: (taskId: string) =>
    request<any>(`/api/tasks/${taskId}/start`, { method: "POST" }),
  submitTask: (taskId: string, proofText: string, proofUrl?: string) =>
    request<any>(`/api/tasks/${taskId}/submit`, {
      method: "POST",
      body: JSON.stringify({ proofText, proofUrl }),
    }),

  // Referrals
  getReferrals: () => request<ReferralData>("/api/referrals"),

  // Plans
  getPlans: () =>
    request<{ plans: PlanItem[]; referenceConversion: string }>("/api/plans"),
  subscribePlan: (planTier: string) =>
    request<any>("/api/plans/subscribe", {
      method: "POST",
      body: JSON.stringify({ planTier }),
    }),

  // Verification
  getVerification: () => request<any>("/api/verification"),
  submitVerification: (payload: {
    documentType: string;
    documentNumber: string;
    fullNameOnDocument: string;
    documentFrontName?: string;
  }) =>
    request<any>("/api/verification/submit", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // Transactions
  getTransactions: (params?: { type?: string; status?: string; search?: string }) => {
    const q = new URLSearchParams();
    if (params?.type) q.append("type", params.type);
    if (params?.status) q.append("status", params.status);
    if (params?.search) q.append("search", params.search);
    return request<{ transactions: WalletTransaction[]; totalCount: number }>(
      `/api/transactions?${q.toString()}`
    );
  },

  // Blog
  getBlogPosts: (params?: { category?: string; search?: string }) => {
    const q = new URLSearchParams();
    if (params?.category) q.append("category", params.category);
    if (params?.search) q.append("search", params.search);
    return request<{ posts: BlogPostItem[]; categories: string[] }>(`/api/blog?${q.toString()}`);
  },
  getBlogPost: (slug: string) => request<{ post: BlogPostItem }>(`/api/blog/${slug}`),

  // Support
  getSupportInfo: () => request<any>("/api/support/info"),
  submitSupportTicket: (payload: {
    name?: string;
    email: string;
    subject: string;
    message: string;
    category?: string;
  }) =>
    request<any>("/api/support/ticket", {
      method: "POST",
      body: JSON.stringify(payload),
    }),

  // Notifications
  getNotifications: () =>
    request<{ notifications: NotificationItem[]; unreadCount: number }>("/api/notifications"),
  markNotificationRead: (id: string) =>
    request<any>(`/api/notifications/${id}/read`, { method: "POST" }),
  markAllNotificationsRead: () =>
    request<any>("/api/notifications/read-all", { method: "POST" }),
};
