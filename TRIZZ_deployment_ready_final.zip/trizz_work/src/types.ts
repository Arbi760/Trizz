export type PageRoute =
  | "home"
  | "about"
  | "how-it-works"
  | "earn"
  | "referral"
  | "financial-services"
  | "services"
  | "plans"
  | "wallet"
  | "withdraw"
  | "transactions"
  | "blog"
  | "blog-detail"
  | "support"
  | "faq"
  | "security"
  | "terms"
  | "privacy"
  | "risk-disclosure"
  | "login"
  | "signup"
  | "verification"
  | "dashboard"
  | "404"
  | "maintenance";

export interface UserSession {
  id: string;
  fullName: string;
  username: string;
  email: string;
  phone: string;
  country: string;
  currencyPreference: "USD" | "NGN";
  referralCode: string;
  planTier: "FREE" | "T1" | "T2" | "T3" | "T4" | "T5" | "T6" | "T7";
  verificationStatus: "not_verified" | "pending" | "verified" | "rejected" | "requires_info";
  createdAt?: string;
}

export interface WalletData {
  availableBalanceUsd: number;
  pendingBalanceUsd: number;
  totalEarnedUsd: number;
  totalWithdrawnUsd: number;
  referralRewardsUsd: number;
  availableBalanceNgn: number;
  pendingBalanceNgn: number;
  totalEarnedNgn: number;
  totalWithdrawnNgn: number;
  rates: {
    depositRate: number;
    withdrawalRate: number;
    withdrawalFeePercent: number;
  };
  userTier: string;
  minimumWithdrawalUsd: number;
  minimumWithdrawalNgn: number;
  withdrawalWindow: {
    isOpen: boolean;
    currentDay: string;
    currentHour: number;
    secondsUntilNextWindow: number;
    nextWindowDateString: string;
    message: string;
    scheduleDay?: string;
    timezone?: string;
  };
  autoWithdrawal: {
    enabled: boolean;
    mode: "minimum" | "custom";
    customAmount: number;
    feePercent: number;
  };
  cryptoDeposit: {
    enabled: boolean;
    asset: string;
    network: string;
    address: string;
    minimumDepositUsd: number;
  };
  recentTransactions?: WalletTransaction[];
}

export interface WalletTransaction {
  id: string;
  userId: string;
  type: "deposit" | "withdrawal" | "reward" | "referral" | "task" | "plan_purchase" | "adjustment";
  amountUsd: number;
  amountNgn: number;
  conversionRate: number;
  feeUsd: number;
  netAmountUsd: number;
  currency: string;
  status: "pending" | "processing" | "completed" | "failed" | "cancelled" | "rejected" | "under_review";
  reference: string;
  description: string;
  createdAt: string;
  metadata?: any;
}

export interface TaskItem {
  id: string;
  title: string;
  description: string;
  category: "app" | "social" | "survey" | "review" | "security" | "finance";
  rewardUsd: number;
  rewardNgn: number;
  estimatedMinutes: number;
  status: "available" | "in_progress" | "submitted" | "under_review" | "approved" | "rejected" | "completed";
  userStatus?: string;
  requirements: string[];
  instructions: string;
  deadlineDays: number;
  planRequirement?: string;
  submission?: {
    id: string;
    status: string;
    proofText?: string;
    proofUrl?: string;
    submittedAt?: string;
  };
}

export interface ReferralData {
  referralCode: string;
  referralLink: string;
  totalReferrals: number;
  activeReferrals: number;
  pendingRewardsUsd: number;
  pendingRewardsNgn: number;
  approvedRewardsUsd: number;
  approvedRewardsNgn: number;
  tierCommissionRate: string;
  history: Array<{
    id: string;
    referredUsername: string;
    qualifyingAction: string;
    rewardUsd: number;
    rewardNgn: number;
    status: "pending" | "approved" | "rejected";
    createdAt: string;
  }>;
}

export interface PlanItem {
  id: string;
  tier: string;
  name: string;
  priceUsd: number;
  priceNgn: number;
  description: string;
  features: string[];
  minWithdrawalUsd: number;
  minWithdrawalNgn: number;
  dailyTaskCap: number;
  referralBonusPercentage: number;
  popular?: boolean;
}

export interface BlogPostItem {
  id: string;
  slug: string;
  title: string;
  summary: string;
  content: string;
  category: string;
  author: {
    name: string;
    role: string;
  };
  publishedAt: string;
  readingTimeMinutes: number;
  tags: string[];
  featuredImageUrl?: string;
  videoUrl?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: string;
  read: boolean;
  link?: string;
  createdAt: string;
}

export type PlatformNotification = NotificationItem;

export interface PlatformConfig {
  brand: {
    name: string;
    tagline: string;
    supportingTagline: string;
    description: string;
  };
  rates: {
    depositReferenceRateNgnPerUsd: number;
    withdrawalReferenceRateNgnPerUsd: number;
    standardWithdrawalFeePercent: number;
    autoWithdrawalFeePercent: number;
  };
  withdrawalWindow: {
    isOpen: boolean;
    currentDay: string;
    currentHour: number;
    secondsUntilNextWindow: number;
    nextWindowDateString: string;
    message: string;
    scheduleDay: string;
    timezone: string;
  };
  minimumWithdrawalsByTier: Record<string, number>;
  cryptoDeposit: {
    enabled: boolean;
    asset: string;
    network: string;
    address: string;
    minimumDepositUsd: number;
  };
  supportChannels: {
    email: string;
    whatsapp: string;
    telegram: string;
    supportHours: string;
  };
  plans: PlanItem[];
}
