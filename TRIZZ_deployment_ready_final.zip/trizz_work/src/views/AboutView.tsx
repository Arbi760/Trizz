import React from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute } from "../types.ts";
import {
  ShieldCheck,
  Zap,
  Lock,
  Cpu,
  Eye,
  RefreshCw,
  ArrowRight,
  CheckCircle2,
} from "lucide-react";

interface AboutViewProps {
  onNavigate: (route: PageRoute) => void;
}

export const AboutView: React.FC<AboutViewProps> = ({ onNavigate }) => {
  const pillars = [
    {
      title: "Trust",
      description: "Built on absolute financial discipline. We do not manufacture fake statistics, fabricate user counts, or offer misleading guarantees.",
      icon: <ShieldCheck className="w-5 h-5 text-[#00e575]" />,
    },
    {
      title: "Technology",
      description: "Modern digital architecture decoupling public presentation from secure administrative ledgers with server-side validation.",
      icon: <Cpu className="w-5 h-5 text-sky-400" />,
    },
    {
      title: "Financial Sophistication",
      description: "Normalized transaction accounting with explicit conversion rates, transparent processing fees, and scheduled liquidity windows.",
      icon: <Zap className="w-5 h-5 text-amber-400" />,
    },
    {
      title: "Security & Fraud Prevention",
      description: "Defenses against referral farming, multi-account abuse, bot submissions, and unauthorized ledger modifications.",
      icon: <Lock className="w-5 h-5 text-rose-400" />,
    },
    {
      title: "Simplicity & Speed",
      description: "Clean, clutter-free user experience allowing anyone to understand registration, verification, task completion, and payouts in minutes.",
      icon: <RefreshCw className="w-5 h-5 text-[#00e575]" />,
    },
    {
      title: "Transparency",
      description: "Zero hidden rules. Clear Saturday settlement windows, published 15% platform fees, and verifiable task qualification criteria.",
      icon: <Eye className="w-5 h-5 text-sky-400" />,
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4 flex flex-col items-center">
        <TRIZZLogo size="lg" glow showTagline={false} className="mb-2" />
        <span className="text-xs font-mono font-bold text-[#00e575] uppercase tracking-widest">
          Platform Architecture & Vision
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          About <span className="text-[#00e575]">TRIZZ</span>
        </h1>
        <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
          TRIZZ represents movement, transactions, technology, earning opportunities, referrals, and access to legitimate digital financial services.
        </p>
      </div>

      {/* Brand Language Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-8 rounded-2xl bg-[#0d0f17] border border-slate-800 text-center space-y-3">
          <span className="text-xs font-mono font-bold text-[#00e575] tracking-widest">CORE ACTION</span>
          <h3 className="text-3xl font-black text-white font-heading">MOVE.</h3>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            Fluid movement of digital assets, frictionless peer interactions, and rapid cross-border technology access.
          </p>
        </div>

        <div className="p-8 rounded-2xl bg-[#0d0f17] border border-slate-800 text-center space-y-3">
          <span className="text-xs font-mono font-bold text-sky-400 tracking-widest">REAL PRODUCTIVITY</span>
          <h3 className="text-3xl font-black text-white font-heading">EARN.</h3>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            Marketplace tasks backed by legitimate institutional partners, surveys, and app evaluation programs.
          </p>
        </div>

        <div className="p-8 rounded-2xl bg-[#0d0f17] border border-slate-800 text-center space-y-3">
          <span className="text-xs font-mono font-bold text-amber-400 tracking-widest">ECOSYSTEM GROWTH</span>
          <h3 className="text-3xl font-black text-white font-heading">REFER.</h3>
          <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
            A merit-based referral structure rewarding genuine network builders with transparent percentage commissions.
          </p>
        </div>
      </div>

      {/* Supporting Language Bar */}
      <div className="p-6 rounded-2xl bg-[#090b11] border border-slate-800/80 text-center">
        <span className="text-xs uppercase font-mono tracking-[0.25em] text-slate-400 font-semibold">
          Alternative Supporting Language:
        </span>
        <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-12 mt-2 font-heading font-extrabold text-lg sm:text-2xl text-slate-200">
          <span className="hover:text-[#00e575] transition-colors">TRANSFER</span>
          <span className="text-slate-600">•</span>
          <span className="hover:text-sky-400 transition-colors">TRADE</span>
          <span className="text-slate-600">•</span>
          <span className="hover:text-[#00e575] transition-colors">TRANSACT</span>
        </div>
      </div>

      {/* Six Pillars of TRIZZ */}
      <div className="space-y-8">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
            Institutional Values
          </h2>
          <p className="text-xs sm:text-sm text-slate-400">
            What differentiates TRIZZ from generic platforms and unregulated online schemes.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pillars.map((pillar, idx) => (
            <div key={idx} className="p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-3">
              <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 w-fit">
                {pillar.icon}
              </div>
              <h4 className="text-lg font-bold text-white font-heading">{pillar.title}</h4>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">{pillar.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Compliance & Responsible Design Stance */}
      <div className="p-8 rounded-3xl bg-[#0a0c12] border border-slate-800 space-y-4">
        <h3 className="text-lg font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#00e575]" />
          <span>Our Strict Compliance Philosophy</span>
        </h3>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          TRIZZ is expressly engineered NOT to resemble a gambling site, meme-coin casino, gaming parlor, or get-rich-quick program.
          We strictly avoid hyperbolic promotional terminology. No claims of "risk-free" or "guaranteed profits" are ever made.
          Every feature—from our task approval queues to our Saturday withdrawal windows—operates on verified backend integrity.
        </p>
        <div className="pt-2 flex flex-wrap gap-4">
          <button
            onClick={() => onNavigate("how-it-works")}
            className="px-5 py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] cursor-pointer transition-colors"
          >
            Explore How It Works
          </button>
          <button
            onClick={() => onNavigate("risk-disclosure")}
            className="px-5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 font-semibold text-xs hover:text-white cursor-pointer"
          >
            Read Risk Disclosure
          </button>
        </div>
      </div>
    </div>
  );
};
