import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import { supabase } from "../lib/supabaseClient.ts";
import {
  Lock,
  Mail,
  User,
  Phone,
  Globe,
  Share2,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  X,
} from "lucide-react";

interface AuthViewsProps {
  mode: "login" | "signup";
  onSuccess: (user: UserSession) => void;
  onNavigate: (route: PageRoute) => void;
}

export const AuthViews: React.FC<AuthViewsProps> = ({
  mode,
  onSuccess,
  onNavigate,
}) => {
  // Login form state
  const [loginIdentifier, setLoginIdentifier] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Signup form state
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [country, setCountry] = useState("Nigeria");
  const [currencyPreference, setCurrencyPreference] = useState<"USD" | "NGN">("USD");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [referralCode, setReferralCode] = useState("");
  const [agreeTerms, setAgreeTerms] = useState(false);
  const [agreePrivacy, setAgreePrivacy] = useState(false);

  // Loading and feedback
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Forgot password modal
  const [forgotPasswordOpen, setForgotPasswordOpen] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");
  const [forgotSubmitted, setForgotSubmitted] = useState(false);

  // Google Custom Dialog (for instant connection or direct Google account email)

  const handleTriggerGoogleFlow = async () => {
    if (!supabase) {
      setError("Supabase authentication is not configured.");
      return;
    }
    try {
      setGoogleLoading(true);
      setError(null);
      const redirectTo = `${window.location.origin}${window.location.pathname}#dashboard`;
      const { error: oauthError } = await supabase.auth.signInWithOAuth({
        provider: "google",
        options: { redirectTo },
      });
      if (oauthError) throw oauthError;
    } catch (err: any) {
      setError(err.message || "Google authentication failed. Please retry.");
      setGoogleLoading(false);
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginIdentifier.trim() || !loginPassword.trim()) {
      setError("Please enter your username/email and password.");
      return;
    }
    try {
      setLoading(true);
      setError(null);
      const res = await api.login({
        identifier: loginIdentifier,
        password: loginPassword,
      });
      if (!supabase) throw new Error("Supabase authentication is not configured.");
      const { error: sessionError } = await supabase.auth.signInWithPassword({ email: res.user.email, password: loginPassword });
      if (sessionError) throw sessionError;
      onSuccess(res.user);
      onNavigate("dashboard");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    if (!agreeTerms || !agreePrivacy) {
      setError("You must accept the Terms & Conditions and Privacy Policy.");
      return;
    }

    try {
      setLoading(true);
      setError(null);
      const res = await api.register({
        fullName,
        username,
        email,
        phone,
        country,
        currencyPreference,
        password,
        referralCode: referralCode.trim() || undefined,
      });
      if (!supabase) throw new Error("Supabase authentication is not configured.");
      const { error: sessionError } = await supabase.auth.signInWithPassword({ email, password });
      if (sessionError) throw sessionError;
      onSuccess(res.user);
      onNavigate("verification");
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail.trim() || !forgotEmail.includes("@")) {
      setError("Please enter a valid registered email address.");
      return;
    }
    if (!supabase) {
      setError("Supabase authentication is not configured.");
      return;
    }
    try {
      setLoading(true);
      setError(null);
      const redirectTo = `${window.location.origin}${window.location.pathname}#login`;
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(forgotEmail.trim().toLowerCase(), { redirectTo });
      if (resetError) throw resetError;
      setForgotSubmitted(true);
    } catch (err: any) {
      setError(err.message || "Unable to send recovery instructions.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12">
      <div className="w-full max-w-md space-y-6">
        {/* Brand Header with Official TRIZZ Logo */}
        <div className="text-center space-y-3">
          <div className="flex justify-center mb-2">
            <TRIZZLogo
              size="lg"
              glow
              priority
              showTagline={false}
              onClick={() => onNavigate("home")}
            />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading uppercase tracking-wider">
            {mode === "login" ? "Sign In to TRIZZ" : "Create TRIZZ Account"}
          </h1>
          <p className="text-xs sm:text-sm text-slate-400">
            {mode === "login"
              ? "Access your verified dashboard, wallet ledger, and earning tasks."
              : "Join a secure, verified rewards and digital financial network."}
          </p>
        </div>

        {/* Error Feedback */}
        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-medium">
            {error}
          </div>
        )}

        {/* Card Form */}
        <div className="p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-5">
          {/* PRIMARY GOOGLE SIGN-IN BUTTON */}
          <div className="space-y-3">
            <button
              id="google-signin-action-btn"
              type="button"
              onClick={handleTriggerGoogleFlow}
              disabled={googleLoading}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-500 text-white font-medium text-xs sm:text-sm flex items-center justify-center gap-3 transition-all hover:bg-slate-800/80 cursor-pointer shadow-sm group"
            >
              <svg className="w-4 h-4 flex-shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>
                {googleLoading
                  ? "Connecting to Google..."
                  : mode === "login"
                  ? "Sign in with Google"
                  : "Sign up with Google"}
              </span>
            </button>

            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-slate-800"></div>
              <span className="flex-shrink mx-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">
                Or continue with password
              </span>
              <div className="flex-grow border-t border-slate-800"></div>
            </div>
          </div>

          {/* Form */}
          {mode === "login" ? (
            <form onSubmit={handleLogin} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Username or Email</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    placeholder="alex.vance@example.com or alexvance"
                    className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-medium">Password</label>
                  <button
                    type="button"
                    onClick={() => {
                      setForgotSubmitted(false);
                      setForgotEmail(loginIdentifier.includes("@") ? loginIdentifier : "");
                      setForgotPasswordOpen(true);
                    }}
                    className="text-[11px] text-[#00e575] hover:underline cursor-pointer"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="p-1 text-slate-500 hover:text-white absolute right-3 top-1/2 -translate-y-1/2 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="checkbox" defaultChecked className="accent-[#00e575] rounded" />
                  <span>Remember this browser</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#00e575]/20"
              >
                <span>{loading ? "Verifying Credentials..." : "Sign In with Password"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <form onSubmit={handleSignup} className="space-y-3.5 text-xs">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Full Legal Name *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="As displayed on government ID"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Username *</label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Choose username"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Country *</label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575] cursor-pointer"
                  >
                    <option value="Nigeria">Nigeria</option>
                    <option value="Ghana">Ghana</option>
                    <option value="Kenya">Kenya</option>
                    <option value="South Africa">South Africa</option>
                    <option value="United States">United States</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Other">Other International</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Email Address *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+234..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Currency Display Preference</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCurrencyPreference("USD")}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                      currencyPreference === "USD"
                        ? "bg-[#00e575]/10 border-[#00e575] text-[#00e575]"
                        : "bg-slate-900 border-slate-800 text-slate-400"
                    }`}
                  >
                    <span>USD ($) — Global</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrencyPreference("NGN")}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer ${
                      currencyPreference === "NGN"
                        ? "bg-[#00e575]/10 border-[#00e575] text-[#00e575]"
                        : "bg-slate-900 border-slate-800 text-slate-400"
                    }`}
                  >
                    <span>NGN (₦) — Local</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Password *</label>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min. 8 characters"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                  />
                </div>
              </div>

              {/* Referral Code */}
              <div className="space-y-1">
                <label className="text-slate-400 text-[11px] flex items-center justify-between">
                  <span>Referral Code (Optional)</span>
                  <span className="text-slate-500 font-mono">e.g. TRZ-ALEX992</span>
                </label>
                <div className="relative">
                  <Share2 className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    placeholder="e.g. TRZ-5049"
                    className="w-full pl-10 pr-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono text-xs focus:outline-none focus:border-[#00e575]"
                  />
                </div>
              </div>

              {/* Checkboxes */}
              <div className="space-y-2 pt-1 text-[11px] text-slate-400">
                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={agreeTerms}
                    onChange={(e) => setAgreeTerms(e.target.checked)}
                    className="mt-0.5 accent-[#00e575] rounded"
                  />
                  <span>
                    I accept the{" "}
                    <button
                      type="button"
                      onClick={() => onNavigate("terms")}
                      className="text-[#00e575] underline cursor-pointer"
                    >
                      Terms and Conditions
                    </button>{" "}
                    including Saturday settlement schedules & 15% platform fee.
                  </span>
                </label>

                <label className="flex items-start gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={agreePrivacy}
                    onChange={(e) => setAgreePrivacy(e.target.checked)}
                    className="mt-0.5 accent-[#00e575] rounded"
                  />
                  <span>
                    I have read and consent to the{" "}
                    <button
                      type="button"
                      onClick={() => onNavigate("privacy")}
                      className="text-[#00e575] underline cursor-pointer"
                    >
                      Privacy Policy
                    </button>{" "}
                    and KYC identity validation protocol.
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#00e575]/20"
              >
                <span>{loading ? "Registering Profile..." : "Create Account with Password"}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}
        </div>

        {/* Footer Switch Link */}
        <div className="text-center text-xs text-slate-400">
          {mode === "login" ? (
            <p>
              Don't have an account yet?{" "}
              <button
                onClick={() => onNavigate("signup")}
                className="text-[#00e575] font-bold hover:underline cursor-pointer ml-1"
              >
                Register here
              </button>
            </p>
          ) : (
            <p>
              Already registered?{" "}
              <button
                onClick={() => onNavigate("login")}
                className="text-[#00e575] font-bold hover:underline cursor-pointer ml-1"
              >
                Sign in to your account
              </button>
            </p>
          )}
        </div>

        {/* Security Assurance Badge */}
        <div className="flex items-center justify-center gap-2 text-slate-500 text-[11px]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#00e575]" />
          <span>Protected by 256-bit TLS encryption & session token isolation</span>
        </div>
      </div>

      {/* MODAL: FORGOT PASSWORD / RECOVERY */}
      {forgotPasswordOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-700 shadow-2xl space-y-5 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <TRIZZLogo size="xs" />
                <span className="font-bold text-white text-sm">TRIZZ Password Recovery</span>
              </div>
              <button
                type="button"
                onClick={() => setForgotPasswordOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {forgotSubmitted ? (
              <div className="text-center py-4 space-y-3">
                <div className="w-12 h-12 rounded-full bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-base font-bold text-white">Recovery Instructions Sent</h3>
                <p className="text-xs text-slate-400 leading-relaxed max-w-xs mx-auto">
                  We've dispatched a secure password reset link to <strong className="text-white">{forgotEmail}</strong>. Please check your inbox and spam folders.
                </p>
                <button
                  type="button"
                  onClick={() => setForgotPasswordOpen(false)}
                  className="mt-2 w-full py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] cursor-pointer"
                >
                  Return to Sign In
                </button>
              </div>
            ) : (
              <form onSubmit={handleForgotPasswordSubmit} className="space-y-4 text-xs">
                <p className="text-slate-400 text-xs leading-relaxed">
                  Enter your registered email address and we'll send you a cryptographic reset link to restore your account access.
                </p>

                <div className="space-y-1">
                  <label className="text-slate-300 font-medium">Registered Email</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={forgotEmail}
                      onChange={(e) => setForgotEmail(e.target.value)}
                      placeholder="alex.vance@example.com"
                      className="w-full pl-10 pr-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all cursor-pointer shadow-md shadow-[#00e575]/20"
                >
                  Send Recovery Link
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
