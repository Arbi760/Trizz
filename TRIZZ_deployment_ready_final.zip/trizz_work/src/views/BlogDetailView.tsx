import React, { useState, useEffect } from "react";
import { BlogPostItem, PageRoute } from "../types.ts";
import { api } from "../services/api.ts";
import {
  ArrowLeft,
  Clock,
  User,
  Calendar,
  Tag,
  Share2,
  Check,
  ShieldCheck,
} from "lucide-react";

interface BlogDetailViewProps {
  slug: string;
  onBack: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const BlogDetailView: React.FC<BlogDetailViewProps> = ({
  slug,
  onBack,
  onNavigate,
}) => {
  const [post, setPost] = useState<BlogPostItem | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setLoading(true);
    api
      .getBlogPost(slug)
      .then((res) => setPost(res.post))
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, [slug]);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 animate-pulse space-y-6">
        <div className="h-8 w-40 bg-slate-800 rounded-lg" />
        <div className="h-12 w-full bg-slate-800 rounded-lg" />
        <div className="h-64 bg-slate-800 rounded-2xl" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold text-white">Article Not Found</h2>
        <p className="text-slate-400 text-sm">The requested publication does not exist or has been archived.</p>
        <button
          onClick={onBack}
          className="px-4 py-2 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs"
        >
          Return to Blog
        </button>
      </div>
    );
  }

  return (
    <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition-colors cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to All Publications</span>
      </button>

      {/* Article Header */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="px-3 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] text-xs font-mono font-bold uppercase">
            {post.category}
          </span>
          <span className="text-xs text-slate-400 font-mono flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5" />
            <span>{post.readingTimeMinutes} min read</span>
          </span>
          <span className="text-xs text-slate-400 font-mono flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5" />
            <span>{new Date(post.publishedAt).toLocaleDateString(undefined, { dateStyle: "long" })}</span>
          </span>
        </div>

        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white font-heading leading-tight">
          {post.title}
        </h1>

        <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
          {post.summary}
        </p>

        {/* Author info & share button */}
        <div className="pt-4 border-t border-slate-800/80 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#00e575]/20 text-[#00e575] flex items-center justify-center font-bold text-sm">
              {post.author.name.charAt(0)}
            </div>
            <div>
              <p className="text-xs font-bold text-white">{post.author.name}</p>
              <p className="text-[11px] text-slate-400">{post.author.role}</p>
            </div>
          </div>

          <button
            onClick={handleShare}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-medium cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#00e575]" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copied ? "Link Copied" : "Share"}</span>
          </button>
        </div>
      </div>

      {/* Article Content */}
      <div className="p-8 sm:p-12 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-6 text-slate-300 text-sm sm:text-base leading-relaxed">
        {post.content.split("\n\n").map((paragraph, idx) => {
          if (paragraph.startsWith("## ")) {
            return (
              <h2 key={idx} className="text-xl sm:text-2xl font-bold text-white font-heading pt-4">
                {paragraph.replace("## ", "")}
              </h2>
            );
          }
          if (paragraph.startsWith("- ")) {
            const items = paragraph.split("\n").map((item) => item.replace("- ", ""));
            return (
              <ul key={idx} className="space-y-2 list-disc list-inside text-slate-300 pl-2">
                {items.map((it, i) => (
                  <li key={i}>{it}</li>
                ))}
              </ul>
            );
          }
          return <p key={idx}>{paragraph}</p>;
        })}
      </div>

      {/* Tags */}
      <div className="flex flex-wrap items-center gap-2 pt-2">
        <span className="text-xs text-slate-400 font-mono flex items-center gap-1 mr-2">
          <Tag className="w-3.5 h-3.5" />
          <span>Tags:</span>
        </span>
        {post.tags.map((tag, idx) => (
          <span
            key={idx}
            className="px-3 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 text-xs font-mono"
          >
            #{tag}
          </span>
        ))}
      </div>

      {/* Next Step / Engagement Box */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-[#0e121d] to-[#07090f] border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="space-y-1 text-center sm:text-left">
          <h3 className="text-lg font-bold text-white">Ready to put this knowledge to work?</h3>
          <p className="text-xs text-slate-400">
            Explore active partner tasks and test your skills in the TRIZZ marketplace.
          </p>
        </div>
        <button
          onClick={() => onNavigate("earn")}
          className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all shadow-md cursor-pointer whitespace-nowrap"
        >
          Explore Tasks
        </button>
      </div>
    </article>
  );
};
