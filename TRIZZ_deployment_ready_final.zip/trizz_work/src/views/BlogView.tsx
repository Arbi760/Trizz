import React, { useState, useEffect } from "react";
import { BlogPostItem, PageRoute } from "../types.ts";
import { api } from "../services/api.ts";
import {
  BookOpen,
  Clock,
  User,
  Tag,
  Search,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
} from "lucide-react";

interface BlogViewProps {
  onSelectPost: (slug: string) => void;
  onNavigate: (route: PageRoute) => void;
}

export const BlogView: React.FC<BlogViewProps> = ({ onSelectPost, onNavigate }) => {
  const [posts, setPosts] = useState<BlogPostItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [search, setSearch] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    api
      .getBlogPosts({
        category: selectedCategory || undefined,
        search: search || undefined,
      })
      .then((res) => {
        setPosts(res?.posts || []);
        setCategories(res?.categories || []);
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, [selectedCategory, search]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <BookOpen className="w-3.5 h-3.5" />
          <span>TRIZZ Knowledge Base & Insights</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Blog & <span className="text-[#00e575]">Education</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Master financial literacy, understand platform settlement mechanics, explore security best practices,
          and maximize genuine community referral growth.
        </p>
      </div>

      {/* Search & Categories */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-[#0d0f17] border border-slate-800">
        <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          <button
            onClick={() => setSelectedCategory("")}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === ""
                ? "bg-[#00e575] text-[#07080b]"
                : "bg-slate-900 text-slate-400 hover:text-white"
            }`}
          >
            All Insights
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? "bg-[#00e575] text-[#07080b]"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search articles..."
            className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-[#00e575]"
          />
        </div>
      </div>

      {/* Posts Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-72 rounded-3xl bg-slate-900/60 border border-slate-800" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {posts.map((post) => (
            <article
              key={post.id}
              onClick={() => onSelectPost(post.slug)}
              className="p-6 sm:p-7 rounded-3xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between cursor-pointer group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] text-[11px] font-mono font-bold uppercase">
                    {post.category}
                  </span>
                  <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{post.readingTimeMinutes} min read</span>
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-[#00e575] transition-colors leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed line-clamp-3">
                    {post.summary}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1">
                  {post.tags.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded bg-slate-900 text-slate-400 text-[10px] font-mono"
                    >
                      #{t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-6 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-bold text-[10px]">
                    {post.author.name.charAt(0)}
                  </div>
                  <span>{post.author.name}</span>
                </div>

                <span className="text-[#00e575] font-bold group-hover:translate-x-1 transition-transform inline-flex items-center gap-1">
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
};
