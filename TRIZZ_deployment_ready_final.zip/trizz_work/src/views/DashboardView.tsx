import React from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession, WalletData, TaskItem } from "../types.ts";
import {
  ShieldCheck,
  AlertCircle,
  Clock,
  Wallet,
  ArrowDownToLine,
  Coins,
  Share2,
  ListTodo,
  History,
  TrendingUp,
  Layers,
  ArrowRight,
  ExternalLink,
  Zap,
} from "lucide-react";

interface DashboardViewProps {
  user: UserSession;
  wallet: WalletData | null;
  onNavigate: (route: PageRoute) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  user,
  wallet,
  onNavigate,
}) => {
  const isVerified = user.verificationStatus === "verified";
  const isPending = user.verificationStatus === "pending";

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
      {/* Top Banner: Greeting, Tier & Verification Badge */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0d121c] via-[#0b0e17] to-[#07090f] border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="hidden sm:block">
            <TRIZZLogo size="md" glow />
          </div>
          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl sm:text-3xl font-black text-white font-heading">
                Welcome back, {user.fullName.split(" ")[0]}
              </h1>
              <span className="px-3 py-1 rounded-full bg-[#00e575]/10 text-[#00e575] border border-[#00e575]/30 text-xs font-mono font-bold">
                {user.planTier} TIER
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400">
              Username: <span className="text-white font-mono">@{user.username}</span> • Account ID:{" "}
              <span className="text-slate-500 font-mono">{user.id}</span>
            </p>
          </div>
        </div>

        {/* Verification Alert / Status */}
        <div className="flex items-center gap-3">
          {isVerified ? (
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] text-xs font-bold font-mono">
              <ShieldCheck className="w-4 h-4" />
              <span>KYC VERIFIED</span>
            </div>
          ) : isPending ? (
            <div className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold font-mono">
              <Clock className="w-4 h-4" />
              <span>KYC UNDER AUDIT</span>
            </div>
          ) : (
            <button
              onClick={() => onNavigate("verification")}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 hover:bg-rose-500/20 text-xs font-bold font-mono transition-colors cursor-pointer"
            >
              <AlertCircle className="w-4 h-4" />
              <span>COMPLETE VERIFICATION</span>
            </button>
          )}

          <button
            onClick={() => onNavigate("plans")}
            className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors cursor-pointer whitespace-nowrap"
          >
            Upgrade Tier
          </button>
        </div>
      </div>

      {/* 5 Key Balances Mandated by Specification */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {/* Available Balance */}
        <div
          onClick={() => onNavigate("wallet")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-[#00e575]/30 hover:border-[#00e575]/60 transition-all cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-[#00e575] uppercase">
              Available Balance
            </span>
            <Wallet className="w-4 h-4 text-[#00e575] group-hover:scale-110 transition-transform" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            ${(wallet?.availableBalanceUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            ≈ ₦{(wallet?.availableBalanceNgn ?? 0).toLocaleString()}
          </p>
        </div>

        {/* Pending Balance */}
        <div
          onClick={() => onNavigate("wallet")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
              Pending Balance
            </span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            ${(wallet?.pendingBalanceUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            ≈ ₦{(wallet?.pendingBalanceNgn ?? 0).toLocaleString()}
          </p>
        </div>

        {/* Total Earned */}
        <div
          onClick={() => onNavigate("earn")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-sky-400 uppercase">
              Total Earned
            </span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            ${(wallet?.totalEarnedUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            ≈ ₦{(wallet?.totalEarnedNgn ?? 0).toLocaleString()}
          </p>
        </div>

        {/* Total Withdrawn */}
        <div
          onClick={() => onNavigate("withdraw")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-slate-400 uppercase">
              Total Withdrawn
            </span>
            <ArrowDownToLine className="w-4 h-4 text-slate-400" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            ${(wallet?.totalWithdrawnUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            ≈ ₦{(wallet?.totalWithdrawnNgn ?? 0).toLocaleString()}
          </p>
        </div>

        {/* Referral Rewards */}
        <div
          onClick={() => onNavigate("referral")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all cursor-pointer space-y-2 group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-[#00e575] uppercase">
              Referral Rewards
            </span>
            <Share2 className="w-4 h-4 text-[#00e575]" />
          </div>
          <p className="text-2xl font-black text-white font-mono">
            ${(wallet?.referralRewardsUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-[11px] font-mono text-slate-400">
            ≈ ₦{((wallet?.referralRewardsUsd ?? 0) * (wallet?.rates?.withdrawalRate ?? 1200)).toLocaleString()}
          </p>
        </div>
      </div>

      {/* Quick Action Grid (Deposit, Withdraw, Refer, Tasks) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button
          onClick={() => onNavigate("wallet")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-[#00e575]/50 transition-all flex flex-col items-center justify-center gap-2 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-[#00e575]/10 text-[#00e575] flex items-center justify-center group-hover:scale-105 transition-transform">
            <Coins className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-white uppercase font-mono">Deposit USDT</span>
          <span className="text-[10px] text-slate-400">BEP-20 Blockchain</span>
        </button>

        <button
          onClick={() => onNavigate("withdraw")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-[#00e575]/50 transition-all flex flex-col items-center justify-center gap-2 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center group-hover:scale-105 transition-transform">
            <ArrowDownToLine className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-white uppercase font-mono">Withdraw Funds</span>
          <span className="text-[10px] text-slate-400">Saturday Window</span>
        </button>

        <button
          onClick={() => onNavigate("earn")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-[#00e575]/50 transition-all flex flex-col items-center justify-center gap-2 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:scale-105 transition-transform">
            <ListTodo className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-white uppercase font-mono">Available Tasks</span>
          <span className="text-[10px] text-slate-400">Earn Verified Rewards</span>
        </button>

        <button
          onClick={() => onNavigate("referral")}
          className="p-5 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-[#00e575]/50 transition-all flex flex-col items-center justify-center gap-2 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Share2 className="w-5 h-5" />
          </div>
          <span className="text-xs font-bold text-white uppercase font-mono">Refer Colleagues</span>
          <span className="text-[10px] text-slate-400">Commission Engine</span>
        </button>
      </div>

      {/* Saturday Window Protocol Status & Referral Link Card */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Card 1: Saturday Window */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-amber-400 flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>Weekly Liquidity Schedule</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">00:00 - 23:59 WAT</span>
            </div>
            <h3 className="text-lg font-bold text-white">Saturday Settlement Window</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Status:{" "}
              <strong className={wallet?.withdrawalWindow?.isOpen ? "text-[#00e575]" : "text-amber-400"}>
                {wallet?.withdrawalWindow?.message || "Withdrawal schedule unavailable."}
              </strong>
              . Standard withdrawals carry a 15% platform processing fee and require KYC verified status.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-300">
              Min. Required for {user.planTier}:{" "}
              <strong className="text-white">${wallet?.minimumWithdrawalUsd}.00</strong>
            </span>
            <button
              onClick={() => onNavigate("withdraw")}
              className="inline-flex items-center gap-1 text-xs font-bold text-[#00e575] hover:underline cursor-pointer"
            >
              <span>Settlement Center</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Card 2: Personal Referral Quick Copy */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase text-[#00e575] flex items-center gap-1.5">
                <Share2 className="w-4 h-4" />
                <span>Personal Referral Code</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">EARN COMMISSIONS</span>
            </div>
            <h3 className="text-lg font-bold text-white font-mono tracking-wider">
              {user.referralCode}
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Share your personal link to earn percentage commissions on verified network member tasks and upgrades.
            </p>
          </div>

          <div className="pt-2 flex items-center justify-between">
            <button
              onClick={() => {
                navigator.clipboard.writeText(`https://trizz.io/register?ref=${user.referralCode}`);
                alert("Referral link copied to clipboard!");
              }}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer transition-colors"
            >
              Copy Referral Link
            </button>
            <button
              onClick={() => onNavigate("referral")}
              className="inline-flex items-center gap-1 text-xs font-bold text-[#00e575] hover:underline cursor-pointer"
            >
              <span>View Referrals</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Recent Ledger Transactions Feed */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-slate-400" />
            <h3 className="text-lg font-bold text-white font-heading">Recent Account Activity</h3>
          </div>
          <button
            onClick={() => onNavigate("transactions")}
            className="text-xs text-[#00e575] font-bold hover:underline cursor-pointer"
          >
            View Full Ledger →
          </button>
        </div>

        <div className="rounded-3xl bg-[#0d0f17] border border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="px-6 py-3.5">Reference</th>
                  <th className="px-6 py-3.5">Type</th>
                  <th className="px-6 py-3.5">Description</th>
                  <th className="px-6 py-3.5">Amount</th>
                  <th className="px-6 py-3.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {wallet?.recentTransactions && wallet.recentTransactions.length > 0 ? (
                  wallet.recentTransactions.slice(0, 5).map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-6 py-3.5 font-mono text-slate-400">
                        #{tx.reference.slice(0, 10)}...
                      </td>
                      <td className="px-6 py-3.5 uppercase font-mono font-bold text-slate-200">
                        {tx.type}
                      </td>
                      <td className="px-6 py-3.5 text-slate-300 max-w-xs truncate">{tx.description}</td>
                      <td className="px-6 py-3.5 font-mono font-bold">
                        <span
                          className={
                            tx.type === "withdrawal" || tx.type === "plan_purchase"
                              ? "text-rose-400"
                              : "text-[#00e575]"
                          }
                        >
                          {tx.type === "withdrawal" || tx.type === "plan_purchase" ? "-" : "+"}
                          ${tx.amountUsd.toFixed(2)}
                        </span>
                      </td>
                      <td className="px-6 py-3.5">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                            tx.status === "completed"
                              ? "bg-[#00e575]/10 text-[#00e575]"
                              : "bg-amber-500/10 text-amber-400"
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-slate-500">
                      No recent activities recorded. Complete tasks or deposit funds to get started.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
