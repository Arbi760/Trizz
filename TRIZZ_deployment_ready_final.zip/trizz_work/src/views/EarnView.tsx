import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, TaskItem, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import {
  ListTodo,
  Clock,
  Award,
  CheckCircle2,
  AlertCircle,
  Play,
  Send,
  X,
  Filter,
  ShieldCheck,
  ChevronRight,
  ExternalLink,
} from "lucide-react";

interface EarnViewProps {
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
}

export const EarnView: React.FC<EarnViewProps> = ({ user, onNavigate }) => {
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [categories, setCategories] = useState<string[]>(["all"]);
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [loading, setLoading] = useState<boolean>(true);
  const [activeTask, setActiveTask] = useState<TaskItem | null>(null);
  const [proofText, setProofText] = useState<string>("");
  const [proofUrl, setProofUrl] = useState<string>("");
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const fetchTasks = async () => {
    try {
      setLoading(true);
      const data = await api.getTasks();
      setTasks(data?.tasks || []);
      setCategories(["all", "app", "survey", "security", "review", "social"]);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [user]);

  const handleStartTask = async (task: TaskItem) => {
    if (!user) {
      onNavigate("login");
      return;
    }
    try {
      await api.startTask(task.id);
      await fetchTasks();
      setActiveTask({ ...task, userStatus: "in_progress" });
    } catch (err: any) {
      setFeedbackMessage({ type: "error", text: err.message });
    }
  };

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTask) return;
    if (!proofText.trim() && !proofUrl.trim()) {
      setFeedbackMessage({
        type: "error",
        text: "Please provide proof notes, screenshot reference, or transaction/survey code.",
      });
      return;
    }

    try {
      setSubmitting(true);
      const res = await api.submitTask(activeTask.id, proofText, proofUrl);
      setFeedbackMessage({ type: "success", text: res.message });
      setProofText("");
      setProofUrl("");
      await fetchTasks();
      setTimeout(() => {
        setActiveTask(null);
        setFeedbackMessage(null);
      }, 2500);
    } catch (err: any) {
      setFeedbackMessage({ type: "error", text: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const filteredTasks = tasks.filter((t) => {
    if (selectedCategory === "all") return true;
    return t.category === selectedCategory;
  });

  const getStatusBadge = (status?: string) => {
    switch (status) {
      case "in_progress":
        return (
          <span className="px-2.5 py-1 rounded-md bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-bold uppercase font-mono">
            In Progress
          </span>
        );
      case "submitted":
      case "under_review":
        return (
          <span className="px-2.5 py-1 rounded-md bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase font-mono">
            Under Review
          </span>
        );
      case "approved":
      case "completed":
        return (
          <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] text-xs font-bold uppercase font-mono">
            Completed
          </span>
        );
      case "rejected":
        return (
          <span className="px-2.5 py-1 rounded-md bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold uppercase font-mono">
            Rejected
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-1 rounded-md bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold uppercase font-mono">
            Available
          </span>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] font-mono font-bold text-xs">
              MARKETPLACE
            </span>
            <span className="text-xs text-slate-400">Server-Side Verified Rewards</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-heading uppercase">
            Earn / <span className="text-[#00e575]">Tasks</span>
          </h1>
          <p className="text-sm text-slate-300 max-w-xl">
            Complete partner applications testing, sentiment surveys, and security reviews.
            All tasks are verified by backend compliance before reward issuance.
          </p>
        </div>

        {/* User Tier & Info */}
        {user ? (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-slate-900 border border-slate-800">
            <div className="text-right">
              <p className="text-[10px] text-slate-400 font-mono uppercase">Current Tier</p>
              <p className="text-sm font-bold text-white">{user.planTier}</p>
            </div>
            <button
              onClick={() => onNavigate("plans")}
              className="px-3 py-1.5 rounded-lg bg-[#00e575]/10 text-[#00e575] hover:bg-[#00e575]/20 text-xs font-bold transition-colors cursor-pointer"
            >
              Upgrade Tier
            </button>
          </div>
        ) : (
          <button
            onClick={() => onNavigate("signup")}
            className="px-5 py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all shadow-md cursor-pointer w-fit"
          >
            Create Account to Start Earning
          </button>
        )}
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <Filter className="w-4 h-4 text-slate-500 mr-1 flex-shrink-0" />
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all whitespace-nowrap cursor-pointer ${
              selectedCategory === cat
                ? "bg-[#00e575] text-[#07080b] shadow-md shadow-[#00e575]/20"
                : "bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Task Cards Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-pulse">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-64 rounded-2xl bg-slate-900/60 border border-slate-800" />
          ))}
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="p-12 rounded-3xl bg-[#0d0f17] border border-slate-800 text-center flex flex-col items-center justify-center max-w-lg mx-auto space-y-3">
          <div className="p-3 rounded-2xl bg-[#0a0d14] border border-slate-800/80">
            <TRIZZLogo size="sm" glow />
          </div>
          <h4 className="text-base font-bold text-white uppercase tracking-wider font-heading">
            No Tasks Available
          </h4>
          <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
            There are currently no tasks matching your selected category or tier. New task batches are released on regular verification cycles.
          </p>
          <button
            onClick={() => setSelectedCategory("all")}
            className="mt-2 px-4 py-2 rounded-xl bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] hover:bg-[#00e575]/20 font-bold text-xs transition-colors cursor-pointer"
          >
            Show All Tasks
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task) => {
            const currentStatus = task.userStatus || task.status;
            return (
              <div
                key={task.id}
                className="p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  {/* Top tags */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[11px] font-mono uppercase text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {task.category}
                    </span>
                    {getStatusBadge(currentStatus)}
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-[#00e575] transition-colors leading-snug">
                      {task.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed line-clamp-3">
                      {task.description}
                    </p>
                  </div>

                  {/* Reward and estimated time */}
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800/80 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-mono">Reward</span>
                      <p className="text-base font-black text-[#00e575] font-mono">
                        ${task.rewardUsd.toFixed(2)}{" "}
                        <span className="text-xs text-slate-400 font-normal">
                          (₦{task.rewardNgn.toLocaleString()})
                        </span>
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase font-mono">Est. Time</span>
                      <p className="text-xs font-bold text-slate-300 flex items-center gap-1 justify-end">
                        <Clock className="w-3.5 h-3.5 text-amber-400" />
                        <span>~{task.estimatedMinutes} mins</span>
                      </p>
                    </div>
                  </div>

                  {/* Requirements Preview */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[11px] font-bold text-slate-300 uppercase tracking-wider">
                      Requirements:
                    </span>
                    <ul className="space-y-1">
                      {task.requirements.slice(0, 2).map((req, rIdx) => (
                        <li key={rIdx} className="text-xs text-slate-400 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-[#00e575] flex-shrink-0" />
                          <span className="truncate">{req}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Card Action Button */}
                <div className="pt-6">
                  {currentStatus === "in_progress" ? (
                    <button
                      onClick={() => setActiveTask(task)}
                      className="w-full py-2.5 rounded-xl bg-sky-500 text-[#07080b] font-bold text-xs hover:bg-sky-400 transition-colors flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                      <span>Submit Proof / Review</span>
                    </button>
                  ) : currentStatus === "submitted" || currentStatus === "under_review" ? (
                    <div className="w-full py-2.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold text-center flex items-center justify-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span>Under Audit Review</span>
                    </div>
                  ) : currentStatus === "approved" || currentStatus === "completed" ? (
                    <div className="w-full py-2.5 rounded-xl bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] text-xs font-bold text-center flex items-center justify-center gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Reward Credited to Wallet</span>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleStartTask(task)}
                      className="w-full py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#00e575]/15"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>Start Task</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Task Submission / Detail Modal */}
      {activeTask && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4">
          <div className="w-full max-w-xl bg-[#0d0f17] border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-4">
              <div>
                <span className="text-xs font-mono text-[#00e575] uppercase font-bold">
                  {activeTask.category} Task
                </span>
                <h3 className="text-xl font-bold text-white">{activeTask.title}</h3>
              </div>
              <button
                onClick={() => setActiveTask(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Reward summary */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400">Task Payout</span>
                <p className="text-lg font-black text-[#00e575] font-mono">
                  ${activeTask.rewardUsd.toFixed(2)} (₦{activeTask.rewardNgn.toLocaleString()})
                </p>
              </div>
              <span className="text-xs text-slate-400 font-mono">Est. {activeTask.estimatedMinutes} mins</span>
            </div>

            {/* Instructions */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Instructions</h4>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed bg-slate-900/50 p-3.5 rounded-xl border border-slate-800/80">
                {activeTask.instructions}
              </p>
            </div>

            {/* Requirements */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Mandatory Criteria</h4>
              <ul className="space-y-1.5">
                {activeTask.requirements.map((req, i) => (
                  <li key={i} className="text-xs text-slate-300 flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-[#00e575] flex-shrink-0 mt-0.5" />
                    <span>{req}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Submission Form */}
            <form onSubmit={handleSubmitProof} className="space-y-4 pt-2 border-t border-slate-800">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">Submit Verification Proof</h4>

              {feedbackMessage && (
                <div
                  className={`p-3 rounded-xl text-xs ${
                    feedbackMessage.type === "success"
                      ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
                      : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
                  }`}
                >
                  {feedbackMessage.text}
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">
                  Proof Notes / Survey Completion Code
                </label>
                <textarea
                  value={proofText}
                  onChange={(e) => setProofText(e.target.value)}
                  placeholder="Paste transaction reference, survey completion token, or qualitative summary of app testing..."
                  rows={3}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs text-slate-300 font-medium">Screenshot / Proof URL (Optional)</label>
                <input
                  type="text"
                  value={proofUrl}
                  onChange={(e) => setProofUrl(e.target.value)}
                  placeholder="https://drive.google.com/... or image upload link"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveTask(null)}
                  className="flex-1 py-3 rounded-xl border border-slate-700 text-slate-300 text-xs font-bold hover:bg-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-3 rounded-xl bg-[#00e575] text-[#07080b] text-xs font-bold hover:bg-[#00ff84] transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  {submitting ? "Validating..." : "Submit for Audit Review"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
