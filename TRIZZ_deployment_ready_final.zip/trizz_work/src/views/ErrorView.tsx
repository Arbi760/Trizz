import React from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute } from "../types.ts";
import { AlertTriangle, Home, RefreshCw, LifeBuoy, ShieldAlert } from "lucide-react";

interface ErrorViewProps {
  type?: "404" | "500" | "maintenance";
  onNavigate: (route: PageRoute) => void;
  onRetry?: () => void;
}

export const ErrorView: React.FC<ErrorViewProps> = ({
  type = "404",
  onNavigate,
  onRetry,
}) => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <div className="max-w-lg w-full text-center space-y-6 bg-[#0c0e16] border border-slate-800/80 p-8 sm:p-10 rounded-3xl shadow-2xl relative overflow-hidden">
        {/* Subtle accent backdrop */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-[#00e575]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Official TRIZZ Emblem */}
        <div className="flex justify-center mb-2">
          <TRIZZLogo size="lg" glow priority />
        </div>

        {type === "404" && (
          <>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>HTTP 404 • ROUTE NOT FOUND</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-heading uppercase tracking-tight">
              Page Not Found
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm mx-auto">
              The secure financial ledger or module you requested does not exist or has been relocated within the TRIZZ infrastructure.
            </p>
          </>
        )}

        {type === "500" && (
          <>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-xs font-mono text-rose-400">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>HTTP 500 • SERVICE INTERRUPTED</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-heading uppercase tracking-tight">
              System Error
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm mx-auto">
              A temporary protocol exception occurred. Our automated ledger monitors have flagged this event for rapid resolution.
            </p>
          </>
        )}

        {type === "maintenance" && (
          <>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-400">
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
              <span>SCHEDULED PROTOCOL AUDIT</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white font-heading uppercase tracking-tight">
              Maintenance Window
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm mx-auto">
              TRIZZ liquidity pools and settlement pipelines are undergoing routine integrity verification. Normal operations resume shortly.
            </p>
          </>
        )}

        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          {onRetry && (
            <button
              onClick={onRetry}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white text-xs font-bold font-mono transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Request</span>
            </button>
          )}
          <button
            onClick={() => onNavigate("home")}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#00e575] hover:bg-[#00ff84] text-[#07080b] text-xs font-black font-mono transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#00e575]/15"
          >
            <Home className="w-3.5 h-3.5" />
            <span>Return to Home</span>
          </button>
          <button
            onClick={() => onNavigate("support")}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800 text-slate-300 text-xs font-bold font-mono transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <LifeBuoy className="w-3.5 h-3.5 text-[#00e575]" />
            <span>Contact Support</span>
          </button>
        </div>
      </div>
    </div>
  );
};
