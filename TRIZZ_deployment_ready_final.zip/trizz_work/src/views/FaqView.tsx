import React, { useState } from "react";
import { PageRoute } from "../types.ts";
import {
  HelpCircle,
  Search,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";

interface FaqViewProps {
  onNavigate: (route: PageRoute) => void;
}

interface FaqItem {
  id: string;
  category: "getting-started" | "earning" | "referrals" | "withdrawals" | "security";
  question: string;
  answer: string;
}

export const FaqView: React.FC<FaqViewProps> = ({ onNavigate }) => {
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  const [expandedId, setExpandedId] = useState<string | null>("w-1");

  const faqs: FaqItem[] = [
    // Getting Started
    {
      id: "gs-1",
      category: "getting-started",
      question: "What is TRIZZ and who can join?",
      answer:
        "TRIZZ is a modern digital platform connecting users with partner earning tasks, referral commission rewards, and access to eligible financial and currency services. Anyone of legal age in supported jurisdictions can create an account and complete KYC verification.",
    },
    {
      id: "gs-2",
      category: "getting-started",
      question: "Is registration free or do I have to purchase a plan?",
      answer:
        "Account creation is completely free. Members start with standard basic access. You may voluntarily activate T1 through T7 product tiers to unlock higher daily task quotas, increased referral commission percentages, and tailored withdrawal thresholds.",
    },
    {
      id: "gs-3",
      category: "getting-started",
      question: "What currency can I use on TRIZZ?",
      answer:
        "TRIZZ operates primarily in United States Dollars (USD) as an accounting baseline, with full support for Nigerian Naira (NGN) conversions and USDT (BEP-20) blockchain deposits. You can select your display preference in your profile.",
    },

    // Earning / Tasks
    {
      id: "e-1",
      category: "earning",
      question: "How do tasks work and when are rewards paid?",
      answer:
        "Tasks represent genuine partner engagements such as testing application usability, completing market research surveys, or evaluating fintech workflows. Once submitted with valid proof, our backend compliance system audits the action before crediting your available wallet balance.",
    },
    {
      id: "e-2",
      category: "earning",
      question: "Why was my task rejected or put under review?",
      answer:
        "Task rewards are never awarded automatically upon button click. Submissions with fabricated screenshots, incorrect completion codes, duplicate submissions, or automated bot patterns are flagged and rejected to preserve platform integrity.",
    },
    {
      id: "e-3",
      category: "earning",
      question: "Are daily tasks guaranteed every day?",
      answer:
        "Task volume depends on partner demand and your active tier quota. TRIZZ never makes claims of guaranteed fixed daily income. Tasks are distributed dynamically based on advertiser campaign availability.",
    },

    // Referrals
    {
      id: "r-1",
      category: "referrals",
      question: "How does the referral commission model function?",
      answer:
        "When an invited user signs up with your referral code or link, you earn structured percentage commissions (ranging from 5% on base tiers up to 16% on T7) on verified qualifying actions and plan activations. There are no limits to how many legitimate members you can refer.",
    },
    {
      id: "r-2",
      category: "referrals",
      question: "How does TRIZZ prevent referral fraud and fake accounts?",
      answer:
        "Our backend enforces strict anti-farming heuristics. Self-referrals, multi-accounting on the same IP cluster, disposable email networks, and bot rings are banned. Rewards remain pending until the referred member clears basic verification.",
    },

    // Withdrawals & Fees
    {
      id: "w-1",
      category: "withdrawals",
      question: "Why can withdrawals only be requested on Saturdays?",
      answer:
        "TRIZZ enforces a scheduled Saturday settlement liquidity protocol (every Saturday from 00:00 to 23:59 WAT / UTC+1). Batching settlements into a weekly liquidity window enables optimal treasury management, lower transaction fees, and institutional compliance checks.",
    },
    {
      id: "w-2",
      category: "withdrawals",
      question: "What is the platform withdrawal processing fee?",
      answer:
        "Standard withdrawals carry a transparent 15% platform processing fee, which covers interbank settlement rails, automated fraud auditing, and treasury custody. If you opt into automated Saturday withdrawals, a 2.5% surcharge applies.",
    },
    {
      id: "w-3",
      category: "withdrawals",
      question: "What is the reference conversion rate for payouts?",
      answer:
        "The current withdrawal reference rate is 1 USD = ₦1,200 (Deposit reference rate: 1 USD = ₦1,500). All conversions and net payouts are displayed dynamically in real time before you confirm your request.",
    },
    {
      id: "w-4",
      category: "withdrawals",
      question: "What is the minimum withdrawal amount?",
      answer:
        "Minimum withdrawals depend on your account tier: Free ($5.00), T1 ($7.00), T2 ($10.00), T3 ($15.00), T4 ($20.00), T5 ($25.00), T6 ($35.00), and T7 ($50.00). Only verified available balances can be withdrawn.",
    },

    // Security & Verification
    {
      id: "s-1",
      category: "security",
      question: "Why do I need to complete KYC verification?",
      answer:
        "KYC verification prevents money laundering, automated script farming, and impersonation. It ensures that withdrawal disbursements reach the genuine identity registered on the profile.",
    },
    {
      id: "s-2",
      category: "security",
      question: "How is my personal and financial data secured?",
      answer:
        "TRIZZ utilizes a decoupled full-stack architecture. Sensitive financial keys and treasury logic reside exclusively in server-side protected environments. We never expose client secrets or store sensitive banking PINs in the browser.",
    },
  ];

  const filteredFaqs = faqs.filter((faq) => {
    const matchesCategory = activeCategory === "all" || faq.category === activeCategory;
    const matchesSearch =
      search.trim() === "" ||
      faq.question.toLowerCase().includes(search.toLowerCase()) ||
      faq.answer.toLowerCase().includes(search.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <HelpCircle className="w-3.5 h-3.5" />
          <span>Knowledge & Clear Answers</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Frequently Asked <span className="text-[#00e575]">Questions</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Everything you need to know about our earning tasks, weekly Saturday settlement windows,
          15% platform fees, and referral mechanics.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative max-w-xl mx-auto">
        <Search className="w-5 h-5 text-slate-500 absolute left-4 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search question keywords (e.g. Saturday, fees, KYC, tasks)..."
          className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-[#0d0f17] border border-slate-800 text-white text-xs sm:text-sm focus:outline-none focus:border-[#00e575]"
        />
      </div>

      {/* Category Tabs */}
      <div className="flex items-center justify-center gap-2 overflow-x-auto pb-2">
        {[
          { id: "all", label: "All Questions" },
          { id: "getting-started", label: "Getting Started" },
          { id: "earning", label: "Earning & Tasks" },
          { id: "referrals", label: "Referral Engine" },
          { id: "withdrawals", label: "Withdrawals & Fees" },
          { id: "security", label: "Security & KYC" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveCategory(tab.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeCategory === tab.id
                ? "bg-[#00e575] text-[#07080b] shadow-md shadow-[#00e575]/20"
                : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* FAQ Accordion List */}
      <div className="space-y-4">
        {filteredFaqs.length === 0 ? (
          <div className="text-center py-16 text-slate-500 text-sm">
            <p>No questions matched your search query.</p>
          </div>
        ) : (
          filteredFaqs.map((item) => {
            const isExpanded = expandedId === item.id;
            return (
              <div
                key={item.id}
                className="rounded-2xl bg-[#0d0f17] border border-slate-800 overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 cursor-pointer hover:bg-slate-900/40 transition-colors"
                >
                  <span className="font-bold text-sm sm:text-base text-white">{item.question}</span>
                  <div className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 flex-shrink-0 text-slate-400">
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-[#00e575]" /> : <ChevronDown className="w-4 h-4" />}
                  </div>
                </button>

                {isExpanded && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-xs sm:text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 font-sans">
                    {item.answer}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Still need help CTA */}
      <div className="p-8 rounded-3xl bg-[#0a0c12] border border-slate-800 text-center space-y-3">
        <h3 className="text-lg font-bold text-white">Have a question not covered here?</h3>
        <p className="text-xs text-slate-400 max-w-md mx-auto">
          Contact our specialized desk or open an official audit ticket through our support center.
        </p>
        <button
          onClick={() => onNavigate("support")}
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all cursor-pointer shadow-md shadow-[#00e575]/15"
        >
          <span>Contact Support Desk</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
