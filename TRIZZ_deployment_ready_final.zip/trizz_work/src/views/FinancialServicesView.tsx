import React from "react";
import { PageRoute } from "../types.ts";
import {
  ArrowLeftRight,
  DollarSign,
  Coins,
  TrendingUp,
  CreditCard,
  ShieldCheck,
  AlertTriangle,
  FileCheck,
  Info,
} from "lucide-react";

interface FinancialServicesViewProps {
  onNavigate: (route: PageRoute) => void;
}

export const FinancialServicesView: React.FC<FinancialServicesViewProps> = ({ onNavigate }) => {
  const services = [
    {
      title: "Digital Transfers & Settlements",
      icon: <ArrowLeftRight className="w-6 h-6 text-[#00e575]" />,
      summary: "Peer-to-peer internal account transfers and scheduled external bank settlements.",
      provider: "TRIZZ Core Ledger with Authorized Banking Settlement Gateways",
      fees: "Standard Saturday withdrawal processing: 15%. Internal verified ledger transfers: 0%.",
      risks: "Settlements are batch-processed weekly; outside the Saturday window (00:00 - 23:59 WAT), balances remain held securely in user wallet custody.",
      eligibility: "Verified accounts (KYC passed) meeting minimum tier withdrawal balance threshold.",
      regulatory: "Technology intermediary utilizing third-party licensed payment processing partners.",
    },
    {
      title: "Currency Conversion Services",
      icon: <DollarSign className="w-6 h-6 text-sky-400" />,
      summary: "Transparent exchange between United States Dollars (USD) and Nigerian Naira (NGN).",
      provider: "Institutional Liquidity Providers and Centralized Order Books",
      fees: "Published reference rates (Deposit: $1 = ₦1,500; Withdrawal: $1 = ₦1,200). Zero hidden spread.",
      risks: "Foreign currency exchange rates are subject to macro market shifts and liquidity adjustments.",
      eligibility: "Available to all registered and active account holders.",
      regulatory: "Software rate quoting layer connected to market liquidity aggregators.",
    },
    {
      title: "Digital Asset Deposits & Custody",
      icon: <Coins className="w-6 h-6 text-amber-400" />,
      summary: "Direct crypto deposits utilizing Tether USD (USDT) on BNB Smart Chain (BEP-20).",
      provider: "Self-Custodial Multi-Signature Cold Infrastructure",
      fees: "0% deposit fee. Standard network gas paid by sender.",
      risks: "Transactions executed on incorrect blockchains or without sufficient network confirmations are unrecoverable.",
      eligibility: "All registered users. Minimum deposit: $10.00.",
      regulatory: "Decentralized blockchain transaction verification; non-custodial gateway integration.",
    },
    {
      title: "Partner Trading & Market Access",
      icon: <TrendingUp className="w-6 h-6 text-rose-400" />,
      summary: "Information access, market sentiment indices, and partner trading terminal links.",
      provider: "Third-Party Regulated Brokerage APIs (External)",
      fees: "Partner-specific broker commissions and spread.",
      risks: "Capital at risk. Derivative instruments and speculative trading carry substantial loss potential. No guaranteed yields.",
      eligibility: "Requires independent registration with partner brokerages and compliance clearance.",
      regulatory: "TRIZZ does not execute trades directly. Trading access is provided strictly through licensed external partners.",
    },
    {
      title: "Merchant & Payout Payment Gateways",
      icon: <CreditCard className="w-6 h-6 text-[#00e575]" />,
      summary: "Automated batch payouts and task bounty disbursements to local bank accounts.",
      provider: "Authorized Central Bank Licensed Payment Service Providers",
      fees: "Integrated into 15% standard settlement fee; 2.5% surcharge for auto-withdrawal service.",
      risks: "Interbank network latency or destination account name mismatch may trigger automated compliance hold.",
      eligibility: "Tier 1 through Tier 7 verified account holders.",
      regulatory: "Disbursements routed strictly through authorized local payment infrastructure.",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-14">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <ShieldCheck className="w-4 h-4" />
          <span>Security-First Compliance Architecture</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Financial <span className="text-[#00e575]">Services</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Transparent disclosure of all digital financial modules, external provider rails, fee structures,
          eligibility criteria, and regulatory boundaries.
        </p>
      </div>

      {/* Services Breakdown List */}
      <div className="space-y-8">
        {services.map((svc, idx) => (
          <div
            key={idx}
            className="p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center flex-shrink-0">
                  {svc.icon}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white font-heading">{svc.title}</h3>
                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5">{svc.summary}</p>
                </div>
              </div>

              <span className="px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-slate-300 font-mono text-xs font-semibold self-start sm:self-auto">
                Audited Module
              </span>
            </div>

            {/* 5 Specific Criteria Mandated by Prompt */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1">
                <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider">
                  Provider Rails
                </span>
                <p className="font-semibold text-white leading-relaxed">{svc.provider}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1">
                <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider">
                  Fee Schedule
                </span>
                <p className="font-semibold text-[#00e575] leading-relaxed">{svc.fees}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1">
                <span className="font-mono text-[10px] text-slate-400 uppercase tracking-wider">
                  Eligibility
                </span>
                <p className="font-semibold text-slate-200 leading-relaxed">{svc.eligibility}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1 lg:col-span-2">
                <span className="font-mono text-[10px] text-amber-400 uppercase tracking-wider flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>Associated Operational Risks</span>
                </span>
                <p className="text-slate-300 leading-relaxed">{svc.risks}</p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800/80 space-y-1">
                <span className="font-mono text-[10px] text-sky-400 uppercase tracking-wider flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" />
                  <span>Regulatory Status</span>
                </span>
                <p className="text-slate-300 leading-relaxed">{svc.regulatory}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Compliance Stance */}
      <div className="p-8 rounded-3xl bg-[#080a0f] border border-slate-800 space-y-3">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#00e575]" />
          <span>Institutional Partner Assurance</span>
        </h3>
        <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
          TRIZZ operates strictly as a financial technology platform and rewards orchestrator.
          Where banking services, foreign currency conversions, or digital asset transmissions occur,
          we collaborate with authorized regional and international payment infrastructure providers.
          We do not solicit speculative deposits or offer unregulated deposit guarantees.
        </p>
      </div>
    </div>
  );
};
