import React from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, PlatformConfig, UserSession } from "../types.ts";
import {
  ArrowRight,
  ShieldCheck,
  Zap,
  Lock,
  TrendingUp,
  Clock,
  CheckCircle2,
  Layers,
  Share2,
  Wallet,
  ArrowUpRight,
  ChevronRight,
  Sparkles,
} from "lucide-react";

interface HomeViewProps {
  config: PlatformConfig | null;
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ config, user, onNavigate }) => {
  return (
    <div className="space-y-24 pb-20 overflow-hidden">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 lg:pt-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        {/* Subtle decorative background ambient glow (Anti-slop: subtle, not garish) */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-[#00e575]/5 blur-[120px] pointer-events-none rounded-full" />

        <div className="text-center max-w-4xl mx-auto space-y-8 relative z-10">
          {/* Institutional Compliance Pill */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-slate-800 text-slate-300 text-xs font-semibold tracking-wide">
            <span className="w-2 h-2 rounded-full bg-[#00e575]" />
            <span className="text-slate-400">Digital Finance & Tasks Infrastructure</span>
            <span className="text-slate-600">•</span>
            <span className="text-[#00e575] font-mono">Saturday Settlement Protocol</span>
          </div>

          {/* Prominent Emblem & Brand Title */}
          <div className="flex flex-col items-center justify-center pt-2">
            <TRIZZLogo size="hero" glow priority showTagline={false} className="mb-6" />
            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black font-heading tracking-tight text-white uppercase leading-[1.08]">
              Move. Earn. <span className="text-[#00e575]">Refer.</span>
            </h1>
            <p className="text-xs sm:text-sm font-bold uppercase tracking-[0.28em] text-slate-400 mt-2 font-mono">
              Transfer • Trade • Transact
            </p>
          </div>

          {/* Supporting Text from Specification */}
          <p className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
            A modern digital platform connecting users with earning opportunities, referral rewards,
            and eligible financial services through a simple and transparent experience.
          </p>

          {/* Primary & Secondary CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              id="hero-primary-cta"
              onClick={() => onNavigate(user ? "dashboard" : "signup")}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-xl bg-[#00e575] text-[#07080b] font-black font-heading text-base tracking-wide hover:bg-[#00ff84] transition-all transform hover:-translate-y-0.5 shadow-xl shadow-[#00e575]/25 cursor-pointer"
            >
              <span>{user ? "GO TO DASHBOARD" : "GET STARTED"}</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              id="hero-secondary-cta"
              onClick={() => onNavigate("how-it-works")}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-7 py-4 rounded-xl bg-slate-900 border border-slate-700/80 text-white font-bold text-base hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <span>HOW IT WORKS</span>
              <ChevronRight className="w-4 h-4 text-slate-400" />
            </button>
          </div>

          {/* Key Compliance Badges */}
          <div className="pt-6 flex flex-wrap items-center justify-center gap-y-3 gap-x-8 text-xs text-slate-400 font-medium">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#00e575]" />
              <span>Server-Side Fraud Validation</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-sky-400" />
              <span>Zero Client Secrets Exposure</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Scheduled Saturday Liquidity</span>
            </div>
          </div>
        </div>
      </section>

      {/* 4-Step Visual Process (Strictly adhering to Step 1-4) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <span className="text-xs font-bold text-[#00e575] uppercase tracking-widest font-mono">
            Structured Workflow
          </span>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-heading">
            How TRIZZ Works
          </h2>
          <p className="text-sm text-slate-400">
            A simple, verified 4-step process designed for absolute clarity and accountability.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Step 1 */}
          <div className="relative p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-bold text-[#00e575] bg-[#00e575]/10 px-2.5 py-1 rounded-md">
                STEP 1
              </span>
              <span className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center text-xs font-bold text-slate-400 font-mono">
                01
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#00e575] transition-colors">
              Create Your Account
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Register with your credentials and set your preferred currency. Secure onboarding without collecting unnecessary personal data.
            </p>
          </div>

          {/* Step 2 */}
          <div className="relative p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-bold text-sky-400 bg-sky-400/10 px-2.5 py-1 rounded-md">
                STEP 2
              </span>
              <span className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center text-xs font-bold text-slate-400 font-mono">
                02
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-sky-400 transition-colors">
              Complete Verification
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Submit standard identification to verify your profile. Compliance review protects the platform against automated abuse and bots.
            </p>
          </div>

          {/* Step 3 */}
          <div className="relative p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-bold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-md">
                STEP 3
              </span>
              <span className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center text-xs font-bold text-slate-400 font-mono">
                03
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              Access Eligible Opportunities
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Browse the tasks marketplace, participate in digital partner evaluations, share your referral link, and access eligible financial features.
            </p>
          </div>

          {/* Step 4 */}
          <div className="relative p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all group">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-bold text-[#00e575] bg-[#00e575]/10 px-2.5 py-1 rounded-md">
                STEP 4
              </span>
              <span className="w-8 h-8 rounded-full bg-slate-800/80 flex items-center justify-center text-xs font-bold text-slate-400 font-mono">
                04
              </span>
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-[#00e575] transition-colors">
              Track Your Rewards / Transactions
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Monitor verified credits in your wallet. Request settlements during the scheduled Saturday withdrawal window with transparent 15% processing.
            </p>
          </div>
        </div>
      </section>

      {/* Core Platform Pillars (Movement, Transactions, Referrals) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Card 1: Earning Tasks */}
          <div className="p-8 rounded-2xl bg-[#0a0c13] border border-slate-800/90 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center text-[#00e575]">
                <TrendingUp className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white font-heading">
                Backend-Validated Tasks
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Explore real partner market research, mobile UI testing, and security checkups. Every reward requires authentic completion—never automated button spam.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={() => onNavigate("earn")}
                className="inline-flex items-center gap-2 text-sm font-bold text-[#00e575] hover:text-[#00ff84] transition-colors cursor-pointer"
              >
                <span>Browse Task Marketplace</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Referral Engine */}
          <div className="p-8 rounded-2xl bg-[#0a0c13] border border-slate-800/90 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400">
                <Share2 className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white font-heading">
                Transparent Referral Engine
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Earn structured commission percentages (5% to 16%) when verified members join your network. Built with active anti-farming fraud controls.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={() => onNavigate("referral")}
                className="inline-flex items-center gap-2 text-sm font-bold text-sky-400 hover:text-sky-300 transition-colors cursor-pointer"
              >
                <span>Referral Mechanics</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 3: Wallet & Settlement */}
          <div className="p-8 rounded-2xl bg-[#0a0c13] border border-slate-800/90 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
                <Wallet className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white font-heading">
                Saturday Settlement Window
              </h3>
              <p className="text-sm text-slate-400 leading-relaxed">
                Liquidity is cleared every Saturday from 00:00 to 23:59 WAT. Reference conversions (Deposit: ₦1,500/$, Withdrawal: ₦1,200/$) are fully transparent.
              </p>
            </div>
            <div className="pt-6">
              <button
                onClick={() => onNavigate("plans")}
                className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
              >
                <span>Review T1–T7 Plans</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Product Plans Tiers Snapshot */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-b from-[#0e111a] to-[#07080b] border border-slate-800 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-3 max-w-xl text-center lg:text-left">
            <span className="text-xs font-mono text-[#00e575] font-bold uppercase tracking-wider">
              Configurable Product Tiers
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-heading">
              Structured T1 through T7 Eligibility
            </h2>
            <p className="text-sm text-slate-400 leading-relaxed">
              From T1 ($10 / ₦15,000) to T7 ($205 / ₦307,500). Clear task quotas, explicit minimum withdrawal thresholds, and higher referral bonuses without misleading investment return promises.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
            <button
              onClick={() => onNavigate("plans")}
              className="px-6 py-3.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-all shadow-lg shadow-[#00e575]/20 cursor-pointer text-center"
            >
              View All 7 Tiers
            </button>
            <button
              onClick={() => onNavigate("security")}
              className="px-6 py-3.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-semibold text-sm hover:bg-slate-800 transition-colors cursor-pointer text-center"
            >
              Security Architecture
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
