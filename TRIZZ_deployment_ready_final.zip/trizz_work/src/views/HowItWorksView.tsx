import React from "react";
import { PageRoute } from "../types.ts";
import { UserCheck, ShieldCheck, ListTodo, Wallet, ArrowRight, CheckCircle2, AlertTriangle } from "lucide-react";

interface HowItWorksViewProps {
  onNavigate: (route: PageRoute) => void;
}

export const HowItWorksView: React.FC<HowItWorksViewProps> = ({ onNavigate }) => {
  const steps = [
    {
      number: "STEP 1",
      title: "Create Your Account",
      subtitle: "Fast, minimal, and secure registration",
      icon: <UserCheck className="w-6 h-6 text-[#00e575]" />,
      description:
        "Provide your name, chosen username, verified email, and phone number. Choose your preferred display currency (USD or NGN) and accept our transparent terms of service. We do not collect extraneous personal data.",
      points: [
        "Configurable username and password protection",
        "Optional referral code support for community rewards",
        "Encrypted credential storage with rate-limiting defenses",
      ],
    },
    {
      number: "STEP 2",
      title: "Complete Verification",
      subtitle: "Know-Your-Customer (KYC) compliance",
      icon: <ShieldCheck className="w-6 h-6 text-sky-400" />,
      description:
        "Submit standard government identification (National ID, International Passport, or Driver's License) to establish platform authenticity. Verification unlocks higher task limits and protects the network against bots and multi-account abuse.",
      points: [
        "Encrypted document submission pipeline",
        "Status tracking: Verified, Pending, or Action Required",
        "Internal compliance notes remain strictly confidential",
      ],
    },
    {
      number: "STEP 3",
      title: "Access Eligible Opportunities",
      subtitle: "Participate in tasks & partner programs",
      icon: <ListTodo className="w-6 h-6 text-amber-400" />,
      description:
        "Explore the task marketplace suited to your plan tier (T1 to T7). Complete partner app evaluations, UX stress testing, market surveys, or security checks. Share your referral link with active colleagues to unlock referral bonuses.",
      points: [
        "Real-time task briefs with clear requirements and deadlines",
        "Server-side validation ensures rewards are genuine",
        "Merit-based referral commissions (5% up to 16%)",
      ],
    },
    {
      number: "STEP 4",
      title: "Track Your Rewards / Transactions",
      subtitle: "Transparent wallet ledger & Saturday payouts",
      icon: <Wallet className="w-6 h-6 text-[#00e575]" />,
      description:
        "Track your available and pending balances in real time. Every transaction is assigned an immutable UUID. When you meet your tier's minimum threshold, submit a withdrawal during the scheduled Saturday window (00:00 to 23:59 WAT).",
      points: [
        "Clear 15% standard withdrawal processing fee",
        "Predictable weekly Saturday settlement window",
        "Automated auto-withdrawal triggers available for active members",
      ],
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 space-y-16">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <span className="text-xs font-mono font-bold text-[#00e575] uppercase tracking-widest">
          Simple 4-Step Process
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          How It <span className="text-[#00e575]">Works</span>
        </h1>
        <p className="text-base text-slate-300 leading-relaxed">
          TRIZZ is engineered for straightforward navigation. From registration to Saturday liquidity settlement,
          here is how every member moves through the platform.
        </p>
      </div>

      {/* Step Cards */}
      <div className="space-y-8">
        {steps.map((step, idx) => (
          <div
            key={idx}
            className="p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700/80 transition-all flex flex-col md:flex-row gap-6 sm:gap-8 items-start"
          >
            {/* Left badge & icon */}
            <div className="flex-shrink-0 flex items-center md:flex-col gap-3">
              <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                {step.icon}
              </div>
              <span className="px-3 py-1 rounded-full bg-slate-800 border border-slate-700 text-slate-300 font-mono text-xs font-bold">
                {step.number}
              </span>
            </div>

            {/* Right content */}
            <div className="flex-1 space-y-3">
              <div>
                <h3 className="text-xl sm:text-2xl font-bold text-white font-heading">
                  {step.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 font-medium">{step.subtitle}</p>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{step.description}</p>

              <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-2">
                {step.points.map((pt, pIdx) => (
                  <div key={pIdx} className="flex items-center gap-2 text-xs text-slate-400">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00e575] flex-shrink-0" />
                    <span>{pt}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Fraud & Settlement Notice */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[#0a0c12] border border-slate-800 flex items-start gap-4">
        <AlertTriangle className="w-6 h-6 text-amber-400 flex-shrink-0 mt-1" />
        <div className="space-y-1.5 text-xs text-slate-300 leading-relaxed">
          <h4 className="font-bold text-white text-sm">Server-Side Validation Mandate</h4>
          <p>
            TRIZZ never automatically credits rewards simply because a button was clicked. All qualifying task actions, survey submissions, and referral credits are checked against backend anti-fraud heuristics before ledger release.
          </p>
        </div>
      </div>

      {/* CTA Box */}
      <div className="text-center pt-4">
        <button
          onClick={() => onNavigate("signup")}
          className="inline-flex items-center gap-3 px-8 py-4 rounded-xl bg-[#00e575] text-[#07080b] font-black font-heading text-sm sm:text-base tracking-wide hover:bg-[#00ff84] transition-all shadow-xl shadow-[#00e575]/25 cursor-pointer"
        >
          <span>START WITH STEP 1 — REGISTER</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
