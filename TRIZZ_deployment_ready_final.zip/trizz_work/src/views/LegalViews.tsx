import React, { useState } from "react";
import { PageRoute } from "../types.ts";
import { ShieldAlert, FileText, Lock, AlertTriangle, CheckCircle2 } from "lucide-react";

interface LegalViewsProps {
  initialTab?: "terms" | "privacy" | "risk-disclosure";
  onNavigate: (route: PageRoute) => void;
}

export const LegalViews: React.FC<LegalViewsProps> = ({
  initialTab = "terms",
  onNavigate,
}) => {
  const [activeTab, setActiveTab] = useState<"terms" | "privacy" | "risk-disclosure">(initialTab);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="text-xs font-mono font-bold text-[#00e575] uppercase tracking-widest">
          Regulatory & Legal Governance
        </span>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Legal & <span className="text-[#00e575]">Compliance</span>
        </h1>
        <p className="text-sm text-slate-300">
          Transparent operational contracts, data handling covenants, and comprehensive risk disclosures.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-center gap-2 border-b border-slate-800 pb-4">
        <button
          onClick={() => setActiveTab("terms")}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "terms"
              ? "bg-[#00e575] text-[#07080b] shadow-md shadow-[#00e575]/20"
              : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
          }`}
        >
          Terms & Conditions
        </button>

        <button
          onClick={() => setActiveTab("privacy")}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "privacy"
              ? "bg-[#00e575] text-[#07080b] shadow-md shadow-[#00e575]/20"
              : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
          }`}
        >
          Privacy Policy
        </button>

        <button
          onClick={() => setActiveTab("risk-disclosure")}
          className={`px-5 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeTab === "risk-disclosure"
              ? "bg-[#00e575] text-[#07080b] shadow-md shadow-[#00e575]/20"
              : "bg-slate-900 text-slate-400 hover:text-white border border-slate-800"
          }`}
        >
          Risk Disclosure Statement
        </button>
      </div>

      {/* Content Area */}
      <div className="p-8 sm:p-12 rounded-3xl bg-[#0d0f17] border border-slate-800 text-xs sm:text-sm text-slate-300 space-y-8 leading-relaxed font-sans">
        {activeTab === "terms" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <FileText className="w-6 h-6 text-[#00e575]" />
              <div>
                <h2 className="text-xl font-bold text-white font-heading">Terms & Conditions of Use</h2>
                <span className="text-[11px] text-slate-500 font-mono">Last Revised: Official Platform Launch</span>
              </div>
            </div>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">1. Agreement to Terms</h3>
              <p>
                By creating an account, accessing the task marketplace, participating in the referral program, or utilizing wallet services on TRIZZ ("Platform"), you expressly agree to abide by these Terms and Conditions and all incorporated guidelines.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">2. Earning Opportunities & Validation Rules</h3>
              <p>
                Rewards associated with application testing, consumer surveys, market analyses, and partner engagements are credited strictly upon genuine fulfillment of task requirements and server-side verification. The platform reserves the right to audit, reject, or reverse reward credits in cases of script automation, duplicate accounts, or falsified proof.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">3. Payout & Saturday Liquidity Policy</h3>
              <p>
                Withdrawals are batched and executed exclusively during the Saturday settlement window (00:00 to 23:59 WAT / UTC+1). All external withdrawals are subject to the standard 15% platform processing fee, applicable minimum tier thresholds, and the published reference conversion rates.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">4. Referral Program Standards & Anti-Abuse</h3>
              <p>
                Referral bonuses are earned when invited real users complete qualifying actions or plan upgrades. Any member found engaging in self-referral schemes, multi-account device manipulation, virtual machine spoofing, or automated referral farming will face immediate permanent account termination and forfeiture of unverified pending balances.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">5. Account Termination & Liability Limit</h3>
              <p>
                TRIZZ reserves the right to suspend or terminate accounts that violate security protocols, present forged identification documents, or compromise platform infrastructure. In no event shall TRIZZ or its operators be liable for indirect, incidental, or consequential damages resulting from platform use.
              </p>
            </section>
          </div>
        )}

        {activeTab === "privacy" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <Lock className="w-6 h-6 text-sky-400" />
              <div>
                <h2 className="text-xl font-bold text-white font-heading">Privacy & Data Governance Policy</h2>
                <span className="text-[11px] text-slate-500 font-mono">Last Revised: Official Platform Launch</span>
              </div>
            </div>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">1. Information We Collect</h3>
              <p>
                We collect only the essential information needed to provision accounts, ensure KYC compliance, and disburse rewards: full name, email address, phone number, username, preferred currency, and government identity documents for verified tier participants.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">2. How Information is Used</h3>
              <p>
                Data is utilized to: (a) authenticate sessions securely; (b) execute server-side reward payouts and settlement ledger entries; (c) satisfy international anti-money laundering (AML) and Know-Your-Customer (KYC) standards; and (d) detect and prevent fraud or automated abuse.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">3. Third-Party Data Sharing</h3>
              <p>
                We do not sell personal data to advertisers. Information may be securely transmitted to authorized payment gateway partners and banking networks solely to complete legitimate user-requested withdrawal disbursements.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">4. Data Encryption & Retention</h3>
              <p>
                All sensitive user documents and session tokens are encrypted in transit via TLS 1.3 and at rest with AES-256 standard encryption. Account data is retained for the duration of the active membership and in accordance with legal record-keeping obligations.
              </p>
            </section>
          </div>
        )}

        {activeTab === "risk-disclosure" && (
          <div className="space-y-6">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <AlertTriangle className="w-6 h-6 text-amber-400" />
              <div>
                <h2 className="text-xl font-bold text-white font-heading">Comprehensive Risk Disclosure Statement</h2>
                <span className="text-[11px] text-slate-500 font-mono">Mandatory Financial & Regulatory Notice</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs">
              <strong className="block font-bold text-white mb-1">Notice to All Participants:</strong>
              TRIZZ is NOT a bank, a registered deposit-taking institution, a collective investment scheme, a hedge fund, or a gambling service. Please read this disclosure carefully before activating any product tier or depositing funds.
            </div>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">1. No Guaranteed Income or Investment Returns</h3>
              <p>
                TRIZZ does not make claims of guaranteed profits, guaranteed income, risk-free returns, or passive capital appreciation. Product tiers (T1 through T7) grant operational allowances, task capacities, and referral multiplier structures—they are not interest-bearing investment securities.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">2. Currency & Conversion Fluctuation Risk</h3>
              <p>
                Digital conversions between United States Dollars (USD) and Nigerian Naira (NGN) utilize published reference platform rates. Macroeconomic conditions, inflation, and foreign exchange market fluctuations may impact the purchasing power of converted rewards.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">3. Digital Asset & Blockchain Risk</h3>
              <p>
                Cryptocurrency transactions (such as USDT on the BNB Smart Chain BEP-20) are irreversible. Sending assets to incorrect wallet addresses, selecting unsupported networks, or failing to maintain private key security will result in permanent, unrecoverable capital loss.
              </p>
            </section>

            <section className="space-y-3">
              <h3 className="text-base font-bold text-white">4. Operational & Weekly Liquidity Window Contingency</h3>
              <p>
                Withdrawals are strictly processed during the Saturday settlement window (00:00 to 23:59 WAT). Unforeseen technical maintenance, interbank settlement delays, or third-party banking downtime may temporarily affect disbursement timing.
              </p>
            </section>
          </div>
        )}
      </div>
    </div>
  );
};
