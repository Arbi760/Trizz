import React, { useState, useEffect } from "react";
import { PageRoute, PlanItem, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import {
  Layers,
  Check,
  ShieldCheck,
  ArrowRight,
  Sparkles,
  AlertCircle,
  HelpCircle,
} from "lucide-react";

interface PlansViewProps {
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
  onRefreshUser?: () => Promise<void>;
}

export const PlansView: React.FC<PlansViewProps> = ({ user, onNavigate, onRefreshUser }) => {
  const [plans, setPlans] = useState<PlanItem[]>([]);
  const [conversionText, setConversionText] = useState("1 USD = ₦1,500");
  const [loading, setLoading] = useState(true);
  const [subscribingTier, setSubscribingTier] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    api
      .getPlans()
      .then((res) => {
        setPlans(res?.plans || []);
        if (res?.referenceConversion) {
          setConversionText(res.referenceConversion);
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  const handleSubscribe = async (tier: string) => {
    if (!user) {
      onNavigate("login");
      return;
    }

    try {
      setSubscribingTier(tier);
      setFeedback(null);
      const res = await api.subscribePlan(tier);
      setFeedback({ type: "success", text: res.message });
      if (onRefreshUser) {
        await onRefreshUser();
      }
    } catch (err: any) {
      setFeedback({ type: "error", text: err.message });
    } finally {
      setSubscribingTier(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <span>Centralized Reference Rate: {conversionText}</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          T1–T7 Product <span className="text-[#00e575]">Tiers</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Transparent platform eligibility tiers. Scale your daily task allocation, increase direct referral commissions,
          and configure your baseline Saturday withdrawal thresholds.
        </p>
      </div>

      {feedback && (
        <div
          className={`max-w-2xl mx-auto p-4 rounded-2xl text-xs sm:text-sm font-medium flex items-center justify-between gap-3 ${
            feedback.type === "success"
              ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
              : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
          }`}
        >
          <span>{feedback.text}</span>
          {feedback.type === "error" && (
            <button
              onClick={() => onNavigate("wallet")}
              className="px-3 py-1.5 rounded-lg bg-rose-500 text-white text-xs font-bold hover:bg-rose-600 transition-colors whitespace-nowrap cursor-pointer"
            >
              Deposit Funds
            </button>
          )}
        </div>
      )}

      {/* Grid of T1 - T7 Plans */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const isCurrentPlan = user?.planTier === plan.tier;
          return (
            <div
              key={plan.id}
              className={`p-6 sm:p-7 rounded-3xl transition-all flex flex-col justify-between relative ${
                plan.popular
                  ? "bg-[#0f131f] border-2 border-[#00e575] shadow-xl shadow-[#00e575]/10"
                  : "bg-[#0d0f17] border border-slate-800 hover:border-slate-700"
              }`}
            >
              {plan.popular && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-[#00e575] text-[#07080b] font-bold text-[10px] font-mono uppercase tracking-wider">
                  MOST POPULAR
                </span>
              )}

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-slate-400 uppercase">
                    {plan.tier}
                  </span>
                  {isCurrentPlan && (
                    <span className="px-2.5 py-0.5 rounded-full bg-[#00e575]/10 text-[#00e575] text-[10px] font-mono font-bold">
                      ACTIVE TIER
                    </span>
                  )}
                </div>

                <div>
                  <h3 className="text-lg font-bold text-white font-heading">{plan.name}</h3>
                  <div className="mt-2 flex items-baseline gap-1.5">
                    <span className="text-3xl font-black text-white font-mono">${plan.priceUsd}</span>
                    <span className="text-xs text-slate-400 font-mono">
                      / ₦{plan.priceNgn.toLocaleString()}
                    </span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800/80 pt-3">
                  {plan.description}
                </p>

                {/* Key Metrics */}
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Min Withdrawal:</span>
                    <span className="font-mono text-white font-bold">
                      ${plan.minWithdrawalUsd} (₦{plan.minWithdrawalNgn.toLocaleString()})
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Daily Task Cap:</span>
                    <span className="font-mono text-white font-bold">{plan.dailyTaskCap} tasks</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Referral Commission:</span>
                    <span className="font-mono text-[#00e575] font-bold">{plan.referralBonusPercentage}%</span>
                  </div>
                </div>

                {/* Feature List */}
                <ul className="space-y-2 pt-2 text-xs text-slate-300">
                  {plan.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-[#00e575] flex-shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <div className="pt-6">
                {isCurrentPlan ? (
                  <button
                    disabled
                    className="w-full py-3 rounded-xl bg-slate-800 text-slate-400 text-xs font-bold cursor-not-allowed text-center"
                  >
                    Current Plan
                  </button>
                ) : (
                  <button
                    onClick={() => handleSubscribe(plan.tier)}
                    disabled={subscribingTier === plan.tier}
                    className={`w-full py-3 rounded-xl font-bold text-xs transition-all cursor-pointer text-center ${
                      plan.popular
                        ? "bg-[#00e575] text-[#07080b] hover:bg-[#00ff84] shadow-md shadow-[#00e575]/20"
                        : "bg-slate-800 text-white hover:bg-slate-700"
                    }`}
                  >
                    {subscribingTier === plan.tier
                      ? "Verifying Balance..."
                      : `Activate ${plan.tier} ($${plan.priceUsd})`}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mandatory No Fixed Return Guarantee Notice */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#090b10] border border-slate-800 text-xs text-slate-400 space-y-2 leading-relaxed">
        <p className="font-bold text-slate-200">
          Strict Regulatory & Financial Presentation Notice:
        </p>
        <p>
          Product tiers T1 through T7 represent access classifications and operational quotas for digital tasks,
          marketplace partner workflows, and referral multipliers. Tier activations DO NOT constitute an investment contract,
          fixed yield product, deposit-taking account, or guaranteed income stream.
        </p>
        <p>
          Withdrawals are processed exclusively subject to available verified wallet balances during the scheduled Saturday
          settlement cycle, adhering to each tier's minimum threshold and the 15% platform processing fee.
        </p>
      </div>
    </div>
  );
};
