import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, ReferralData, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import {
  Share2,
  Copy,
  Check,
  Users,
  Award,
  Clock,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  ExternalLink,
} from "lucide-react";

interface ReferralViewProps {
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
}

export const ReferralView: React.FC<ReferralViewProps> = ({ user, onNavigate }) => {
  const [data, setData] = useState<ReferralData | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      api
        .getReferrals()
        .then((res) => setData(res))
        .catch((err) => console.error(err))
        .finally(() => setLoading(false));
    } else {
      setLoading(false);
    }
  }, [user]);

  const copyToClipboard = (text: string, isCode = false) => {
    navigator.clipboard.writeText(text);
    if (isCode) {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  const handleShare = async () => {
    if (!data) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Join me on TRIZZ — Move. Earn. Refer.",
          text: `Use my referral code ${data.referralCode} to join TRIZZ for transparent digital earning and verified rewards.`,
          url: data.referralLink,
        });
      } catch {
        // Fallback
        copyToClipboard(data.referralLink);
      }
    } else {
      copyToClipboard(data.referralLink);
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center mx-auto text-[#00e575]">
          <Share2 className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-heading">
          TRIZZ Referral Program
        </h1>
        <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
          Sign in or register to access your personal referral link, track downline activities,
          and earn verified commissions on plan upgrades and task completions.
        </p>
        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate("signup")}
            className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-colors"
          >
            Create Account
          </button>
          <button
            onClick={() => onNavigate("login")}
            className="px-6 py-3 rounded-xl bg-slate-900 border border-slate-700 text-white font-semibold text-sm hover:bg-slate-800 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] font-mono font-bold text-xs">
              COMMISSION ENGINE
            </span>
            <span className="text-xs text-slate-400">Merit-Based Partner Growth</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-heading uppercase">
            Referral <span className="text-[#00e575]">Dashboard</span>
          </h1>
          <p className="text-sm text-slate-300 max-w-xl">
            Invite colleagues and builders to TRIZZ. Earn structured commissions on verified member upgrades
            and completed qualifying actions.
          </p>
        </div>

        {/* Current tier rate badge */}
        <div className="p-3.5 rounded-2xl bg-[#0d0f17] border border-slate-800 flex items-center gap-4">
          <div>
            <p className="text-[10px] text-slate-400 font-mono uppercase">Direct Commission Rate</p>
            <p className="text-xl font-black text-[#00e575] font-mono">
              {data?.tierCommissionRate || "8.5%"}
            </p>
          </div>
          <button
            onClick={() => onNavigate("plans")}
            className="text-xs font-bold text-slate-300 hover:text-white underline cursor-pointer"
          >
            Upgrade Tier
          </button>
        </div>
      </div>

      {/* Referral Link & Code Box */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Box 1: Referral Link */}
        <div className="p-6 sm:p-7 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-300 tracking-wider">
              My Referral Link
            </span>
            <span className="text-[10px] text-[#00e575] font-mono font-bold">1-CLICK TRACKING</span>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300 overflow-hidden">
            <span className="truncate flex-1 text-slate-200">
              {data?.referralLink || `https://trizz.io/register?ref=${user.referralCode}`}
            </span>
            <button
              onClick={() => copyToClipboard(data?.referralLink || `https://trizz.io/register?ref=${user.referralCode}`)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer transition-colors flex-shrink-0"
              title="Copy Link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-[#00e575]" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              onClick={() => copyToClipboard(data?.referralLink || `https://trizz.io/register?ref=${user.referralCode}`)}
              className="flex-1 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              {copiedLink ? <Check className="w-4 h-4 text-[#00e575]" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? "LINK COPIED" : "COPY LINK"}</span>
            </button>
            <button
              onClick={handleShare}
              className="flex-1 py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#00e575]/15"
            >
              <Share2 className="w-4 h-4" />
              <span>SHARE LINK</span>
            </button>
          </div>
        </div>

        {/* Box 2: Referral Code */}
        <div className="p-6 sm:p-7 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase text-slate-300 tracking-wider">
              My Referral Code
            </span>
            <span className="text-[10px] text-slate-400 font-mono">MANUAL SIGNUP</span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="text-xl font-black text-white font-mono tracking-wider">
              {data?.referralCode || user.referralCode}
            </span>
            <button
              onClick={() => copyToClipboard(data?.referralCode || user.referralCode, true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 cursor-pointer transition-colors"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-[#00e575]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCode ? "Copied" : "Copy Code"}</span>
            </button>
          </div>

          <p className="text-xs text-slate-400 leading-relaxed pt-1">
            New members can enter this code manually in the optional referral code field during registration.
          </p>
        </div>
      </div>

      {/* Referral KPI Metrics Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="p-5 sm:p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Total Referrals</span>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            {data?.totalReferrals ?? 0}
          </p>
          <span className="text-[10px] text-slate-500">Registered users in tree</span>
        </div>

        <div className="p-5 sm:p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Active Referrals</span>
          <p className="text-2xl sm:text-3xl font-black text-sky-400 font-mono">
            {data?.activeReferrals ?? 0}
          </p>
          <span className="text-[10px] text-slate-500">Completed KYC / Upgraded</span>
        </div>

        <div className="p-5 sm:p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Pending Rewards</span>
          <p className="text-2xl sm:text-3xl font-black text-amber-400 font-mono">
            ${(data?.pendingRewardsUsd ?? 0).toFixed(2)}
          </p>
          <span className="text-[10px] text-slate-500">
            ₦{(data?.pendingRewardsNgn ?? 0).toLocaleString()} under verification
          </span>
        </div>

        <div className="p-5 sm:p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 space-y-1">
          <span className="text-[11px] font-mono text-slate-400 uppercase">Approved Rewards</span>
          <p className="text-2xl sm:text-3xl font-black text-[#00e575] font-mono">
            ${(data?.approvedRewardsUsd ?? 0).toFixed(2)}
          </p>
          <span className="text-[10px] text-slate-500">
            ₦{(data?.approvedRewardsNgn ?? 0).toLocaleString()} credited to wallet
          </span>
        </div>
      </div>

      {/* Referral History Table */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white font-heading">Referral History</h3>
          <span className="text-xs text-slate-400 font-mono">Auditable Ledger</span>
        </div>

        <div className="rounded-2xl bg-[#0d0f17] border border-slate-800 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="px-5 py-3">Date</th>
                  <th className="px-5 py-3">Referred User</th>
                  <th className="px-5 py-3">Qualifying Action</th>
                  <th className="px-5 py-3">Commission Reward</th>
                  <th className="px-5 py-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {data?.history && data.history.length > 0 ? (
                  data.history.map((row) => (
                    <tr key={row.id} className="hover:bg-slate-800/30 transition-colors">
                      <td className="px-5 py-3.5 font-mono text-slate-400 whitespace-nowrap">
                        {new Date(row.createdAt).toLocaleDateString()}
                      </td>
                      <td className="px-5 py-3.5 font-bold text-white whitespace-nowrap">
                        @{row.referredUsername}
                      </td>
                      <td className="px-5 py-3.5 text-slate-300">{row.qualifyingAction}</td>
                      <td className="px-5 py-3.5 font-bold font-mono text-[#00e575] whitespace-nowrap">
                        +${row.rewardUsd.toFixed(2)}{" "}
                        <span className="text-[10px] text-slate-500">
                          (₦{row.rewardNgn.toLocaleString()})
                        </span>
                      </td>
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        {row.status === "approved" ? (
                          <span className="px-2 py-0.5 rounded bg-[#00e575]/10 text-[#00e575] text-[11px] font-mono font-bold">
                            Approved
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[11px] font-mono font-bold">
                            Pending Audit
                          </span>
                        )}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-5 py-14 text-center">
                      <div className="flex flex-col items-center justify-center max-w-sm mx-auto space-y-3">
                        <div className="p-3 rounded-2xl bg-[#0a0d14] border border-slate-800/80">
                          <TRIZZLogo size="sm" glow />
                        </div>
                        <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
                          No Referrals Yet
                        </h4>
                        <p className="text-xs text-slate-400 leading-relaxed">
                          Share your referral link or code above to invite collaborators, friends, and colleagues to TRIZZ.
                        </p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Strict Anti-Abuse & Fraud Mitigation Notice */}
      <div className="p-6 rounded-2xl bg-[#0a0c12] border border-slate-800 flex items-start gap-4">
        <ShieldCheck className="w-6 h-6 text-sky-400 flex-shrink-0 mt-1" />
        <div className="space-y-1.5 text-xs text-slate-400 leading-relaxed">
          <h4 className="font-bold text-slate-200 text-sm">Server-Side Anti-Farming & Abuse Protections</h4>
          <p>
            To maintain regulatory integrity, TRIZZ automatically detects self-referrals, duplicate IP clusters,
            virtual machine farming, and automated bot networks. Referral commissions are strictly unlocked through genuine
            qualifying events and compliance-cleared profiles.
          </p>
        </div>
      </div>
    </div>
  );
};
