import React from "react";
import { PageRoute } from "../types.ts";
import {
  ShieldCheck,
  Lock,
  Server,
  EyeOff,
  Cpu,
  Fingerprint,
  AlertTriangle,
  KeyRound,
  FileCheck2,
} from "lucide-react";

interface SecurityViewProps {
  onNavigate: (route: PageRoute) => void;
}

export const SecurityView: React.FC<SecurityViewProps> = ({ onNavigate }) => {
  const securityLayers = [
    {
      title: "Server-Authoritative Financial Execution",
      icon: <Server className="w-6 h-6 text-[#00e575]" />,
      description:
        "The browser is strictly a rendering viewport. All balance deductions, task completions, reward calculations, Saturday settlement eligibility, and currency conversions are verified and executed inside isolated server environments. Client-side manipulation of financial states is mathematically impossible.",
    },
    {
      title: "Zero Client Secrets Exposure",
      icon: <EyeOff className="w-6 h-6 text-sky-400" />,
      description:
        "API keys, administrative credentials, treasury private keys, and payout webhook signing secrets are permanently shielded behind proxy routes. No third-party API secret or administrative authorization header is ever transmitted or rendered in the browser bundle.",
    },
    {
      title: "Anti-Fraud & Sybil Defense Heuristics",
      icon: <Fingerprint className="w-6 h-6 text-amber-400" />,
      description:
        "Automated bot detection continuously monitors referral graphs, click intervals, browser user agents, and IP cluster anomalies. Self-referrals, automated script submissions, and virtual machine farms are intercepted before ledger settlement.",
    },
    {
      title: "Granular Role-Based Decoupling",
      icon: <Lock className="w-6 h-6 text-rose-400" />,
      description:
        "The public platform architecture is deliberately quarantined from internal administrative controls. Administrative capabilities, user overrides, and treasury adjustments require segregated token authentication and cannot be accessed via the public client interface.",
    },
    {
      title: "Session Cryptography & Token Hygiene",
      icon: <KeyRound className="w-6 h-6 text-indigo-400" />,
      description:
        "Authentication uses cryptographically random session tokens with automated expiration, constant-time validation comparisons to mitigate timing attacks, and strict cross-origin resource sharing (CORS) enforcement.",
    },
    {
      title: "Auditable Immutable Ledger",
      icon: <FileCheck2 className="w-6 h-6 text-[#00e575]" />,
      description:
        "Every transaction—from a ₦1,500 task reward to a Saturday bank disbursement—generates an immutable UUID audit record. Ledger state changes must balance across double-entry debits and credits.",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-14">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <ShieldCheck className="w-4 h-4" />
          <span>Institutional Trust & Engineering</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Security <span className="text-[#00e575]">Architecture</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          How TRIZZ protects user treasury balances, ensures fraud-free task validation,
          and isolates core financial state from public web vulnerabilities.
        </p>
      </div>

      {/* Security Pillars Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {securityLayers.map((layer, idx) => (
          <div
            key={idx}
            className="p-7 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                {layer.icon}
              </div>
              <h3 className="text-lg font-bold text-white font-heading">{layer.title}</h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
                {layer.description}
              </p>
            </div>
            <div className="pt-4 border-t border-slate-800/80">
              <span className="text-[10px] font-mono uppercase text-[#00e575] font-bold">
                ENFORCED SYSTEM-WIDE
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Best Practices for Account Security */}
      <div className="p-8 sm:p-10 rounded-3xl bg-[#0a0c12] border border-slate-800 space-y-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white font-heading flex items-center gap-2">
            <Lock className="w-5 h-5 text-sky-400" />
            <span>Member Best Practices</span>
          </h2>
          <p className="text-xs text-slate-400">Essential habits to maintain complete account safety.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <span className="font-bold text-white block">Unique Passwords</span>
            <p className="text-slate-400 leading-relaxed">
              Use a distinct, complex passphrase not shared with other web applications or email accounts.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <span className="font-bold text-white block">Official Channels Only</span>
            <p className="text-slate-400 leading-relaxed">
              TRIZZ staff will never ask for your password or direct you to send cryptocurrency to unverified addresses.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-1.5">
            <span className="font-bold text-white block">Accurate KYC Details</span>
            <p className="text-slate-400 leading-relaxed">
              Ensure your destination bank account name matches your registered identity to avoid compliance settlement holds.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
