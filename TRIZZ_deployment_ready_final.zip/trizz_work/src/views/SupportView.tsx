import React, { useState } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import {
  LifeBuoy,
  Mail,
  MessageSquare,
  Send,
  Clock,
  CheckCircle2,
  HelpCircle,
  ShieldCheck,
  PhoneCall,
  ExternalLink,
} from "lucide-react";

interface SupportViewProps {
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
}

export const SupportView: React.FC<SupportViewProps> = ({ user, onNavigate }) => {
  const [name, setName] = useState(user?.fullName || "");
  const [email, setEmail] = useState(user?.email || "");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("general");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [ticketFeedback, setTicketFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !subject.trim() || !message.trim()) {
      setTicketFeedback({ type: "error", text: "Please fill out all required fields." });
      return;
    }

    try {
      setSubmitting(true);
      setTicketFeedback(null);
      const res = await api.submitSupportTicket({
        name,
        email,
        subject,
        category,
        message,
      });
      setTicketFeedback({ type: "success", text: res.message });
      setSubject("");
      setMessage("");
    } catch (err: any) {
      setTicketFeedback({ type: "error", text: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const channels = [
    {
      name: "Official Telegram Support",
      handle: "@trizz_official_support",
      link: "https://t.me/trizz_official_support",
      icon: <Send className="w-5 h-5 text-sky-400" />,
      note: "Instant ticket triage & status queries",
    },
    {
      name: "WhatsApp Community Desk",
      handle: "+234 812 000 TRIZZ",
      link: "https://wa.me/2348120008749",
      icon: <MessageSquare className="w-5 h-5 text-[#00e575]" />,
      note: "Direct representative assistance",
    },
    {
      name: "Compliance & Security Desk",
      handle: "support@trizz.io",
      link: "mailto:support@trizz.io",
      icon: <Mail className="w-5 h-5 text-amber-400" />,
      note: "Official KYC & transaction reviews",
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-4 flex flex-col items-center">
        <TRIZZLogo size="md" glow showTagline={false} className="mb-1" />
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs font-mono text-[#00e575]">
          <LifeBuoy className="w-3.5 h-3.5" />
          <span>Support & Member Care</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-black text-white font-heading uppercase tracking-tight">
          Contact <span className="text-[#00e575]">Support</span>
        </h1>
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
          Need assistance with verification, Saturday settlements, or task validations?
          Our specialized support team is here to assist you through verified channels.
        </p>
      </div>

      {/* Support Channels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {channels.map((ch, idx) => (
          <a
            key={idx}
            href={ch.link}
            target="_blank"
            rel="noopener noreferrer"
            className="p-6 sm:p-7 rounded-3xl bg-[#0d0f17] border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between group cursor-pointer"
          >
            <div className="space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center">
                {ch.icon}
              </div>
              <div>
                <h3 className="text-base font-bold text-white group-hover:text-[#00e575] transition-colors">
                  {ch.name}
                </h3>
                <p className="text-xs font-mono text-slate-400 mt-1">{ch.handle}</p>
                <p className="text-xs text-slate-500 mt-2 leading-relaxed">{ch.note}</p>
              </div>
            </div>

            <div className="pt-6 flex items-center justify-between text-xs text-[#00e575] font-bold">
              <span>Connect Now</span>
              <ExternalLink className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
            </div>
          </a>
        ))}
      </div>

      {/* Operational Hours Banner */}
      <div className="p-6 rounded-2xl bg-[#0a0c12] border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-3">
          <Clock className="w-5 h-5 text-amber-400 flex-shrink-0" />
          <div>
            <span className="font-bold text-white block">Official Support Hours</span>
            <span className="text-slate-400">
              Monday through Sunday: 08:00 to 22:00 WAT (West Africa Time / UTC+1)
            </span>
          </div>
        </div>
        <button
          onClick={() => onNavigate("faq")}
          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 font-semibold cursor-pointer"
        >
          Check FAQs First
        </button>
      </div>

      {/* Support Ticket Submission Form */}
      <div className="max-w-3xl mx-auto p-8 sm:p-10 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-6">
        <div className="space-y-1">
          <h2 className="text-xl font-bold text-white font-heading">Submit an Audit / Support Ticket</h2>
          <p className="text-xs text-slate-400">
            For complex account inquiries, transaction investigations, or verification reviews.
          </p>
        </div>

        {ticketFeedback && (
          <div
            className={`p-4 rounded-2xl text-xs font-medium ${
              ticketFeedback.type === "success"
                ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
                : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
            }`}
          >
            {ticketFeedback.text}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Your Name</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Full Name"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
              />
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Email Address *</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575] cursor-pointer"
              >
                <option value="general">General Inquiries</option>
                <option value="verification">Verification & KYC</option>
                <option value="deposit">Deposit Confirmation</option>
                <option value="withdrawal">Saturday Settlement Queue</option>
                <option value="task">Task Evaluation Dispute</option>
                <option value="referral">Referral Attribution</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Subject *</label>
              <input
                type="text"
                required
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Brief summary of issue"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-slate-300 font-medium">Detailed Message *</label>
            <textarea
              required
              rows={4}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Include transaction references, task IDs, or specific dates where relevant..."
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
            />
          </div>

          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#00e575]/15"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{submitting ? "Transmitting Ticket..." : "Submit Ticket to Support Team"}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
