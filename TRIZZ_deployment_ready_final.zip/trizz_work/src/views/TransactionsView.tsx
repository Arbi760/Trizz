import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession, WalletTransaction } from "../types.ts";
import { api } from "../services/api.ts";
import {
  History,
  Copy,
  Check,
  Search,
  Filter,
  ArrowDownToLine,
  ArrowUpFromLine,
  Gift,
  Share2,
  CheckSquare,
  Layers,
  RefreshCw,
} from "lucide-react";

interface TransactionsViewProps {
  user: UserSession | null;
  onNavigate: (route: PageRoute) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({ user, onNavigate }) => {
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>("");
  const [selectedStatus, setSelectedStatus] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");

  const fetchTransactions = async () => {
    try {
      setLoading(true);
      const data = await api.getTransactions({
        type: selectedType || undefined,
        status: selectedStatus || undefined,
        search: searchQuery || undefined,
      });
      setTransactions(data?.transactions || []);
    } catch (err: any) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchTransactions();
    } else {
      setLoading(false);
    }
  }, [user, selectedType, selectedStatus]);

  const copyRef = (ref: string) => {
    navigator.clipboard.writeText(ref);
    setCopiedId(ref);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "deposit":
        return <ArrowDownToLine className="w-4 h-4 text-[#00e575]" />;
      case "withdrawal":
        return <ArrowUpFromLine className="w-4 h-4 text-sky-400" />;
      case "referral":
        return <Share2 className="w-4 h-4 text-amber-400" />;
      case "task":
        return <CheckSquare className="w-4 h-4 text-[#00e575]" />;
      case "plan_purchase":
        return <Layers className="w-4 h-4 text-indigo-400" />;
      default:
        return <Gift className="w-4 h-4 text-slate-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-[#00e575]/10 text-[#00e575] text-[10px] font-mono font-bold uppercase">
            Completed
          </span>
        );
      case "pending":
      case "processing":
      case "under_review":
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-[10px] font-mono font-bold uppercase">
            {status.replace("_", " ")}
          </span>
        );
      case "failed":
      case "rejected":
      case "cancelled":
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-400 text-[10px] font-mono font-bold uppercase">
            {status}
          </span>
        );
      default:
        return (
          <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono font-bold uppercase">
            {status}
          </span>
        );
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center mx-auto text-[#00e575]">
          <History className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-heading">Transactions Ledger</h1>
        <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
          Please sign in to inspect your auditable transaction ledger and payment confirmations.
        </p>
        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate("login")}
            className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-colors cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] font-mono font-bold text-xs">
              IMMUTABLE RECORD
            </span>
            <span className="text-xs text-slate-400">UUID Tracking & Audit Trail</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-heading uppercase">
            Transaction <span className="text-[#00e575]">Ledger</span>
          </h1>
          <p className="text-sm text-slate-300 max-w-xl">
            Complete, timestamped history of deposits, task compensations, referrals, and bank payouts.
          </p>
        </div>

        <button
          onClick={fetchTransactions}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white text-xs font-mono transition-colors cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Ledger</span>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-2xl bg-[#0d0f17] border border-slate-800 flex flex-col md:flex-row items-center gap-4">
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && fetchTransactions()}
            placeholder="Search by reference ID or description..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-[#00e575]"
          />
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="w-4 h-4 text-slate-500 flex-shrink-0" />
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-[#00e575] cursor-pointer"
          >
            <option value="">All Types</option>
            <option value="deposit">Deposits</option>
            <option value="withdrawal">Withdrawals</option>
            <option value="reward">Task Rewards</option>
            <option value="referral">Referrals</option>
            <option value="plan_purchase">Plan Upgrades</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 text-xs focus:outline-none focus:border-[#00e575] cursor-pointer"
          >
            <option value="">All Statuses</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="under_review">Under Review</option>
            <option value="failed">Failed / Rejected</option>
          </select>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="rounded-3xl bg-[#0d0f17] border border-slate-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900/90 text-slate-400 font-mono uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="px-6 py-3.5">Reference ID</th>
                <th className="px-6 py-3.5">Type</th>
                <th className="px-6 py-3.5">Description</th>
                <th className="px-6 py-3.5">Amount (USD / Local)</th>
                <th className="px-6 py-3.5">Status</th>
                <th className="px-6 py-3.5">Date & Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-sans">
              {loading ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-slate-500 animate-pulse">
                    Loading records from secure ledger...
                  </td>
                </tr>
              ) : transactions.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-16 text-center">
                    <div className="flex flex-col items-center justify-center max-w-sm mx-auto space-y-3">
                      <div className="p-3 rounded-2xl bg-[#0a0d14] border border-slate-800/80">
                        <TRIZZLogo size="sm" glow />
                      </div>
                      <h4 className="text-sm font-bold text-white uppercase tracking-wider font-heading">
                        No Transactions Yet
                      </h4>
                      <p className="text-xs text-slate-400 leading-relaxed">
                        Your auditable ledger will record deposits, completed tasks, referral rewards, and Saturday settlements here.
                      </p>
                      <button
                        onClick={() => onNavigate("earn")}
                        className="mt-2 px-4 py-2 rounded-xl bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] hover:bg-[#00e575]/20 font-bold text-xs transition-colors cursor-pointer"
                      >
                        Explore Tasks to Earn
                      </button>
                    </div>
                  </td>
                </tr>
              ) : (
                transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4 font-mono text-slate-300 whitespace-nowrap">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400">#{tx.reference.slice(0, 14)}...</span>
                        <button
                          onClick={() => copyRef(tx.reference)}
                          className="p-1 rounded text-slate-500 hover:text-white cursor-pointer"
                          title="Copy Full Reference"
                        >
                          {copiedId === tx.reference ? (
                            <Check className="w-3.5 h-3.5 text-[#00e575]" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center gap-2 font-mono uppercase font-bold text-[11px] text-slate-200">
                        {getTypeIcon(tx.type)}
                        <span>{tx.type.replace("_", " ")}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-300 max-w-xs truncate">{tx.description}</td>
                    <td className="px-6 py-4 whitespace-nowrap font-mono font-bold">
                      <span
                        className={
                          tx.type === "withdrawal" || tx.type === "plan_purchase"
                            ? "text-rose-400"
                            : "text-[#00e575]"
                        }
                      >
                        {tx.type === "withdrawal" || tx.type === "plan_purchase" ? "-" : "+"}
                        ${tx.amountUsd.toFixed(2)}
                      </span>
                      <span className="text-slate-500 text-[10px] ml-1.5 font-normal">
                        (₦{tx.amountNgn.toLocaleString()})
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(tx.status)}</td>
                    <td className="px-6 py-4 text-slate-400 font-mono whitespace-nowrap">
                      {new Date(tx.createdAt).toLocaleString(undefined, {
                        month: "short",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
