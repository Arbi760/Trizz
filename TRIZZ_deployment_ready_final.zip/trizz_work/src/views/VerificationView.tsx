import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession } from "../types.ts";
import { api } from "../services/api.ts";
import {
  ShieldCheck,
  Award,
  Clock,
  AlertCircle,
  FileCheck,
  Upload,
  CheckCircle2,
  ArrowRight,
  Info,
} from "lucide-react";

interface VerificationViewProps {
  user: UserSession | null;
  onRefreshUser: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const VerificationView: React.FC<VerificationViewProps> = ({
  user,
  onRefreshUser,
  onNavigate,
}) => {
  const [docType, setDocType] = useState("National Identity Card (NIN)");
  const [docNumber, setDocNumber] = useState("");
  const [nameOnDoc, setNameOnDoc] = useState(user?.fullName || "");
  const [fileName, setFileName] = useState("government_id_front.jpg");
  const [submitting, setSubmitting] = useState(false);
  const [verificationData, setVerificationData] = useState<any>(null);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  useEffect(() => {
    if (user) {
      api
        .getVerification()
        .then((res) => setVerificationData(res))
        .catch((err) => console.error(err));
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!docNumber.trim() || !nameOnDoc.trim()) {
      setFeedback({ type: "error", text: "Please provide your ID document number and full legal name." });
      return;
    }

    try {
      setSubmitting(true);
      setFeedback(null);
      const res = await api.submitVerification({
        documentType: docType,
        documentNumber: docNumber,
        fullNameOnDocument: nameOnDoc,
        documentFrontName: fileName,
      });
      setFeedback({ type: "success", text: res.message });
      onRefreshUser();
      const updated = await api.getVerification();
      setVerificationData(updated);
    } catch (err: any) {
      setFeedback({ type: "error", text: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center mx-auto text-[#00e575]">
          <ShieldCheck className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-heading">Account Verification</h1>
        <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
          Please sign in to inspect your identity status or submit documents for compliance review.
        </p>
        <button
          onClick={() => onNavigate("login")}
          className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-colors cursor-pointer"
        >
          Sign In
        </button>
      </div>
    );
  }

  const currentStatus = user.verificationStatus || "not_verified";

  const getStatusBadge = () => {
    switch (currentStatus) {
      case "verified":
        return (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575] text-xs font-bold font-mono">
            <ShieldCheck className="w-4 h-4" />
            <span>IDENTITY VERIFIED</span>
          </div>
        );
      case "pending":
        return (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold font-mono">
            <Clock className="w-4 h-4" />
            <span>AUDIT UNDER REVIEW</span>
          </div>
        );
      case "rejected":
        return (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold font-mono">
            <AlertCircle className="w-4 h-4" />
            <span>SUBMISSION REJECTED</span>
          </div>
        );
      default:
        return (
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold font-mono">
            <Info className="w-4 h-4" />
            <span>ACTION REQUIRED</span>
          </div>
        );
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Welcome Banner from Specification */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#0d131f] to-[#080d14] border border-[#00e575]/25 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
        <div className="space-y-2">
          <span className="text-xs font-mono font-bold text-[#00e575] uppercase tracking-wider block">
            Welcome to TRIZZ
          </span>
          <h2 className="text-xl sm:text-2xl font-bold text-white font-heading">
            Your account has been created successfully.
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
            Complete your verification to unlock higher task limits, full wallet access, and smooth Saturday withdrawals.
          </p>
        </div>
        <div className="flex-shrink-0 self-center sm:self-auto">
          <TRIZZLogo size="lg" glow />
        </div>
      </div>

      {/* Header and Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h1 className="text-2xl sm:text-3xl font-black text-white font-heading uppercase">
            Account <span className="text-[#00e575]">Verification (KYC)</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Status: Document level authentication for user safety and anti-money laundering compliance.
          </p>
        </div>

        <div>{getStatusBadge()}</div>
      </div>

      {/* Verification Status Card */}
      {currentStatus === "verified" ? (
        <div className="p-8 rounded-3xl bg-[#0d0f17] border border-[#00e575]/30 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#00e575]/10 text-[#00e575] flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white">Full Compliance Clearance Granted</h3>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            Your identity has been verified against national regulatory records. You have unrestricted access to
            all task tier quotas and Saturday bank settlement disbursements.
          </p>
          <div className="pt-2 flex justify-center gap-4">
            <button
              onClick={() => onNavigate("dashboard")}
              className="px-6 py-2.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] cursor-pointer"
            >
              Open Dashboard
            </button>
            <button
              onClick={() => onNavigate("earn")}
              className="px-6 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 font-semibold text-xs hover:text-white cursor-pointer"
            >
              Explore Tasks
            </button>
          </div>
        </div>
      ) : currentStatus === "pending" ? (
        <div className="p-8 rounded-3xl bg-[#0d0f17] border border-amber-500/30 text-center space-y-4">
          <div className="w-16 h-16 rounded-full bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto">
            <Clock className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-bold text-white">Compliance Audit In Progress</h3>
          <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto leading-relaxed">
            Your document ({verificationData?.documentType || docType} - #{verificationData?.documentNumber || docNumber})
            has been received. Standard manual compliance reviews typically complete within 12–24 business hours.
          </p>
        </div>
      ) : (
        /* Document Submission Form */
        <div className="p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-6">
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-white font-heading">Submit Official Identification</h3>
            <p className="text-xs text-slate-400">
              Government-issued identification protects the platform from bots and automated multi-accounting.
            </p>
          </div>

          {feedback && (
            <div
              className={`p-4 rounded-2xl text-xs font-medium ${
                feedback.type === "success"
                  ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
                  : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
              }`}
            >
              {feedback.text}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div className="space-y-1">
              <label className="text-slate-300 font-medium">Document Type *</label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575] cursor-pointer"
              >
                <option value="National Identity Card (NIN)">National Identity Card (NIN / National ID)</option>
                <option value="International Passport">International Passport</option>
                <option value="Driver's License">Driver's License</option>
                <option value="Voter's Card">Voter's Card</option>
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-slate-300 font-medium">ID / Document Number *</label>
                <input
                  type="text"
                  required
                  value={docNumber}
                  onChange={(e) => setDocNumber(e.target.value)}
                  placeholder="e.g. 11-digit NIN or Passport No."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white font-mono focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-300 font-medium">Full Name on Document *</label>
                <input
                  type="text"
                  required
                  value={nameOnDoc}
                  onChange={(e) => setNameOnDoc(e.target.value)}
                  placeholder={user.fullName}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white focus:outline-none focus:border-[#00e575]"
                />
              </div>
            </div>

            {/* Document Upload Simulation */}
            <div className="space-y-1.5 pt-1">
              <label className="text-slate-300 font-medium">Upload Document Photo (Front & Back)</label>
              <div className="p-6 rounded-2xl bg-slate-900/60 border border-dashed border-slate-700 hover:border-[#00e575] transition-colors flex flex-col items-center justify-center text-center cursor-pointer">
                <Upload className="w-8 h-8 text-slate-400 mb-2" />
                <span className="text-xs font-bold text-white">Click or drag document images here</span>
                <span className="text-[11px] text-slate-500 mt-1">
                  Supported formats: PNG, JPG, PDF (Max 10MB). Encrypted on upload.
                </span>
                <span className="mt-3 px-3 py-1 rounded-md bg-slate-800 text-[#00e575] text-[10px] font-mono">
                  {fileName}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-xs hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#00e575]/20"
            >
              <FileCheck className="w-4 h-4" />
              <span>{submitting ? "Encrypting & Submitting..." : "Submit for Verification Review"}</span>
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
