import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession, WalletData } from "../types.ts";
import { api } from "../services/api.ts";
import {
  Wallet as WalletIcon,
  ArrowDownToLine,
  ArrowUpFromLine,
  ArrowLeftRight,
  History,
  Copy,
  Check,
  AlertTriangle,
  QrCode,
  Coins,
  ShieldCheck,
  Clock,
  X,
  Send,
} from "lucide-react";

interface WalletViewProps {
  user: UserSession | null;
  wallet: WalletData | null;
  onRefreshWallet: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  user,
  wallet,
  onRefreshWallet,
  onNavigate,
}) => {
  const [depositModalOpen, setDepositModalOpen] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [txHash, setTxHash] = useState("");
  const [depositNotes, setDepositNotes] = useState("");
  const [submittingHash, setSubmittingHash] = useState(false);
  const [depositFeedback, setDepositFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const cryptoConfig = wallet?.cryptoDeposit || {
    asset: "USDT",
    network: "BNB Smart Chain (BEP-20)",
    address: "",
    minimumDepositUsd: 10,
  };

  const copyAddress = () => {
    if (!cryptoConfig.address) return;
    navigator.clipboard.writeText(cryptoConfig.address);
    setCopiedAddress(true);
    setTimeout(() => setCopiedAddress(false), 2000);
  };

  const handleVerifyDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!txHash.trim()) {
      setDepositFeedback({ type: "error", text: "Please enter a valid transaction hash." });
      return;
    }
    try {
      setSubmittingHash(true);
      setDepositFeedback(null);
      const res = await api.verifyDeposit({
        transactionHash: txHash,
        notes: depositNotes,
      });
      setDepositFeedback({ type: "success", text: res.message });
      setTxHash("");
      setDepositNotes("");
      onRefreshWallet();
      setTimeout(() => {
        setDepositModalOpen(false);
        setDepositFeedback(null);
      }, 3000);
    } catch (err: any) {
      setDepositFeedback({ type: "error", text: err.message });
    } finally {
      setSubmittingHash(false);
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center mx-auto text-[#00e575]">
          <WalletIcon className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-heading">Digital Wallet Custody</h1>
        <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
          Please sign in to inspect your wallet ledger, submit crypto deposits, and configure Saturday settlement payouts.
        </p>
        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate("login")}
            className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-colors cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <TRIZZLogo size="xs" glow />
            <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] font-mono font-bold text-xs">
              TREASURY LEDGER
            </span>
            <span className="text-xs text-slate-400">Multi-Currency Balances</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-heading uppercase">
            User <span className="text-[#00e575]">Wallet</span>
          </h1>
          <p className="text-sm text-slate-300 max-w-xl">
            View available liquidity, pending audit balances, and initiate deposit or Saturday settlement requests.
          </p>
        </div>

        {/* Quick Reference Conversion Banner */}
        <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-xs font-mono text-slate-400 flex flex-col gap-1">
          <span className="text-[10px] uppercase text-slate-500">Platform Reference Rates</span>
          <div className="flex gap-4 text-slate-300 font-semibold">
            <span>Deposit: ₦{wallet?.rates.depositRate.toLocaleString()} / $1</span>
            <span>Withdrawal: ₦{wallet?.rates.withdrawalRate.toLocaleString()} / $1</span>
          </div>
        </div>
      </div>

      {/* 5 Core Balances Mandated by Specification */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 sm:gap-6">
        {/* 1. Available Balance */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-[#00e575]/30 shadow-lg shadow-[#00e575]/5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-mono font-bold text-[#00e575] uppercase">
              Available Balance
            </span>
            <span className="w-2 h-2 rounded-full bg-[#00e575] animate-ping" />
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            ${(wallet?.availableBalanceUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-xs font-mono text-slate-400">
            ≈ ₦{(wallet?.availableBalanceNgn ?? 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-[#00e575] block pt-1 font-medium">Eligible for payout</span>
        </div>

        {/* 2. Pending Balance */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-2">
          <span className="text-[11px] font-mono font-bold text-amber-400 uppercase">
            Pending Balance
          </span>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            ${(wallet?.pendingBalanceUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-xs font-mono text-slate-400">
            ≈ ₦{(wallet?.pendingBalanceNgn ?? 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-amber-400/80 block pt-1">Awaiting task audit</span>
        </div>

        {/* 3. Total Earned */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-2">
          <span className="text-[11px] font-mono font-bold text-sky-400 uppercase">
            Total Earned
          </span>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            ${(wallet?.totalEarnedUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-xs font-mono text-slate-400">
            ≈ ₦{(wallet?.totalEarnedNgn ?? 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-500 block pt-1">Cumulative verified</span>
        </div>

        {/* 4. Total Withdrawn */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-2">
          <span className="text-[11px] font-mono font-bold text-slate-400 uppercase">
            Total Withdrawn
          </span>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            ${(wallet?.totalWithdrawnUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-xs font-mono text-slate-400">
            ≈ ₦{(wallet?.totalWithdrawnNgn ?? 0).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-500 block pt-1">Disbursed to bank</span>
        </div>

        {/* 5. Referral Rewards */}
        <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-2">
          <span className="text-[11px] font-mono font-bold text-[#00e575] uppercase">
            Referral Rewards
          </span>
          <p className="text-2xl sm:text-3xl font-black text-white font-mono">
            ${(wallet?.referralRewardsUsd ?? 0).toFixed(2)}
          </p>
          <p className="text-xs font-mono text-slate-400">
            ≈ ₦{((wallet?.referralRewardsUsd ?? 0) * (wallet?.rates.withdrawalRate ?? 1200)).toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-500 block pt-1">Community bonuses</span>
        </div>
      </div>

      {/* Quick Action Buttons (DEPOSIT, WITHDRAW, TRANSFER, TRANSACTIONS) */}
      <div className="p-6 rounded-3xl bg-[#0a0c12] border border-slate-800">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-4 font-mono">
          Quick Actions
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <button
            onClick={() => setDepositModalOpen(true)}
            className="p-4 rounded-2xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-[#00e575]/15"
          >
            <Coins className="w-5 h-5" />
            <span>DEPOSIT USDT</span>
          </button>

          <button
            onClick={() => onNavigate("withdraw")}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-700 text-white font-bold text-sm hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowDownToLine className="w-5 h-5 text-[#00e575]" />
            <span>WITHDRAW FUNDS</span>
          </button>

          <button
            onClick={() => onNavigate("earn")}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-700 text-white font-bold text-sm hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowLeftRight className="w-5 h-5 text-sky-400" />
            <span>TASK REWARDS</span>
          </button>

          <button
            onClick={() => onNavigate("transactions")}
            className="p-4 rounded-2xl bg-slate-900 border border-slate-700 text-white font-bold text-sm hover:bg-slate-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
          >
            <History className="w-5 h-5 text-amber-400" />
            <span>TRANSACTIONS</span>
          </button>
        </div>
      </div>

      {/* Saturday Window Notification Alert */}
      <div className="p-6 rounded-2xl bg-[#0d0f17] border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-xl bg-amber-500/10 text-amber-400 flex-shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-white text-sm">Saturday Withdrawal Window Protocol</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Settlements disburse each Saturday (00:00 - 23:59 WAT). Status:{" "}
              <strong className={wallet?.withdrawalWindow.isOpen ? "text-[#00e575]" : "text-amber-400"}>
                {wallet?.withdrawalWindow.message}
              </strong>
            </p>
          </div>
        </div>

        <button
          onClick={() => onNavigate("withdraw")}
          className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition-colors whitespace-nowrap"
        >
          Manage Settlement
        </button>
      </div>

      {/* Crypto Deposit Modal */}
      {depositModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-lg bg-[#0d0f17] border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 max-h-[92vh] overflow-y-auto">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-mono text-[#00e575] font-bold uppercase">
                  Direct Digital Asset Gateway
                </span>
                <h3 className="text-xl font-bold text-white mt-1">Deposit USDT</h3>
              </div>
              <button
                onClick={() => setDepositModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Asset and Network Specification */}
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 font-mono">Asset:</span>
                <p className="font-bold text-white font-mono text-sm mt-0.5">{cryptoConfig.asset}</p>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-400 font-mono">Network:</span>
                <p className="font-bold text-[#00e575] font-mono text-sm mt-0.5">
                  {cryptoConfig.network}
                </p>
              </div>
            </div>

            {/* Mandatory Prompt Warning */}
            <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs leading-relaxed flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <div>
                <strong className="block text-white font-bold mb-1">Critical Deposit Warning:</strong>
                Send only USDT ({cryptoConfig.network}) to this address. Sending any other asset or
                using the wrong network may result in permanent loss.
              </div>
            </div>

            {/* Deposit Address Box */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">Your Dedicated Deposit Address</span>
                <span className="text-[10px] text-slate-400 font-mono">Min: ${cryptoConfig.minimumDepositUsd}.00</span>
              </div>
              {cryptoConfig.address ? (
                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
                  <span className="font-mono text-xs text-[#00e575] truncate">
                    {cryptoConfig.address}
                  </span>
                  <button
                    onClick={copyAddress}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer transition-colors flex-shrink-0"
                    title="Copy address"
                  >
                    {copiedAddress ? <Check className="w-4 h-4 text-[#00e575]" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 text-amber-300 text-xs leading-relaxed">
                  Official platform crypto deposit address is being provisioned by platform compliance. Please check back shortly or reach out to support.
                </div>
              )}
            </div>

            {/* Simulated Vector QR Representation */}
            {cryptoConfig.address && (
              <div className="p-4 rounded-2xl bg-white w-36 h-36 mx-auto flex flex-col items-center justify-center text-slate-900 shadow-lg">
                <QrCode className="w-28 h-28" />
              </div>
            )}

            {/* Manual Verification Form */}
            <form onSubmit={handleVerifyDeposit} className="space-y-4 pt-2 border-t border-slate-800">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Confirm Transaction Hash for Instant Credit
              </h4>

              {depositFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs ${
                    depositFeedback.type === "success"
                      ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
                      : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
                  }`}
                >
                  {depositFeedback.text}
                </div>
              )}

              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium">Transaction Hash (TxID)</label>
                <input
                  type="text"
                  value={txHash}
                  onChange={(e) => setTxHash(e.target.value)}
                  placeholder="0x..."
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono placeholder:text-slate-500 focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs text-slate-300 font-medium">Optional Sender Notes / Amount Sent</label>
                <input
                  type="text"
                  value={depositNotes}
                  onChange={(e) => setDepositNotes(e.target.value)}
                  placeholder="e.g. Sent $50 USDT from Binance"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs placeholder:text-slate-500 focus:outline-none focus:border-[#00e575]"
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setDepositModalOpen(false)}
                  className="flex-1 py-3 rounded-xl border border-slate-700 text-slate-300 text-xs font-bold hover:bg-slate-800 cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={submittingHash}
                  className="flex-1 py-3 rounded-xl bg-[#00e575] text-[#07080b] text-xs font-bold hover:bg-[#00ff84] transition-colors cursor-pointer flex items-center justify-center gap-2"
                >
                  {submittingHash ? "Validating On-Chain..." : "Verify & Credit Deposit"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
