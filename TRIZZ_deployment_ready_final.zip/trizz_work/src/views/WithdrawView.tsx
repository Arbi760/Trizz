import React, { useState, useEffect } from "react";
import { TRIZZLogo } from "../components/TRIZZLogo.tsx";
import { PageRoute, UserSession, WalletData } from "../types.ts";
import { api } from "../services/api.ts";
import {
  ArrowDownToLine,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Settings2,
  Calendar,
  Building2,
  ShieldCheck,
  DollarSign,
  Info,
  Zap,
} from "lucide-react";

interface WithdrawViewProps {
  user: UserSession | null;
  wallet: WalletData | null;
  onRefreshWallet: () => void;
  onNavigate: (route: PageRoute) => void;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({
  user,
  wallet,
  onRefreshWallet,
  onNavigate,
}) => {
  const [withdrawAmount, setWithdrawAmount] = useState<string>("");
  const [bankName, setBankName] = useState<string>("");
  const [accountNumber, setAccountNumber] = useState<string>("");
  const [accountName, setAccountName] = useState<string>("");
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; text: string } | null>(null);

  // Auto-withdrawal states
  const [autoWithdrawEnabled, setAutoWithdrawEnabled] = useState<boolean>(
    wallet?.autoWithdrawal.enabled ?? false
  );
  const [autoWithdrawMode, setAutoWithdrawMode] = useState<"minimum" | "custom">(
    wallet?.autoWithdrawal.mode ?? "minimum"
  );
  const [customAutoAmount, setCustomAutoAmount] = useState<number>(
    wallet?.autoWithdrawal.customAmount ?? 20
  );
  const [savingAuto, setSavingAuto] = useState<boolean>(false);
  const [autoFeedback, setAutoFeedback] = useState<string | null>(null);

  // Demo bypass toggle for testing

  useEffect(() => {
    if (wallet?.autoWithdrawal) {
      setAutoWithdrawEnabled(wallet.autoWithdrawal.enabled);
      setAutoWithdrawMode(wallet.autoWithdrawal.mode);
      setCustomAutoAmount(wallet.autoWithdrawal.customAmount);
    }
  }, [wallet]);

  const numAmount = parseFloat(withdrawAmount) || 0;
  const feeRate = (wallet?.rates.withdrawalFeePercent ?? 15) / 100;
  const feeUsd = numAmount * feeRate;
  const netUsd = Math.max(0, numAmount - feeUsd);
  const rateNgn = wallet?.rates.withdrawalRate ?? 1200;
  const netNgn = netUsd * rateNgn;
  const minRequiredUsd = wallet?.minimumWithdrawalUsd ?? 10;


  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      onNavigate("login");
      return;
    }

    if (numAmount < minRequiredUsd) {
      setFeedback({
        type: "error",
        text: `Withdrawal amount must be at least $${minRequiredUsd} for your plan tier (${user.planTier}).`,
      });
      return;
    }

    if (numAmount > (wallet?.availableBalanceUsd ?? 0)) {
      setFeedback({
        type: "error",
        text: "Insufficient available balance. Pending balances cannot be withdrawn until audit completion.",
      });
      return;
    }

    if (!accountNumber.trim() || !bankName.trim() || !accountName.trim()) {
      setFeedback({
        type: "error",
        text: "Please provide complete bank settlement credentials (Bank Name, Account Number, and Account Name).",
      });
      return;
    }

    try {
      setSubmitting(true);
      setFeedback(null);
      const res = await api.submitWithdrawal({
        amountUsd: numAmount,
        withdrawalMethod: "bank_transfer",
        destinationDetails: {
          bankName,
          accountNumber,
          accountName,
        },
      });
      setFeedback({ type: "success", text: res.message });
      setWithdrawAmount("");
      onRefreshWallet();
    } catch (err: any) {
      setFeedback({ type: "error", text: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveAutoWithdrawal = async () => {
    try {
      setSavingAuto(true);
      setAutoFeedback(null);
      await api.configureAutoWithdraw({
        enabled: autoWithdrawEnabled,
        mode: autoWithdrawMode,
        customAmount: customAutoAmount,
      });
      setAutoFeedback("Auto-withdrawal preferences updated successfully.");
      onRefreshWallet();
      setTimeout(() => setAutoFeedback(null), 3000);
    } catch (err: any) {
      setAutoFeedback(`Error: ${err.message}`);
    } finally {
      setSavingAuto(false);
    }
  };

  const formatCountdown = (seconds: number) => {
    if (seconds <= 0) return "Active Now (Window Open)";
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${days}d ${hours}h ${minutes}m`;
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-6">
        <div className="w-16 h-16 rounded-2xl bg-[#00e575]/10 border border-[#00e575]/20 flex items-center justify-center mx-auto text-[#00e575]">
          <ArrowDownToLine className="w-8 h-8" />
        </div>
        <h1 className="text-3xl font-extrabold text-white font-heading">Withdrawal Settlement</h1>
        <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
          Sign in to your TRIZZ account to review your minimum withdrawal eligibility and participate in the scheduled Saturday settlement window.
        </p>
        <div className="flex justify-center gap-4 pt-2">
          <button
            onClick={() => onNavigate("login")}
            className="px-6 py-3 rounded-xl bg-[#00e575] text-[#07080b] font-bold text-sm hover:bg-[#00ff84] transition-colors cursor-pointer"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const isWindowOpen = wallet?.withdrawalWindow?.isOpen ?? false;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14 space-y-10">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-slate-800">
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <TRIZZLogo size="xs" glow />
            <span className="px-2.5 py-1 rounded-md bg-[#00e575]/10 text-[#00e575] font-mono font-bold text-xs">
              SETTLEMENT PROTOCOL
            </span>
            <span className="text-xs text-slate-400">Scheduled Weekly Liquidity</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white font-heading uppercase">
            Withdraw <span className="text-[#00e575]">Funds</span>
          </h1>
          <p className="text-sm text-slate-300 max-w-xl">
            Withdrawals process every Saturday between 00:00 and 23:59 WAT with transparent 15% platform processing.
          </p>
        </div>

      </div>

      {/* Saturday Window Protocol Banner */}
      <div
        className={`p-6 rounded-3xl border transition-all ${
          isWindowOpen
            ? "bg-[#00e575]/5 border-[#00e575]/40 shadow-lg shadow-[#00e575]/5"
            : "bg-[#0d0f17] border-amber-500/30"
        }`}
      >
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <div
              className={`p-3.5 rounded-2xl flex-shrink-0 ${
                isWindowOpen ? "bg-[#00e575]/20 text-[#00e575]" : "bg-amber-500/10 text-amber-400"
              }`}
            >
              <Clock className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  {isWindowOpen ? "Saturday Settlement Window is LIVE" : "Settlement Window Scheduled"}
                </h3>
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                    isWindowOpen ? "bg-[#00e575] text-[#07080b]" : "bg-amber-500/20 text-amber-400"
                  }`}
                >
                  {isWindowOpen ? "ACTIVE" : "QUEUED"}
                </span>
              </div>
              <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                Standard withdrawal requests are processed exclusively on Saturdays (00:00 - 23:59 WAT).
                Requests submitted outside this window are automatically batched or queued for the upcoming Saturday settlement run.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-center flex-shrink-0 min-w-[200px]">
            <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
              {isWindowOpen ? "Window Closes In" : "Next Window Countdown"}
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-[#00e575]">
              {formatCountdown(wallet?.withdrawalWindow?.secondsUntilNextWindow ?? 0)}
            </span>
            <span className="text-[10px] text-slate-500 block mt-0.5">
              {wallet?.withdrawalWindow?.nextWindowDateString}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: Withdrawal Form vs Rules & Auto-Withdrawal */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Settlement Form */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 sm:p-8 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <h3 className="text-lg font-bold text-white font-heading">Submit Settlement Request</h3>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 font-mono uppercase block">Available Balance</span>
                <span className="text-sm font-bold text-[#00e575] font-mono">
                  ${(wallet?.availableBalanceUsd ?? 0).toFixed(2)} (₦{(wallet?.availableBalanceNgn ?? 0).toLocaleString()})
                </span>
              </div>
            </div>

            {feedback && (
              <div
                className={`p-4 rounded-2xl text-xs ${
                  feedback.type === "success"
                    ? "bg-[#00e575]/10 border border-[#00e575]/30 text-[#00e575]"
                    : "bg-rose-500/10 border border-rose-500/30 text-rose-400"
                }`}
              >
                {feedback.text}
              </div>
            )}

            <form onSubmit={handleWithdrawSubmit} className="space-y-5">
              {/* Amount input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <label className="text-slate-300 font-medium">Withdrawal Amount (USD)</label>
                  <span className="text-slate-400 font-mono text-[11px]">
                    Min for {user.planTier}: ${minRequiredUsd}.00
                  </span>
                </div>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-mono text-sm">
                    $
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    min={minRequiredUsd}
                    value={withdrawAmount}
                    onChange={(e) => setWithdrawAmount(e.target.value)}
                    placeholder={`${minRequiredUsd}.00`}
                    className="w-full pl-8 pr-20 py-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-white font-mono text-base focus:outline-none focus:border-[#00e575]"
                  />
                  <button
                    type="button"
                    onClick={() => setWithdrawAmount((wallet?.availableBalanceUsd ?? 0).toString())}
                    className="absolute right-3 top-1/2 -translate-y-1/2 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-mono font-bold cursor-pointer"
                  >
                    MAX
                  </button>
                </div>
              </div>

              {/* Dynamic Fee & Net Payout Calculation */}
              {numAmount > 0 && (
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Requested Amount:</span>
                    <span className="font-mono text-white">${numAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Standard Platform Fee (15%):</span>
                    <span className="font-mono text-rose-400">-${feeUsd.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Settlement Conversion Rate:</span>
                    <span className="font-mono text-slate-300">1 USD = ₦{rateNgn.toLocaleString()}</span>
                  </div>
                  <div className="pt-2 border-t border-slate-800 flex justify-between items-baseline font-bold">
                    <span className="text-white">Net Bank Payout:</span>
                    <div className="text-right">
                      <span className="text-[#00e575] font-mono text-base">
                        ₦{Math.round(netNgn).toLocaleString()}
                      </span>
                      <span className="text-slate-400 font-mono text-[11px] block">
                        (${netUsd.toFixed(2)} USD)
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Destination Bank Details */}
              <div className="space-y-3 pt-2">
                <span className="text-xs font-bold text-white uppercase tracking-wider block font-mono">
                  Destination Account Details
                </span>

                <div className="space-y-1">
                  <label className="text-xs text-slate-300 font-medium">Bank Name</label>
                  <input
                    type="text"
                    value={bankName}
                    onChange={(e) => setBankName(e.target.value)}
                    placeholder="e.g. Access Bank, GTBank, Zenith Bank, Kuda"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-[#00e575]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-xs text-slate-300 font-medium">Account Number (NUBAN)</label>
                    <input
                      type="text"
                      maxLength={10}
                      value={accountNumber}
                      onChange={(e) => setAccountNumber(e.target.value)}
                      placeholder="10-digit number"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs font-mono focus:outline-none focus:border-[#00e575]"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs text-slate-300 font-medium">Account Name (Must Match KYC)</label>
                    <input
                      type="text"
                      value={accountName}
                      onChange={(e) => setAccountName(e.target.value)}
                      placeholder={user.fullName}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-[#00e575]"
                    />
                  </div>
                </div>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-4 rounded-2xl bg-[#00e575] text-[#07080b] font-black font-heading text-sm hover:bg-[#00ff84] transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xl shadow-[#00e575]/20"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>
                  {submitting
                    ? "Submitting to Settlement Queue..."
                    : isWindowOpen
                    ? "SUBMIT SATURDAY WITHDRAWAL"
                    : "QUEUE FOR SATURDAY SETTLEMENT"}
                </span>
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Auto-Withdrawal Config & Tier Minimums */}
        <div className="lg:col-span-5 space-y-6">
          {/* Auto-Withdrawal Panel */}
          <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-white text-sm">Automated Settlement</h3>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/10 text-amber-400 font-bold">
                +2.5% Surcharge
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Enable automatic execution during each Saturday window without requiring manual login.
            </p>

            {autoFeedback && (
              <div className="p-3 rounded-xl bg-slate-800 text-[#00e575] text-xs">{autoFeedback}</div>
            )}

            <div className="space-y-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoWithdrawEnabled}
                  onChange={(e) => setAutoWithdrawEnabled(e.target.checked)}
                  className="w-4 h-4 accent-[#00e575] rounded"
                />
                <span className="text-xs font-bold text-white">Enable Saturday Auto-Withdrawal</span>
              </label>

              {autoWithdrawEnabled && (
                <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3 text-xs">
                  <div className="space-y-1.5">
                    <label className="text-slate-400">Trigger Mode</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setAutoWithdrawMode("minimum")}
                        className={`p-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          autoWithdrawMode === "minimum"
                            ? "bg-[#00e575]/10 border-[#00e575] text-[#00e575]"
                            : "bg-slate-800 border-slate-700 text-slate-400"
                        }`}
                      >
                        Tier Minimum (${minRequiredUsd})
                      </button>
                      <button
                        type="button"
                        onClick={() => setAutoWithdrawMode("custom")}
                        className={`p-2 rounded-xl text-xs font-bold border transition-colors cursor-pointer ${
                          autoWithdrawMode === "custom"
                            ? "bg-[#00e575]/10 border-[#00e575] text-[#00e575]"
                            : "bg-slate-800 border-slate-700 text-slate-400"
                        }`}
                      >
                        Custom Threshold
                      </button>
                    </div>
                  </div>

                  {autoWithdrawMode === "custom" && (
                    <div className="space-y-1">
                      <label className="text-slate-400">Trigger Amount (USD)</label>
                      <input
                        type="number"
                        min={minRequiredUsd}
                        value={customAutoAmount}
                        onChange={(e) => setCustomAutoAmount(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white font-mono text-xs"
                      />
                    </div>
                  )}
                </div>
              )}

              <button
                type="button"
                onClick={handleSaveAutoWithdrawal}
                disabled={savingAuto}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs cursor-pointer transition-colors"
              >
                {savingAuto ? "Saving Preferences..." : "Save Auto-Withdrawal Config"}
              </button>
            </div>
          </div>

          {/* Minimum Withdrawal Thresholds Table */}
          <div className="p-6 rounded-3xl bg-[#0d0f17] border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
              Tier Minimum Withdrawal Limits
            </h4>
            <div className="space-y-2 text-xs">
              {[
                { tier: "FREE", minUsd: 5, minNgn: 6000 },
                { tier: "T1", minUsd: 7, minNgn: 8400 },
                { tier: "T2", minUsd: 10, minNgn: 12000 },
                { tier: "T3", minUsd: 15, minNgn: 18000 },
                { tier: "T4", minUsd: 20, minNgn: 24000 },
                { tier: "T5", minUsd: 25, minNgn: 30000 },
                { tier: "T6", minUsd: 35, minNgn: 42000 },
                { tier: "T7", minUsd: 50, minNgn: 60000 },
              ].map((item) => (
                <div
                  key={item.tier}
                  className={`flex justify-between p-2 rounded-lg ${
                    user.planTier === item.tier
                      ? "bg-[#00e575]/10 border border-[#00e575]/40 text-[#00e575] font-bold"
                      : "text-slate-400"
                  }`}
                >
                  <span>{item.tier} Tier</span>
                  <span className="font-mono">
                    ${item.minUsd}.00 (₦{item.minNgn.toLocaleString()})
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
