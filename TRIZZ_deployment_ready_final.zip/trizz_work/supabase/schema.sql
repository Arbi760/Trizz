-- ==============================================================================
-- TRIZZ PLATFORM — COMPLETE HARDENED SUPABASE POSTGRESQL DATABASE SCHEMA
-- Unified Shared Database Architecture for:
--   1. TRIZZ Public Website (Client & Server-Side Proxied Routes)
--   2. TRIZZ Admin Control Center (Back-Office Administration & Auditing)
--
-- Security Features:
--   - Strict Row Level Security (RLS) on all tables
--   - Recursion-safe SECURITY DEFINER administrator authorization (is_admin())
--   - Complete immutability of financial ledger and audit logs (append-only)
--   - Atomic, concurrency-safe server functions for balance movements & plan upgrades
--   - Protection against race conditions, negative balances, and replay attacks
--   - Zero hardcoded deposit addresses or fake operational data
-- ==============================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

ALTER TABLE IF EXISTS platform_settings DROP COLUMN IF EXISTS force_window_open_demo;

-- ==============================================================================
-- 2. CORE SYSTEM & CONFIGURATION TABLES
-- ==============================================================================

-- Platform Global Settings (Admin-Controlled Single Row)
CREATE TABLE IF NOT EXISTS platform_settings (
  id VARCHAR(64) PRIMARY KEY DEFAULT 'default',
  deposit_reference_rate_ngn_per_usd NUMERIC(12, 2) NOT NULL DEFAULT 1500.00,
  withdrawal_reference_rate_ngn_per_usd NUMERIC(12, 2) NOT NULL DEFAULT 1200.00,
  standard_withdrawal_fee_percent NUMERIC(5, 2) NOT NULL DEFAULT 15.00,
  auto_withdrawal_fee_percent NUMERIC(5, 2) NOT NULL DEFAULT 2.50,
  withdrawal_window_day VARCHAR(32) NOT NULL DEFAULT 'Saturday',
  withdrawal_window_day_num INT NOT NULL DEFAULT 6,
  withdrawal_opening_hour INT NOT NULL DEFAULT 0,
  withdrawal_closing_hour INT NOT NULL DEFAULT 23,
  withdrawal_timezone VARCHAR(64) NOT NULL DEFAULT 'UTC+1 / West Africa Time (WAT)',
  withdrawal_timezone_offset INT NOT NULL DEFAULT 1,
  crypto_deposit_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  crypto_deposit_asset VARCHAR(16) NOT NULL DEFAULT 'USDT',
  crypto_deposit_network VARCHAR(64) NOT NULL DEFAULT 'BEP-20 (BNB Smart Chain)',
  crypto_deposit_address VARCHAR(128) DEFAULT NULL, -- Configurable by Admin only
  crypto_deposit_min_usd NUMERIC(10, 2) NOT NULL DEFAULT 10.00,
  maintenance_mode BOOLEAN NOT NULL DEFAULT FALSE,
  maintenance_notice TEXT,
  compliance_statement TEXT DEFAULT 'Official company registration credentials and jurisdictional licensing will be published by authorized platform compliance officers upon administrative configuration.',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Support Communication Channels (Admin-Controlled)
CREATE TABLE IF NOT EXISTS support_channels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_type VARCHAR(32) NOT NULL, -- 'telegram' | 'whatsapp' | 'email' | 'desk'
  title VARCHAR(128) NOT NULL,
  handle VARCHAR(128) NOT NULL,
  target_url TEXT NOT NULL,
  support_hours VARCHAR(128) NOT NULL DEFAULT 'Monday – Sunday, 24/7 Operational Response',
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Global Announcements & In-App Banners (Admin-Controlled)
CREATE TABLE IF NOT EXISTS announcements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(256) NOT NULL,
  message TEXT NOT NULL,
  banner_type VARCHAR(32) NOT NULL DEFAULT 'info', -- 'info' | 'warning' | 'success' | 'maintenance'
  action_url TEXT,
  action_text VARCHAR(64),
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  starts_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  ends_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Platform Product & Membership Tiers (T1–T7)
CREATE TABLE IF NOT EXISTS plans (
  id VARCHAR(32) PRIMARY KEY, -- 't1' through 't7'
  tier VARCHAR(16) UNIQUE NOT NULL, -- 'T1' through 'T7'
  name VARCHAR(128) NOT NULL,
  price_usd NUMERIC(10, 2) NOT NULL,
  price_ngn NUMERIC(14, 2) NOT NULL,
  description TEXT NOT NULL,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  min_withdrawal_usd NUMERIC(10, 2) NOT NULL,
  min_withdrawal_ngn NUMERIC(14, 2) NOT NULL,
  daily_task_cap INT NOT NULL DEFAULT 5,
  referral_bonus_percentage NUMERIC(5, 2) NOT NULL DEFAULT 5.00,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==============================================================================
-- 3. USERS, PROFILES & IDENTITY VERIFICATION
-- ==============================================================================

-- Registered User Accounts
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  supabase_auth_id UUID UNIQUE, -- Foreign reference to auth.users
  full_name VARCHAR(128) NOT NULL,
  username VARCHAR(64) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(32),
  country VARCHAR(64) NOT NULL DEFAULT 'Nigeria',
  currency_preference VARCHAR(8) NOT NULL DEFAULT 'USD',
  referral_code VARCHAR(32) UNIQUE NOT NULL,
  referred_by UUID REFERENCES users(id),
  role VARCHAR(16) NOT NULL DEFAULT 'user', -- 'user' | 'admin' | 'moderator'
  plan_tier VARCHAR(16) NOT NULL DEFAULT 'FREE',
  verification_status VARCHAR(32) NOT NULL DEFAULT 'not_verified', -- 'not_verified' | 'pending' | 'verified' | 'rejected' | 'requires_info'
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  is_banned BOOLEAN NOT NULL DEFAULT FALSE,
  ban_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- KYC Compliance Verifications
CREATE TABLE IF NOT EXISTS kyc_verifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  document_type VARCHAR(32) NOT NULL, -- 'national_id' | 'passport' | 'drivers_license' | 'voters_card'
  document_number VARCHAR(128) NOT NULL,
  full_name_on_document VARCHAR(128) NOT NULL,
  document_front_url TEXT,
  document_back_url TEXT,
  selfie_url TEXT,
  status VARCHAR(32) NOT NULL DEFAULT 'pending', -- 'pending' | 'verified' | 'rejected' | 'requires_info'
  admin_notes_internal TEXT, -- Confidential compliance notes, never sent to client
  public_feedback TEXT,
  reviewed_by UUID REFERENCES users(id),
  submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ
);

-- ==============================================================================
-- 4. WALLET, TRANSACTIONS, LEDGER & SUBSCRIPTIONS
-- ==============================================================================

-- User Summary Wallets (Strictly modified via atomic functions/ledger entries)
CREATE TABLE IF NOT EXISTS wallets (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  available_balance_usd NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (available_balance_usd >= 0.00),
  pending_balance_usd NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (pending_balance_usd >= 0.00),
  total_earned_usd NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (total_earned_usd >= 0.00),
  total_withdrawn_usd NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (total_withdrawn_usd >= 0.00),
  referral_rewards_usd NUMERIC(14, 2) NOT NULL DEFAULT 0.00 CHECK (referral_rewards_usd >= 0.00),
  auto_withdrawal_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  auto_withdrawal_mode VARCHAR(16) NOT NULL DEFAULT 'minimum',
  auto_withdrawal_custom_amount NUMERIC(12, 2) NOT NULL DEFAULT 50.00 CHECK (auto_withdrawal_custom_amount >= 20.00),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User Facing Financial Transactions (Deposits, Withdrawals, Upgrades, Rewards)
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type VARCHAR(32) NOT NULL, -- 'deposit' | 'withdrawal' | 'reward' | 'referral' | 'task' | 'plan_upgrade' | 'adjustment'
  amount_usd NUMERIC(12, 2) NOT NULL CHECK (amount_usd > 0.00),
  amount_ngn NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
  conversion_rate NUMERIC(12, 2) NOT NULL DEFAULT 1500.00,
  fee_usd NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
  net_amount_usd NUMERIC(12, 2) NOT NULL,
  currency VARCHAR(16) NOT NULL DEFAULT 'USD',
  status VARCHAR(32) NOT NULL DEFAULT 'pending', -- 'pending' | 'under_review' | 'processing' | 'completed' | 'failed' | 'cancelled' | 'rejected'
  reference VARCHAR(64) UNIQUE NOT NULL,
  description TEXT NOT NULL,
  -- Dedicated Structured Deposit/Funding Fields
  asset VARCHAR(16) DEFAULT 'USDT',
  network VARCHAR(64),
  transaction_hash VARCHAR(256),
  destination_address VARCHAR(128),
  provider_reference VARCHAR(128),
  idempotency_key VARCHAR(128) UNIQUE,
  verified_at TIMESTAMPTZ,
  verified_by UUID REFERENCES users(id),
  -- Dedicated Structured Withdrawal Fields
  destination_details JSONB DEFAULT '{}'::jsonb,
  settled_at TIMESTAMPTZ,
  settled_by UUID REFERENCES users(id),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Immutable Double-Entry Financial Movement Ledger
CREATE TABLE IF NOT EXISTS wallet_ledger (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  transaction_id UUID REFERENCES wallet_transactions(id) ON DELETE SET NULL,
  entry_type VARCHAR(16) NOT NULL, -- 'credit' | 'debit'
  account VARCHAR(32) NOT NULL, -- 'available_balance' | 'pending_balance' | 'referral_pool' | 'platform_reserve'
  amount_usd NUMERIC(14, 2) NOT NULL CHECK (amount_usd > 0.00),
  balance_before_usd NUMERIC(14, 2) NOT NULL,
  balance_after_usd NUMERIC(14, 2) NOT NULL,
  description TEXT NOT NULL,
  reference VARCHAR(64) NOT NULL,
  actor_type VARCHAR(16) NOT NULL DEFAULT 'system', -- 'system' | 'admin' | 'user'
  actor_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- User Plan Purchase & Upgrade Relationship History
CREATE TABLE IF NOT EXISTS user_plan_subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  previous_plan_tier VARCHAR(16) NOT NULL DEFAULT 'FREE',
  new_plan_tier VARCHAR(16) NOT NULL REFERENCES plans(tier),
  transaction_id UUID REFERENCES wallet_transactions(id) ON DELETE SET NULL,
  amount_usd NUMERIC(10, 2) NOT NULL,
  amount_ngn NUMERIC(14, 2) NOT NULL,
  status VARCHAR(32) NOT NULL DEFAULT 'active', -- 'active' | 'superseded' | 'cancelled'
  reference VARCHAR(64) UNIQUE NOT NULL, -- Idempotent purchase reference
  activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==============================================================================
-- 5. TASKS, REFERRALS, BLOG, TICKETS & NOTIFICATIONS
-- ==============================================================================

-- Tasks Marketplace
CREATE TABLE IF NOT EXISTS tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(256) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(32) NOT NULL, -- 'app' | 'social' | 'survey' | 'review' | 'security' | 'finance'
  reward_usd NUMERIC(10, 2) NOT NULL CHECK (reward_usd >= 0.00),
  reward_ngn NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
  estimated_minutes INT NOT NULL DEFAULT 5,
  plan_requirement VARCHAR(16) DEFAULT 'FREE',
  requirements JSONB NOT NULL DEFAULT '[]'::jsonb,
  instructions TEXT NOT NULL,
  deadline_days INT NOT NULL DEFAULT 7,
  max_submissions INT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Task Submissions
CREATE TABLE IF NOT EXISTS task_submissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(32) NOT NULL DEFAULT 'in_progress', -- 'in_progress' | 'submitted' | 'under_review' | 'approved' | 'rejected'
  proof_text TEXT,
  proof_url TEXT,
  reward_claimed BOOLEAN NOT NULL DEFAULT FALSE,
  submitted_at TIMESTAMPTZ,
  reviewed_at TIMESTAMPTZ,
  reviewed_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT unique_user_task_submission UNIQUE (user_id, task_id)
);

-- Referral Rewards
CREATE TABLE IF NOT EXISTS referral_rewards (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  referrer_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  referred_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  qualifying_action VARCHAR(128) NOT NULL,
  reward_usd NUMERIC(10, 2) NOT NULL CHECK (reward_usd >= 0.00),
  reward_ngn NUMERIC(14, 2) NOT NULL DEFAULT 0.00,
  status VARCHAR(32) NOT NULL DEFAULT 'pending', -- 'pending' | 'approved' | 'rejected'
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  approved_at TIMESTAMPTZ
);

-- Knowledge Base & Editorial Blog Posts
CREATE TABLE IF NOT EXISTS blog_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  slug VARCHAR(256) UNIQUE NOT NULL,
  title VARCHAR(256) NOT NULL,
  summary TEXT NOT NULL,
  content TEXT NOT NULL,
  category VARCHAR(64) NOT NULL,
  author_name VARCHAR(128) NOT NULL DEFAULT 'TRIZZ Editorial Team',
  author_role VARCHAR(128) NOT NULL DEFAULT 'Compliance & Strategy',
  published_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reading_time_minutes INT NOT NULL DEFAULT 4,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  featured_image_url TEXT,
  video_url TEXT,
  status VARCHAR(16) NOT NULL DEFAULT 'published', -- 'published' | 'draft' | 'archived'
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Platform Legal & Regulatory Documents
CREATE TABLE IF NOT EXISTS legal_documents (
  slug VARCHAR(64) PRIMARY KEY, -- 'terms' | 'privacy' | 'risk-disclosure'
  title VARCHAR(256) NOT NULL,
  version VARCHAR(32) NOT NULL,
  effective_date DATE NOT NULL,
  last_updated DATE NOT NULL,
  sections JSONB NOT NULL DEFAULT '[]'::jsonb,
  regulatory_notice TEXT NOT NULL DEFAULT 'Regulatory registration and jurisdictional compliance credentials will be published directly by authorized compliance officers upon administrative configuration.',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Support Tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  name VARCHAR(128) NOT NULL,
  email VARCHAR(255) NOT NULL,
  subject VARCHAR(256) NOT NULL,
  message TEXT NOT NULL,
  category VARCHAR(32) NOT NULL DEFAULT 'general',
  status VARCHAR(32) NOT NULL DEFAULT 'open', -- 'open' | 'in_progress' | 'resolved' | 'closed'
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- In-App Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(256) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(32) NOT NULL, -- 'account' | 'withdrawal' | 'task' | 'referral' | 'verification' | 'announcement'
  read BOOLEAN NOT NULL DEFAULT FALSE,
  link TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Immutable Administrative & System Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  admin_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(128) NOT NULL,
  category VARCHAR(32) NOT NULL, -- 'auth' | 'wallet' | 'compliance' | 'admin' | 'tasks'
  ip_address VARCHAR(64),
  user_agent TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==============================================================================
-- 6. SECURITY HELPER FUNCTIONS & TRIGGER DEFENDERS
-- ==============================================================================

-- Recursion-Safe Administrator Authorization Check
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE supabase_auth_id = auth.uid()
      AND role IN ('admin','super_admin')
      AND is_active = TRUE
      AND is_banned = FALSE
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE SET search_path = public, pg_temp;

-- Trigger: Protect Privileged User Columns from Client Tampering
CREATE OR REPLACE FUNCTION protect_user_privileged_columns()
RETURNS TRIGGER AS $$
BEGIN
  IF (COALESCE(auth.jwt() ->> 'role', 'authenticated')) != 'service_role' AND NOT is_admin() THEN
    IF OLD.role IS DISTINCT FROM NEW.role THEN
      RAISE EXCEPTION 'Security violation: Client cannot modify role.';
    END IF;
    IF OLD.plan_tier IS DISTINCT FROM NEW.plan_tier THEN
      RAISE EXCEPTION 'Security violation: Client cannot directly modify plan_tier. Use process_plan_upgrade().';
    END IF;
    IF OLD.verification_status IS DISTINCT FROM NEW.verification_status THEN
      RAISE EXCEPTION 'Security violation: Client cannot directly modify verification_status.';
    END IF;
    IF OLD.is_active IS DISTINCT FROM NEW.is_active OR OLD.is_banned IS DISTINCT FROM NEW.is_banned THEN
      RAISE EXCEPTION 'Security violation: Client cannot modify account status.';
    END IF;
    IF OLD.referral_code IS DISTINCT FROM NEW.referral_code THEN
      RAISE EXCEPTION 'Security violation: referral_code is immutable.';
    END IF;
    IF OLD.referred_by IS DISTINCT FROM NEW.referred_by THEN
      RAISE EXCEPTION 'Security violation: referred_by cannot be altered after creation.';
    END IF;
    IF OLD.supabase_auth_id IS DISTINCT FROM NEW.supabase_auth_id THEN
      RAISE EXCEPTION 'Security violation: Auth identity link is immutable.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_protect_user_privileged_columns ON users;
CREATE TRIGGER trg_protect_user_privileged_columns
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION protect_user_privileged_columns();

-- Trigger: Protect Task Submission Approval Status & Reward Claims
CREATE OR REPLACE FUNCTION protect_task_submission_columns()
RETURNS TRIGGER AS $$
BEGIN
  IF (COALESCE(auth.jwt() ->> 'role', 'authenticated')) != 'service_role' AND NOT is_admin() THEN
    IF OLD.reward_claimed IS DISTINCT FROM NEW.reward_claimed AND NEW.reward_claimed = TRUE THEN
      RAISE EXCEPTION 'Security violation: Task rewards can only be disbursed by server-side verification.';
    END IF;
    IF OLD.status IS DISTINCT FROM NEW.status AND NEW.status IN ('approved', 'rejected') THEN
      RAISE EXCEPTION 'Security violation: Task status approval is restricted to authorized administrators.';
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_protect_task_submission_columns ON task_submissions;
CREATE TRIGGER trg_protect_task_submission_columns
BEFORE UPDATE ON task_submissions
FOR EACH ROW
EXECUTE FUNCTION protect_task_submission_columns();

-- Trigger: Guarantee Immutability of Financial Ledger (Append-Only)
CREATE OR REPLACE FUNCTION forbid_ledger_tampering()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Security violation: wallet_ledger is an immutable audit trail. Records cannot be updated or deleted.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_forbid_ledger_tampering ON wallet_ledger;
CREATE TRIGGER trg_forbid_ledger_tampering
BEFORE UPDATE OR DELETE ON wallet_ledger
FOR EACH ROW
EXECUTE FUNCTION forbid_ledger_tampering();

-- Trigger: Guarantee Immutability of Audit Logs (Append-Only)
CREATE OR REPLACE FUNCTION forbid_audit_log_tampering()
RETURNS TRIGGER AS $$
BEGIN
  RAISE EXCEPTION 'Security violation: audit_logs is an immutable audit trail. Records cannot be updated or deleted.';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS trg_forbid_audit_log_tampering ON audit_logs;
CREATE TRIGGER trg_forbid_audit_log_tampering
BEFORE UPDATE OR DELETE ON audit_logs
FOR EACH ROW
EXECUTE FUNCTION forbid_audit_log_tampering();

-- ==============================================================================
-- 7. ATOMIC SERVER-SIDE FINANCIAL STORED PROCEDURES
-- ==============================================================================

-- Procedure 1: Atomic Plan Purchase & Upgrade
CREATE OR REPLACE FUNCTION process_plan_upgrade(
  p_user_id UUID,
  p_target_tier VARCHAR,
  p_reference VARCHAR
)
RETURNS JSONB AS $$
DECLARE
  v_user users%ROWTYPE;
  v_plan plans%ROWTYPE;
  v_wallet wallets%ROWTYPE;
  v_previous_tier VARCHAR;
  v_balance_before NUMERIC;
  v_balance_after NUMERIC;
  v_tx_id UUID;
BEGIN
  IF COALESCE(auth.jwt() ->> 'role','authenticated') <> 'service_role'
     AND NOT is_admin()
     AND NOT EXISTS (SELECT 1 FROM users WHERE id = p_user_id AND supabase_auth_id = auth.uid()) THEN
    RAISE EXCEPTION 'Security violation: cannot purchase a plan for another user.';
  END IF;

  -- 1. Idempotency Guard
  IF EXISTS (SELECT 1 FROM user_plan_subscriptions WHERE reference = p_reference) THEN
    RETURN jsonb_build_object(
      'success', true,
      'idempotent', true,
      'message', 'Transaction previously completed.'
    );
  END IF;

  -- 2. Validate User
  SELECT * INTO v_user FROM users WHERE id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'User does not exist.';
  END IF;
  IF v_user.is_banned THEN
    RAISE EXCEPTION 'Account suspended. Plan activations are prohibited.';
  END IF;
  IF NOT v_user.is_active THEN
    RAISE EXCEPTION 'Account is inactive.';
  END IF;

  -- 3. Validate Target Plan
  SELECT * INTO v_plan FROM plans WHERE tier = p_target_tier AND is_active = TRUE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Target plan tier is invalid or currently inactive.';
  END IF;

  v_previous_tier := v_user.plan_tier;
  IF v_previous_tier = v_plan.tier THEN
    RAISE EXCEPTION 'User is already subscribed to % (%)', v_plan.name, v_plan.tier;
  END IF;

  -- 4. Lock Wallet Row & Prevent Concurrency / Negative Balances
  SELECT * INTO v_wallet FROM wallets WHERE user_id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Wallet record not found.';
  END IF;

  v_balance_before := v_wallet.available_balance_usd;
  IF v_balance_before < v_plan.price_usd THEN
    RAISE EXCEPTION 'Insufficient available balance. Required: $%, Available: $%. Please deposit funds.',
      v_plan.price_usd, v_balance_before;
  END IF;

  v_balance_after := ROUND((v_balance_before - v_plan.price_usd), 2);

  -- 5. Deduct Wallet Balance
  UPDATE wallets
  SET available_balance_usd = v_balance_after,
      updated_at = NOW()
  WHERE user_id = p_user_id;

  -- 6. Insert Completed Transaction Record
  INSERT INTO wallet_transactions (
    user_id,
    type,
    amount_usd,
    amount_ngn,
    conversion_rate,
    fee_usd,
    net_amount_usd,
    currency,
    status,
    reference,
    description,
    metadata
  ) VALUES (
    p_user_id,
    'plan_upgrade',
    v_plan.price_usd,
    v_plan.price_ngn,
    COALESCE((SELECT deposit_reference_rate_ngn_per_usd FROM platform_settings WHERE id='default'), 1500.00),
    0.00,
    v_plan.price_usd,
    'USD',
    'completed',
    p_reference,
    'Upgraded to ' || v_plan.name || ' (' || v_plan.tier || ')',
    jsonb_build_object(
      'previous_tier', v_previous_tier,
      'new_tier', v_plan.tier,
      'balance_before', v_balance_before,
      'balance_after', v_balance_after
    )
  ) RETURNING id INTO v_tx_id;

  -- 7. Insert Immutable Double-Entry Ledger Movement
  INSERT INTO wallet_ledger (
    user_id,
    transaction_id,
    entry_type,
    account,
    amount_usd,
    balance_before_usd,
    balance_after_usd,
    description,
    reference,
    actor_type,
    actor_id
  ) VALUES (
    p_user_id,
    v_tx_id,
    'debit',
    'available_balance',
    v_plan.price_usd,
    v_balance_before,
    v_balance_after,
    'Plan upgrade to ' || v_plan.name || ' (' || p_reference || ')',
    p_reference,
    'user',
    p_user_id
  );

  -- 8. Record in User Plan Subscriptions Table
  INSERT INTO user_plan_subscriptions (
    user_id,
    previous_plan_tier,
    new_plan_tier,
    transaction_id,
    amount_usd,
    amount_ngn,
    status,
    reference,
    activated_at
  ) VALUES (
    p_user_id,
    v_previous_tier,
    v_plan.tier,
    v_tx_id,
    v_plan.price_usd,
    v_plan.price_ngn,
    'active',
    p_reference,
    NOW()
  );

  -- 9. Update User Plan Tier
  UPDATE users
  SET plan_tier = v_plan.tier,
      updated_at = NOW()
  WHERE id = p_user_id;

  -- 10. Audit Log & Notification
  INSERT INTO audit_logs (
    user_id,
    action,
    category,
    details
  ) VALUES (
    p_user_id,
    'plan.purchased',
    'wallet',
    jsonb_build_object(
      'previous_tier', v_previous_tier,
      'new_tier', v_plan.tier,
      'price_usd', v_plan.price_usd,
      'reference', p_reference
    )
  );

  INSERT INTO notifications (
    user_id,
    title,
    message,
    type,
    link
  ) VALUES (
    p_user_id,
    'Plan Upgraded Successfully!',
    'Congratulations! You have upgraded to ' || v_plan.name || ' (' || v_plan.tier || '). Your new task limits and payout privileges are active.',
    'account',
    '/plans'
  );

  RETURN jsonb_build_object(
    'success', true,
    'message', 'Plan successfully upgraded to ' || v_plan.name,
    'new_tier', v_plan.tier,
    'previous_tier', v_previous_tier,
    'new_balance_usd', v_balance_after,
    'reference', p_reference
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

-- Procedure 2: Atomic Saturday Withdrawal Request
CREATE OR REPLACE FUNCTION process_withdrawal_request(
  p_user_id UUID,
  p_amount_usd NUMERIC,
  p_withdrawal_method VARCHAR,
  p_destination_details JSONB,
  p_reference VARCHAR
)
RETURNS JSONB AS $$
DECLARE
  v_user users%ROWTYPE;
  v_wallet wallets%ROWTYPE;
  v_settings platform_settings%ROWTYPE;
  v_min_threshold NUMERIC;
  v_fee_percent NUMERIC;
  v_fee_usd NUMERIC;
  v_net_usd NUMERIC;
  v_conversion_rate NUMERIC;
  v_final_ngn NUMERIC;
  v_balance_before NUMERIC;
  v_balance_after NUMERIC;
  v_tx_id UUID;
  v_is_saturday BOOLEAN;
BEGIN
  IF COALESCE(auth.jwt() ->> 'role','authenticated') <> 'service_role'
     AND NOT is_admin()
     AND NOT EXISTS (SELECT 1 FROM users WHERE id = p_user_id AND supabase_auth_id = auth.uid()) THEN
    RAISE EXCEPTION 'Security violation: cannot withdraw for another user.';
  END IF;

  -- 1. Idempotency Guard
  IF EXISTS (SELECT 1 FROM wallet_transactions WHERE reference = p_reference) THEN
    RETURN jsonb_build_object(
      'success', true,
      'idempotent', true,
      'message', 'Withdrawal request previously queued.'
    );
  END IF;

  -- 2. Fetch Settings
  SELECT * INTO v_settings FROM platform_settings WHERE id = 'default';
  v_conversion_rate := COALESCE(v_settings.withdrawal_reference_rate_ngn_per_usd, 1200.00);

  -- 3. Enforce Saturday withdrawal window server-side.
  v_is_saturday := (EXTRACT(DOW FROM (NOW() AT TIME ZONE 'UTC' + INTERVAL '1 hour')) = COALESCE(v_settings.withdrawal_window_day_num, 6));
  IF NOT v_is_saturday THEN
    RAISE EXCEPTION 'Withdrawals are currently closed. Payout requests are permitted exclusively during the configured withdrawal window.';
  END IF;

  -- 4. Validate User
  SELECT * INTO v_user FROM users WHERE id = p_user_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found.';
  END IF;
  IF v_user.is_banned THEN
    RAISE EXCEPTION 'Account suspended.';
  END IF;

  -- 5. Validate Minimum Threshold by Tier
  SELECT min_withdrawal_usd INTO v_min_threshold FROM plans WHERE tier = v_user.plan_tier;
  IF v_min_threshold IS NULL THEN
    v_min_threshold := 20.00;
  END IF;

  IF p_amount_usd < v_min_threshold THEN
    RAISE EXCEPTION 'Minimum withdrawal threshold for tier % is $%.', v_user.plan_tier, v_min_threshold;
  END IF;

  -- 6. Lock Wallet Row
  SELECT * INTO v_wallet FROM wallets WHERE user_id = p_user_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Wallet record not found.';
  END IF;

  v_balance_before := v_wallet.available_balance_usd;
  IF v_balance_before < p_amount_usd THEN
    RAISE EXCEPTION 'Insufficient available balance. You have $%, requested $%.',
      v_balance_before, p_amount_usd;
  END IF;

  -- 7. Calculate Fee & Settlement Net
  v_fee_percent := COALESCE(v_settings.standard_withdrawal_fee_percent, 15.00);
  v_fee_usd := ROUND((p_amount_usd * v_fee_percent / 100.0), 2);
  v_net_usd := ROUND((p_amount_usd - v_fee_usd), 2);
  v_final_ngn := ROUND((v_net_usd * v_conversion_rate), 2);
  v_balance_after := ROUND((v_balance_before - p_amount_usd), 2);

  -- 8. Deduct Balance Atomically
  UPDATE wallets
  SET available_balance_usd = v_balance_after,
      total_withdrawn_usd = total_withdrawn_usd + p_amount_usd,
      updated_at = NOW()
  WHERE user_id = p_user_id;

  -- 9. Insert Withdrawal Transaction
  INSERT INTO wallet_transactions (
    user_id,
    type,
    amount_usd,
    amount_ngn,
    conversion_rate,
    fee_usd,
    net_amount_usd,
    currency,
    status,
    reference,
    description,
    destination_details,
    metadata
  ) VALUES (
    p_user_id,
    'withdrawal',
    p_amount_usd,
    p_amount_usd * v_conversion_rate,
    v_conversion_rate,
    v_fee_usd,
    v_net_usd,
    'USD',
    'processing',
    p_reference,
    'Withdrawal to ' || COALESCE(p_destination_details ->> 'bankName', 'Bank') || ' (' || p_reference || ')',
    p_destination_details,
    jsonb_build_object(
      'fee_percent', v_fee_percent,
      'fee_usd', v_fee_usd,
      'net_amount_usd', v_net_usd,
      'final_amount_ngn', v_final_ngn
    )
  ) RETURNING id INTO v_tx_id;

  -- 10. Insert Double-Entry Ledger Entry
  INSERT INTO wallet_ledger (
    user_id,
    transaction_id,
    entry_type,
    account,
    amount_usd,
    balance_before_usd,
    balance_after_usd,
    description,
    reference,
    actor_type,
    actor_id
  ) VALUES (
    p_user_id,
    v_tx_id,
    'debit',
    'available_balance',
    p_amount_usd,
    v_balance_before,
    v_balance_after,
    'Withdrawal request (' || p_reference || ')',
    p_reference,
    'user',
    p_user_id
  );

  -- 11. Audit Log & Notification
  INSERT INTO audit_logs (
    user_id,
    action,
    category,
    details
  ) VALUES (
    p_user_id,
    'withdrawal.requested',
    'wallet',
    jsonb_build_object(
      'amount_usd', p_amount_usd,
      'fee_usd', v_fee_usd,
      'net_usd', v_net_usd,
      'reference', p_reference
    )
  );

  INSERT INTO notifications (
    user_id,
    title,
    message,
    type,
    link
  ) VALUES (
    p_user_id,
    'Withdrawal Request Submitted',
    'Your withdrawal of $' || p_amount_usd || ' (Net: ₦' || v_final_ngn || ') has been queued for scheduled settlement.',
    'withdrawal',
    '/transactions'
  );

  RETURN jsonb_build_object(
    'success', true,
    'transaction_id', v_tx_id,
    'reference', p_reference,
    'requested_usd', p_amount_usd,
    'fee_usd', v_fee_usd,
    'net_usd', v_net_usd,
    'final_ngn', v_final_ngn,
    'new_balance_usd', v_balance_after
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

-- Never expose controlled financial functions to anonymous clients.
REVOKE ALL ON FUNCTION process_plan_upgrade(UUID, VARCHAR, VARCHAR) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION process_plan_upgrade(UUID, VARCHAR, VARCHAR) TO authenticated, service_role;
REVOKE ALL ON FUNCTION process_withdrawal_request(UUID, NUMERIC, VARCHAR, JSONB, VARCHAR) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION process_withdrawal_request(UUID, NUMERIC, VARCHAR, JSONB, VARCHAR) TO authenticated, service_role;

-- ==============================================================================
-- 8. ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================

-- Enable RLS across all tables
ALTER TABLE platform_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE announcements ENABLE ROW LEVEL SECURITY;
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE kyc_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallet_ledger ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_plan_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE legal_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- 8.1. PUBLIC READ POLICIES (Anonymous & Authenticated Users)
CREATE POLICY "Public read platform settings" ON platform_settings FOR SELECT USING (true);
CREATE POLICY "Public read active support channels" ON support_channels FOR SELECT USING (is_active = true);
CREATE POLICY "Public read active announcements" ON announcements FOR SELECT USING (is_active = true);
CREATE POLICY "Public read active plans" ON plans FOR SELECT USING (is_active = true);
CREATE POLICY "Public read active tasks" ON tasks FOR SELECT USING (is_active = true);
CREATE POLICY "Public read published blog posts" ON blog_posts FOR SELECT USING (status = 'published');
CREATE POLICY "Public read legal documents" ON legal_documents FOR SELECT USING (true);

-- 8.2. AUTHENTICATED USERS: PRIVATE ISOLATION POLICIES
-- Users Profile
CREATE POLICY "Users read their own profile" ON users FOR SELECT USING (auth.uid() = supabase_auth_id);
CREATE POLICY "Users update their own profile" ON users FOR UPDATE USING (auth.uid() = supabase_auth_id) WITH CHECK (auth.uid() = supabase_auth_id);

-- Wallets: READ-ONLY for users. Mutations strictly handled via atomic stored functions & ledger.
CREATE POLICY "Users read their own wallet" ON wallets FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = wallets.user_id));

-- Transactions: READ-ONLY for users.
CREATE POLICY "Users read their own transactions" ON wallet_transactions FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = wallet_transactions.user_id));

-- Double-Entry Ledger: READ-ONLY for users.
CREATE POLICY "Users read their own ledger" ON wallet_ledger FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = wallet_ledger.user_id));

-- Plan Subscriptions: READ-ONLY for users.
CREATE POLICY "Users read their own plan subscriptions" ON user_plan_subscriptions FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = user_plan_subscriptions.user_id));

-- KYC Identity Verification
CREATE POLICY "Users read their own KYC" ON kyc_verifications FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = kyc_verifications.user_id));
CREATE POLICY "Users submit their own KYC" ON kyc_verifications FOR INSERT WITH CHECK (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = kyc_verifications.user_id) AND status = 'pending' AND reviewed_by IS NULL AND reviewed_at IS NULL);

-- Tasks & Task Submissions
CREATE POLICY "Users read their own task submissions" ON task_submissions FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = task_submissions.user_id));
CREATE POLICY "Users start task submissions" ON task_submissions FOR INSERT WITH CHECK (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = task_submissions.user_id));
CREATE POLICY "Users submit task proofs" ON task_submissions FOR UPDATE USING (
  auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = task_submissions.user_id) AND status = 'in_progress'
) WITH CHECK (
  auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = task_submissions.user_id) AND (status = 'in_progress' OR status = 'submitted')
);

-- Referral Rewards
CREATE POLICY "Users read their own referral rewards" ON referral_rewards FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = referral_rewards.referrer_user_id));

-- In-App Notifications
CREATE POLICY "Users read their own notifications" ON notifications FOR SELECT USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = notifications.user_id));
CREATE POLICY "Users mark notifications read" ON notifications FOR UPDATE USING (auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = notifications.user_id));

-- Support Tickets (Restricted: Users can only view & create tickets for themselves)
CREATE POLICY "Users read their own support tickets" ON support_tickets FOR SELECT USING (
  user_id IS NOT NULL AND auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = support_tickets.user_id)
);
CREATE POLICY "Users create their own support tickets" ON support_tickets FOR INSERT WITH CHECK (
  user_id IS NULL OR auth.uid() IN (SELECT supabase_auth_id FROM users WHERE id = support_tickets.user_id)
);

-- 8.3. ADMINISTRATOR PRIVILEGED POLICIES (TRIZZ Admin Control Center)
-- Uses is_admin() to prevent RLS recursion
CREATE POLICY "Admins full access to platform_settings" ON platform_settings FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to support_channels" ON support_channels FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to announcements" ON announcements FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to plans" ON plans FOR ALL USING (is_admin());
CREATE POLICY "Admins view all users" ON users FOR SELECT USING (is_admin());
CREATE POLICY "Admins update users" ON users FOR UPDATE USING (is_admin());
CREATE POLICY "Admins view all wallets" ON wallets FOR SELECT USING (is_admin());
-- NOTE: Admins DO NOT have direct UPDATE policy on wallets; financial adjustments must occur via ledger-audited routes
CREATE POLICY "Admins view all transactions" ON wallet_transactions FOR SELECT USING (is_admin());
-- Financial transaction status changes must go through controlled server/admin workflows.
-- No direct client UPDATE policy is granted to admins here.
CREATE POLICY "Admins view all ledger" ON wallet_ledger FOR SELECT USING (is_admin());
CREATE POLICY "Admins view all plan subscriptions" ON user_plan_subscriptions FOR SELECT USING (is_admin());
CREATE POLICY "Admins full access to tasks" ON tasks FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to task_submissions" ON task_submissions FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to referral_rewards" ON referral_rewards FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to blog_posts" ON blog_posts FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to legal_documents" ON legal_documents FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to kyc_verifications" ON kyc_verifications FOR ALL USING (is_admin());
CREATE POLICY "Admins full access to support_tickets" ON support_tickets FOR ALL USING (is_admin());
CREATE POLICY "Admins insert notifications" ON notifications FOR INSERT WITH CHECK (is_admin());
CREATE POLICY "Admins view audit_logs" ON audit_logs FOR SELECT USING (is_admin());
CREATE POLICY "Admins insert audit_logs" ON audit_logs FOR INSERT WITH CHECK (is_admin());

-- ==============================================================================
-- 9. PERFORMANCE INDEXES
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_users_supabase_auth_id ON users(supabase_auth_id);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

CREATE INDEX IF NOT EXISTS idx_wallets_user_id ON wallets(user_id);

CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_status ON wallet_transactions(status);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_type ON wallet_transactions(type);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_reference ON wallet_transactions(reference);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at ON wallet_transactions(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_wallet_ledger_user_id ON wallet_ledger(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_ledger_reference ON wallet_ledger(reference);
CREATE INDEX IF NOT EXISTS idx_wallet_ledger_created_at ON wallet_ledger(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_plan_subs_user_id ON user_plan_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_user_plan_subs_reference ON user_plan_subscriptions(reference);

CREATE INDEX IF NOT EXISTS idx_kyc_user_id ON kyc_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_kyc_status ON kyc_verifications(status);

CREATE INDEX IF NOT EXISTS idx_tasks_category ON tasks(category);
CREATE INDEX IF NOT EXISTS idx_tasks_is_active ON tasks(is_active);

CREATE INDEX IF NOT EXISTS idx_task_subs_user_id ON task_submissions(user_id);
CREATE INDEX IF NOT EXISTS idx_task_subs_task_id ON task_submissions(task_id);
CREATE INDEX IF NOT EXISTS idx_task_subs_status ON task_submissions(status);

CREATE INDEX IF NOT EXISTS idx_referral_rewards_referrer ON referral_rewards(referrer_user_id);
CREATE INDEX IF NOT EXISTS idx_referral_rewards_status ON referral_rewards(status);

CREATE INDEX IF NOT EXISTS idx_blog_posts_slug ON blog_posts(slug);
CREATE INDEX IF NOT EXISTS idx_blog_posts_status ON blog_posts(status);

CREATE INDEX IF NOT EXISTS idx_support_tickets_user_id ON support_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON support_tickets(status);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read);

CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);
