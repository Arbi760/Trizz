-- ==============================================================================
-- TRIZZ PLATFORM — INITIAL BASELINE SEED DATA
-- Run after schema.sql to populate baseline configuration for Public & Admin applications.
-- ==============================================================================

-- 1. PLATFORM SETTINGS
INSERT INTO platform_settings (
  id,
  deposit_reference_rate_ngn_per_usd,
  withdrawal_reference_rate_ngn_per_usd,
  standard_withdrawal_fee_percent,
  auto_withdrawal_fee_percent,
  withdrawal_window_day,
  withdrawal_window_day_num,
  withdrawal_opening_hour,
  withdrawal_closing_hour,
  withdrawal_timezone,
  withdrawal_timezone_offset,
  crypto_deposit_enabled,
  crypto_deposit_asset,
  crypto_deposit_network,
  crypto_deposit_address,
  crypto_deposit_min_usd,
  maintenance_mode,
  compliance_statement
) VALUES (
  'default',
  1500.00,
  1200.00,
  15.00,
  2.50,
  'Saturday',
  6,
  0,
  23,
  'UTC+1 / West Africa Time (WAT)',
  1,
  false,
  'USDT',
  'BEP-20 (BNB Smart Chain)',
  NULL,
  10.00,
  false,
  'TRIZZ operates in strict compliance with applicable consumer protection standards, digital asset transparency frameworks, and anti-money-laundering (AML) protocols. Jurisdictional licensing credentials will be updated by authorized compliance officers.'
) ON CONFLICT (id) DO UPDATE SET
  deposit_reference_rate_ngn_per_usd = EXCLUDED.deposit_reference_rate_ngn_per_usd,
  withdrawal_reference_rate_ngn_per_usd = EXCLUDED.withdrawal_reference_rate_ngn_per_usd,
  updated_at = NOW();

-- 2–3. Support channels and announcements are intentionally empty until an authorized admin configures real values.

-- 4. PLANS & PRODUCT TIERS (T1–T7)
INSERT INTO plans (
  id, tier, name, price_usd, price_ngn, description, features, min_withdrawal_usd, min_withdrawal_ngn, daily_task_cap, referral_bonus_percentage, is_active, sort_order
) VALUES
  (
    't1', 'T1', 'Tier 1 — Starter Access', 10.00, 15000.00,
    'Entry-level participant tier with access to core digital micro-tasks and scheduled payouts.',
    '["Access to basic task opportunities", "5% direct referral commission", "Saturday scheduled payouts", "Standard support queue"]'::jsonb,
    20.00, 24000.00, 3, 5.00, true, 1
  ),
  (
    't2', 'T2', 'Tier 2 — Member Tier', 25.00, 37500.00,
    'Elevated daily task quotas and enhanced referral yields for regular active participants.',
    '["Access to intermediate tasks", "7% direct referral commission", "Saturday scheduled payouts", "Standard verification review"]'::jsonb,
    40.00, 48000.00, 5, 7.00, true, 2
  ),
  (
    't3', 'T3', 'Tier 3 — Contributor', 40.00, 60000.00,
    'Expanded earning opportunities with higher task allocations and priority support.',
    '["Expanded daily task pool", "8% direct referral commission", "Accelerated review times", "Auto-withdrawal eligibility"]'::jsonb,
    60.00, 72000.00, 8, 8.00, true, 3
  ),
  (
    't4', 'T4', 'Tier 4 — Advanced Tier', 65.00, 97500.00,
    'Popular tier providing optimal balance between task rewards and fast turnaround.',
    '["High-yield task verification", "10% direct referral commission", "Priority Saturday payouts", "Reduced processing turnaround"]'::jsonb,
    80.00, 96000.00, 12, 10.00, true, 4
  ),
  (
    't5', 'T5', 'Tier 5 — Professional', 80.00, 120000.00,
    'Substantial daily task quota designed for power users and active team builders.',
    '["Premium partner task library", "12% direct referral commission", "Priority automated payouts", "Dedicated support manager"]'::jsonb,
    100.00, 120000.00, 15, 12.00, true, 5
  ),
  (
    't6', 'T6', 'Tier 6 — Executive Member', 115.00, 172500.00,
    'Comprehensive access with maximum task allocation and priority escalation queues.',
    '["Exclusive brand verification tasks", "14% direct referral commission", "Instant approval queue", "VIP telegram channel access"]'::jsonb,
    200.00, 240000.00, 20, 14.00, true, 6
  ),
  (
    't7', 'T7', 'Tier 7 — Premier Enterprise', 205.00, 307500.00,
    'Top-tier flagship membership with highest task allocations and maximum payout privileges.',
    '["Unrestricted task allocation", "16% direct referral commission", "Zero-delay automated payouts", "Direct compliance liaison", "Maximum earning ceiling"]'::jsonb,
    380.00, 456000.00, 30, 16.00, true, 7
  )
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  price_usd = EXCLUDED.price_usd,
  price_ngn = EXCLUDED.price_ngn,
  min_withdrawal_usd = EXCLUDED.min_withdrawal_usd,
  min_withdrawal_ngn = EXCLUDED.min_withdrawal_ngn,
  updated_at = NOW();

-- 5. INITIAL LEGAL & REGULATORY DOCUMENTS
INSERT INTO legal_documents (slug, title, version, effective_date, last_updated, sections, regulatory_notice) VALUES
  (
    'terms',
    'TRIZZ Platform Terms of Service',
    '2.4.0',
    '2026-01-01',
    '2026-09-01',
    '[
      {"id": "acceptance", "heading": "1. Acceptance of Terms", "content": "By accessing, registering, or interacting with TRIZZ (the Platform), you acknowledge that you have read, understood, and agree to be bound by these Terms of Service. If you do not agree to these terms, you must immediately cease all access and utilization of the Platform."},
      {"id": "eligibility", "heading": "2. Eligibility & Account Integrity", "content": "You must be at least 18 years old and legally capable of entering binding agreements in your jurisdiction. Each user is strictly permitted one active account. Maintaining multiple or coordinated duplicate accounts is grounds for immediate termination and forfeiture of unverified balances."},
      {"id": "financial", "heading": "3. Rates, Withdrawals & Ledger Rules", "content": "All platform financial operations operate through an auditable double-entry ledger. Withdrawals are processed exclusively within the Saturday Scheduled Window (00:00 to 23:59 WAT). Standard withdrawals are subject to a 15% platform processing fee, while Auto-Withdrawals enjoy a discounted 2.5% fee."},
      {"id": "kyc", "heading": "4. Identity Verification & Anti-Fraud", "content": "To prevent unauthorized activity, money laundering, and identity fraud, TRIZZ enforces multi-tier Know Your Customer (KYC) identity verification before processing eligible withdrawal requests."}
    ]'::jsonb,
    'TRIZZ complies with digital consumer protection guidelines and transparent financial operating rules. Official corporate licensing credentials will be displayed upon administrative audit finalization.'
  ),
  (
    'privacy',
    'TRIZZ Privacy & Data Protection Policy',
    '2.1.0',
    '2026-01-01',
    '2026-09-01',
    '[
      {"id": "collection", "heading": "1. Information We Collect", "content": "We collect information necessary to provide account services, fulfill KYC legal obligations, prevent fraudulent transactions, and facilitate peer referral matching."},
      {"id": "protection", "heading": "2. Data Security & Storage", "content": "All sensitive identity documentation and authentication credentials are encrypted in transit and at rest using enterprise-grade AES-256 and SSL/TLS 1.3 cryptographic protocols."},
      {"id": "sharing", "heading": "3. Third-Party Sharing Restrictions", "content": "TRIZZ does not sell, rent, or monetize personal user data to advertisers. Information is disclosed strictly where required by valid legal process or authorized financial clearinghouses."}
    ]'::jsonb,
    'Data processing is carried out in adherence with applicable data protection legislation and privacy standards.'
  ),
  (
    'risk-disclosure',
    'TRIZZ Platform Risk & Operating Disclosure',
    '1.5.0',
    '2026-01-01',
    '2026-09-01',
    '[
      {"id": "operational", "heading": "1. Operational Nature of Earning Tasks", "content": "Earnings on TRIZZ are directly contingent upon the successful completion, submission, and verification of eligible partner tasks. Membership tiers provide access to task opportunities and do not represent passive guaranteed returns."},
      {"id": "currency", "heading": "2. Currency & Conversion Dynamics", "content": "Platform balances are tracked in US Dollar equivalents with authorized reference conversion rates applied to local settlements. Users acknowledge potential exchange rate variance between external markets and internal reference rates."}
    ]'::jsonb,
    'This disclosure highlights key operational mechanics to ensure informed and transparent user participation.'
  )
ON CONFLICT (slug) DO UPDATE SET
  title = EXCLUDED.title,
  sections = EXCLUDED.sections,
  last_updated = EXCLUDED.last_updated,
  updated_at = NOW();
